#!/usr/bin/env python3
"""GB2312 中文字符串编码工具 - 生成 C 语言 hex 数组

用法:
  python gb2312tool.py "欢迎使用"
  python gb2312tool.py "无效命令："

输出:
  中文原文 + GB2312 hex 数组 + C 代码片段
"""
import sys

def encode_gb2312(text):
    encoded = text.encode('gb2312')
    hexarr = ', '.join(f'0x{b:02x}' for b in encoded)
    hexesc = ''.join(f'\\x{b:02x}' for b in encoded)
    return encoded, hexarr, hexesc

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("用法: python gb2312tool.py \"中文字符串\"")
        sys.exit(1)

    text = sys.argv[1]
    encoded, hexarr, hexesc = encode_gb2312(text)

    print(f"原文: {text}")
    print(f"GB2312 hex: {hexarr}")
    print(f"转义序列: {hexesc}")
    print(f"C 数组: unsigned char str[] = {{{hexarr}, 0x00}};  /* {text} */")
    print(f"C 字符串: \"{hexesc}\"  /* {text} */")
