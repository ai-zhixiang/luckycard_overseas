#!/usr/bin/env python3
"""gb2hex.py - C 源码中文预处理器

功能：扫描 C 源文件中的字符串字面量，将 UTF-8 中文字符自动转为 GB2312 \\xHH 转义序列。
OSASK 工具链 (cc1.exe) 不支持 UTF-8/GBK 源文件，此脚本作为预处理步骤解决此问题。

用法：
  python py/gb2hex.py kernel/console.c temp/console.c

规则：
  - "无效命令："   → "\xce\xde\xd0\xa7\xc3\xfc\xc1\xee\xa3\xba"
  - ASCII 字符保持不变
  - 已有的 \\xHH 转义保持不变
  - char 数组初始化中的中文字符同样处理
  - 不在字符串内的中文（注释中的）不处理
"""

import sys
import re

def process_string_literal(s):
    """处理一个字符串字面量内容（不含引号），将 UTF-8 中文转为 GB2312 \\xHH"""
    result = []
    i = 0
    raw = s.encode('utf-8') if isinstance(s, str) else s
    # 先按 utf-8 解码原始内容
    text = s
    i = 0
    out = []
    while i < len(text):
        ch = text[i]
        if ch == '\\' and i + 1 < len(text):
            # 已有转义序列，原样保留
            next_ch = text[i + 1]
            if next_ch == 'x' and i + 3 < len(text):
                # \xHH 转义，保留原样
                out.append(text[i:i+4])
                i += 4
            elif next_ch in ('n', 't', 'r', '0', '\\', '"', "'", 'a', 'b', 'f', 'v'):
                out.append(text[i:i+2])
                i += 2
            elif next_ch >= '0' and next_ch <= '7':
                # 八进制转义 \ooo
                j = i + 1
                while j < len(text) and j < i + 4 and text[j] >= '0' and text[j] <= '7':
                    j += 1
                out.append(text[i:j])
                i = j
            else:
                out.append(text[i:i+2])
                i += 2
        elif ord(ch) > 127:
            # 非 ASCII 字符（中文等），转 GB2312 hex 转义
            try:
                gb = ch.encode('gb2312')
                for b in gb:
                    out.append(f'\\x{b:02x}')
            except UnicodeEncodeError:
                # GB2312 编码失败，保留原字符（会出错但至少不丢数据）
                out.append(ch)
            i += 1
        else:
            out.append(ch)
            i += 1
    return ''.join(out)


def process_char_array_init(s):
    """处理 char/unsigned char 数组初始化列表中的中文字符
    例如: {0xbf, 0xd8, '控', 0x00} 中的 '控' 会被转为 GB2312 字节
    """
    result = []
    i = 0
    while i < len(s):
        # 检测单引号内的中文字符：'中'
        if s[i] == "'" and i + 2 < len(s) and s[i+2] == "'" and ord(s[i+1]) > 127:
            ch = s[i+1]
            try:
                gb = ch.encode('gb2312')
                hex_items = ', '.join(f'0x{b:02x}' for b in gb)
                result.append(hex_items)
            except UnicodeEncodeError:
                result.append(s[i:i+3])
            i += 3
        else:
            result.append(s[i])
            i += 1
    return ''.join(result)


def preprocess_c_source(source_text):
    """预处理 C 源文件：将字符串字面量中的 UTF-8 中文转为 GB2312 \\xHH 转义"""
    result = []
    i = 0
    length = len(source_text)

    while i < length:
        ch = source_text[i]

        # 跳过行注释
        if ch == '/' and i + 1 < length and source_text[i + 1] == '/':
            end = source_text.find('\n', i)
            if end == -1:
                result.append(source_text[i:])
                break
            result.append(source_text[i:end + 1])
            i = end + 1
            continue

        # 跳过块注释
        if ch == '/' and i + 1 < length and source_text[i + 1] == '*':
            end = source_text.find('*/', i + 2)
            if end == -1:
                result.append(source_text[i:])
                break
            result.append(source_text[i:end + 2])
            i = end + 2
            continue

        # 处理字符串字面量 "..."
        if ch == '"':
            j = i + 1
            while j < length:
                if source_text[j] == '\\' and j + 1 < length:
                    j += 2  # 跳过转义
                elif source_text[j] == '"':
                    break
                else:
                    j += 1
            if j < length:
                # 提取字符串内容（不含引号）
                content = source_text[i + 1:j]
                processed = process_string_literal(content)
                result.append('"' + processed + '"')
                i = j + 1
            else:
                result.append(source_text[i])
                i += 1
            continue

        # 处理字符字面量 'x'
        if ch == "'" and i + 2 < length:
            if source_text[i + 1] == '\\':
                # 转义字符如 '\n'
                if i + 3 < length and source_text[i + 3] == "'":
                    result.append(source_text[i:i + 4])
                    i += 4
                else:
                    result.append(source_text[i])
                    i += 1
                continue
            elif source_text[i + 2] == "'":
                the_char = source_text[i + 1]
                if ord(the_char) > 127:
                    # 中文字符在单引号中 → 转为 GB2312 多字节
                    # 但 C char 只能存1字节，所以这是个错误用法，我们转为 hex
                    try:
                        gb = the_char.encode('gb2312')
                        # 用第一个字节作为字符值（不完美，但至少不崩溃）
                        result.append(f"'\\x{gb[0]:02x}'")
                    except:
                        result.append(source_text[i:i + 3])
                else:
                    result.append(source_text[i:i + 3])
                i += 3
                continue

        result.append(ch)
        i += 1

    return ''.join(result)


def main():
    if len(sys.argv) < 3:
        print(f"用法: python {sys.argv[0]} <输入文件> <输出文件>")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    with open(input_file, 'r', encoding='utf-8') as f:
        source = f.read()

    processed = preprocess_c_source(source)

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(processed)


if __name__ == '__main__':
    main()
