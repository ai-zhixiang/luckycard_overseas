"""
make_iso.py — 从 WinDOS.img 创建 El Torito 可引导 ISO
用法: python make_iso.py [输入img] [输出iso]
"""
import struct, sys

img_in = sys.argv[1] if len(sys.argv) > 1 else r'WinDOS.img'
iso_out = sys.argv[2] if len(sys.argv) > 2 else r'WinDOS.iso'

with open(img_in, 'rb') as f:
    floppy = f.read()

SEC = 2048
flop_secs = (len(floppy) + SEC - 1) // SEC
PVD = 16; BVD = 17; TERM = 18; CAT = 19; BOOT = 20
TOTAL = BOOT + flop_secs

iso = bytearray(TOTAL * SEC)

def w(s, o, d):
    iso[s*SEC+o : s*SEC+o+len(d)] = d

def wl(s, o, fmt, *vals):
    w(s, o, struct.pack('<' + fmt, *vals))

def wb(s, o, fmt, *vals):
    w(s, o, struct.pack('>' + fmt, *vals))

# --- Primary Volume Descriptor (sector 16) ---
w(16, 0, b'\x01CD001\x01')
w(16, 8,  b'WINDOS_BOOTABLE               ')
w(16, 40, b'WINDOS                         ')
wl(16, 80, 'I', TOTAL);  wb(16, 84, 'I', TOTAL)
wl(16, 120, 'H', 1);     wb(16, 124, 'H', 1)
wl(16, 128, 'H', 1);     wb(16, 132, 'H', 1)
wl(16, 132, 'H', SEC);   wb(16, 136, 'H', SEC)
wl(16, 140, 'I', 10);    wb(16, 144, 'I', 10)
wl(16, 148, 'I', 20);    wb(16, 152, 'I', 21)
# Root directory record (offset 156)
w(16, 156, bytes([34, 0]))
wl(16, 158, 'I', 22);    wl(16, 162, 'I', SEC)
wb(16, 166, 'I', 22);    wb(16, 170, 'I', SEC)
w(16, 174, b'\x00' * 7 + b'\x02\x02\x01')
wl(16, 184, 'H', 1);     wb(16, 186, 'H', 1)
w(16, 188, b'\x00\x00')

# --- Boot Record Volume Descriptor (sector 17) ---
w(17, 0, b'\x00CD001\x01')
w(17, 7, b'EL TORITO SPECIFICATION' + b'\x00' * 9)
wl(17, 71, 'I', CAT)

# --- Terminator (sector 18) ---
w(18, 0, b'\xffCD001\x01')

# --- Boot Catalog (sector 19) ---
w(19, 0, b'\x01\x00\x00\x00')
w(19, 4, b'WINDOS_BOOT_CATALOG\x00\x00\x00')
wl(19, 28, 'H', 0xAA55)
# Initial/Default boot entry
w(19, 32, b'\x88\x00\x00\x00')
wl(19, 36, 'H', 0)
w(19, 38, b'\x01\x00')
wl(19, 40, 'H', 1)         # 1 emulated 512-byte sector per CD sector
wl(19, 42, 'I', BOOT)       # boot image at sector 20

# --- Boot image (floppy disk image at sector 20) ---
iso[BOOT*SEC : BOOT*SEC + len(floppy)] = floppy

# --- Path tables ---
wl(20*SEC, 0, 'B', 1);    wl(20*SEC, 1, 'I', 22); wl(20*SEC, 7, 'H', 1)
wb(21*SEC, 0, 'B', 1);    wb(21*SEC, 1, 'I', 22); wb(21*SEC, 7, 'H', 1)

# --- Root directory (sector 22): '.' and '..' entries ---
def dir_entry(s, o, name_len, name_byte):
    w(s, o, bytes([34, 0]))
    wl(s, o+2, 'I', 22);   wl(s, o+6, 'I', SEC)
    wb(s, o+10, 'I', 22);  wb(s, o+14, 'I', SEC)
    w(s, o+18, b'\x00'*7 + b'\x02\x00\x00')
    wl(s, o+27, 'H', 1);   wb(s, o+29, 'H', 1)
    w(s, o+31, bytes([0, name_len, name_byte]))

dir_entry(22*SEC, 0, 1, 0)    # '.'
dir_entry(22*SEC, 34, 1, 1)   # '..'

with open(iso_out, 'wb') as f:
    f.write(iso)

print(f'Created {iso_out}')
print(f'  Size: {len(iso)} bytes ({len(iso)/1024/1024:.1f} MB)')
print(f'  Sectors: {TOTAL}')
print(f'  Boot image at sector {BOOT} (floppy emulation)')
