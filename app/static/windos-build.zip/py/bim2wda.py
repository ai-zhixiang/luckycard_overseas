#!/usr/bin/env python
# bim2wda.py - 将 obj2bim 生成的 .bim 文件转换为 WinDOS .wda 格式
#
# .bim 文件格式（基于 bootpack.bim 和 app .bim 分析）:
#   +0: 4 字节:  入口点（逻辑地址）
#   +4: 4 字节:  头部大小 (通常 36)
#   +8: 4 字节:  头部大小 (通常 36)
#  +12: 4 字节:  代码段大小 (codesize)
#  +16: 4 字节:  栈大小（由 rule 文件指定）
#  +20: 4 字节:  数据段大小 (datasize)
#  +24: 4 字节:  代码段逻辑起始地址
#  +28: 4 字节:  0
#  +32: 4 字节:  0
#  +36: 代码段开始（代码段 + 数据段按逻辑地址连续存储）
#
# 注意：数据段紧跟在代码段之后，但 .bim 文件的 "数据段" 实际上
# 包含 app.rul 中 file: 之外的其他 .obj 文件的代码和数据。
# 我们直接取偏移 36 之后的全部内容作为 .wda 负载。
#
# 用法:  python bim2wda.py 输入.bim 输出.wda [入口点] [栈大小]

import struct
import sys

def main():
    if len(sys.argv) < 3:
        print("用法: python bim2wda.py <输入.bim> <输出.wda> [入口点] [栈大小]")
        sys.exit(1)

    bim_path = sys.argv[1]
    wda_path = sys.argv[2]

    with open(bim_path, 'rb') as f:
        bim_data = f.read()

    if len(bim_data) < 36:
        print(f"错误: 输入文件太小 ({len(bim_data)} 字节)，不是有效的 .bim 文件")
        sys.exit(2)

    # 从 .bim 头部提取参数
    bim_entry = struct.unpack('<I', bim_data[0:4])[0]
    bim_stack = struct.unpack('<I', bim_data[16:20])[0]

    # 默认入口点为 0（代码段起始），允许命令行覆盖
    entry = int(sys.argv[3], 0) if len(sys.argv) > 3 else 0
    stack_size = int(sys.argv[4], 0) if len(sys.argv) > 4 else 8192

    # 头部大小固定为 36
    hdr_size = 36
    wda_body = bim_data[hdr_size:]

    # 如果 entry 没在命令行指定，搜索 _start 入口点
    if len(sys.argv) <= 3:
        # _start 特征码: E8 xx xx xx xx BA 04 00 00 00 CD 40
        end_pattern = bytes([0xBA, 0x04, 0x00, 0x00, 0x00, 0xCD, 0x40])
        for i in range(len(wda_body) - 12):
            if wda_body[i] == 0xe8:
                if wda_body[i+5:i+12] == end_pattern:
                    entry = i  # _start 在 body 中的偏移
                    break

    # 构建 .wda: 16 字节头部 + body
    wda_header = struct.pack('<4sIII', b'WDAG', entry, stack_size, 0)
    wda_size = len(wda_header) + len(wda_body)

    with open(wda_path, 'wb') as f:
        f.write(wda_header + wda_body)

    print(f"生成 {wda_path}: {wda_size} 字节")
    print(f"  + 入口点:   0x{entry:08x}")
    print(f"  + body:     {len(wda_body)} 字节")
    print(f"  + 栈大小:   {stack_size} 字节")

if __name__ == '__main__':
    main()
