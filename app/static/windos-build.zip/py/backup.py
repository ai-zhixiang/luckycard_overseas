import zipfile, os, datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
name = f'../WinDOS_build_{ts}.zip'

with zipfile.ZipFile(name, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk('.'):
        # 跳过临时构建目录和旧备份
        dirs[:] = [d for d in dirs if d not in ('temp', '__pycache__')]
        for f in files:
            if f.startswith('WinDOS_backup_') and f.endswith('.zip'):
                continue
            zf.write(os.path.join(root, f))

print(f'Created {name}')
