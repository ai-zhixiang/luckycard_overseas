"""fix_indent.py"""
import sys
START = '\u5f00\u59cb\u6309\u94ae\u70b9\u51fb\u68c0\u6d4b'
END = '===== \u63a7\u5236\u53f0\u76f8\u5173\u51fd\u6570 ====='

NEW = ""
with open(__file__, 'r') as f:
    for line in f:
        if line == '###CUT###\n': break
with open(__file__.replace('.py','.dat'), 'r') as f:
    NEW = f.read()

def fix(path):
    with open(path, 'r') as f: c = f.read()
    a = c.find(START); b = c.find(END)
    if a<0 or b<0: return False
    c = c[:a] + NEW + '\n' + c[b:]
    with open(path, 'w') as f: f.write(c)
    return True

if __name__ == '__main__':
    fix(sys.argv[1] if len(sys.argv)>1 else 'kernel/bootpack.c')
