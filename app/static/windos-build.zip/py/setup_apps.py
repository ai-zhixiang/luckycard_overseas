#!/usr/bin/env python3
"""setup_apps.py - 确保 apps/ 目录下关键文件存在，缺失则创建"""
import os

APPS_DIR = 'apps'

CRT0_NAS = '''[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "crt0.nas"]
\tGLOBAL\t_start
\tGLOBAL\t___main
\tEXTERN\t_main
[SECTION .text]
___main:
\tRET
_start:
\tCALL\t_main
\tMOV\tEDX,4
\tINT\t0x40
'''

APILIB_NAS = '''; apilib.nas - WinDOS 应用程序 API 库
[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "apilib.nas"]

[SECTION .text]

\tGLOBAL\t_putchar
_putchar:\t; void putchar(int c);
\tMOV\tEDX,1
\tMOV\tEAX,[ESP+4]
\tINT\t0x40
\tRET

\tGLOBAL\t_putstr0
_putstr0:\t; void putstr0(char *s);
\tMOV\tEDX,2
\tMOV\tEBX,[ESP+4]
\tINT\t0x40
\tRET

\tGLOBAL\t_end
_end:\t\t; void end(void);
\tMOV\tEDX,4
\tINT\t0x40
\tRET

\tGLOBAL\t_createwin
_createwin:\t; int createwin(char *buf, int xsiz, int ysiz, int col_inv, char *title);
\tPUSH\tEBX
\tMOV\tEDX,5
\tMOV\tEBX,[ESP+8]
\tMOV\tESI,[ESP+12]
\tMOV\tEDI,[ESP+16]
\tMOV\tEAX,[ESP+20]
\tMOV\tECX,[ESP+24]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_putstrwin
_putstrwin:\t; void putstrwin(int win, int x, int y, int col, int len, char *str);
\tPUSH\tEBX
\tPUSH\tEBP
\tMOV\tEDX,6
\tMOV\tEBX,[ESP+12]
\tMOV\tESI,[ESP+16]
\tMOV\tEDI,[ESP+20]
\tMOV\tEAX,[ESP+24]
\tMOV\tECX,[ESP+28]
\tMOV\tEBP,[ESP+32]
\tINT\t0x40
\tPOP\tEBP
\tPOP\tEBX
\tRET

\tGLOBAL\t_boxfilwin
_boxfilwin:\t; void boxfilwin(int win, int x0, int y0, int x1, int y1, int col);
\tPUSH\tEBX
\tPUSH\tEBP
\tMOV\tEDX,7
\tMOV\tEBX,[ESP+12]
\tMOV\tEAX,[ESP+16]
\tMOV\tECX,[ESP+20]
\tMOV\tESI,[ESP+24]
\tMOV\tEDI,[ESP+28]
\tMOV\tEBP,[ESP+32]
\tINT\t0x40
\tPOP\tEBP
\tPOP\tEBX
\tRET

\tGLOBAL\t_linewin
_linewin:\t; void linewin(int win, int x0, int y0, int x1, int y1, int col);
\tPUSH\tEBX
\tPUSH\tEBP
\tMOV\tEDX,8
\tMOV\tEBX,[ESP+12]
\tMOV\tESI,[ESP+16]
\tMOV\tEDI,[ESP+20]
\tMOV\tEAX,[ESP+24]
\tMOV\tECX,[ESP+28]
\tMOV\tEBP,[ESP+32]
\tINT\t0x40
\tPOP\tEBP
\tPOP\tEBX
\tRET

\tGLOBAL\t_point
_point:\t\t; void point(int win, int x, int y, int col);
\tPUSH\tEBX
\tMOV\tEDX,9
\tMOV\tEBX,[ESP+8]
\tMOV\tESI,[ESP+12]
\tMOV\tEDI,[ESP+16]
\tMOV\tEAX,[ESP+20]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_refreshwin
_refreshwin:\t; void refreshwin(int win, int x0, int y0, int x1, int y1);
\tPUSH\tEBX
\tMOV\tEDX,10
\tMOV\tEBX,[ESP+8]
\tMOV\tESI,[ESP+12]
\tMOV\tEDI,[ESP+16]
\tMOV\tEAX,[ESP+20]
\tMOV\tECX,[ESP+24]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_closewin
_closewin:\t; void closewin(int win);
\tPUSH\tEBX
\tMOV\tEDX,11
\tMOV\tEBX,[ESP+8]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_getkey
_getkey:\t; int getkey(int mode);
\tMOV\tEDX,12
\tMOV\tEAX,[ESP+4]
\tINT\t0x40
\tRET

\tGLOBAL\t_show_menu
_show_menu:\t; int show_menu(int x, int y, struct MENU_ITEM *items, int count);
\tPUSH\tEBX
\tMOV\tEDX,13
\tMOV\tEBX,[ESP+8]
\tMOV\tESI,[ESP+12]
\tMOV\tEDI,[ESP+16]
\tMOV\tEAX,[ESP+20]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_setcritical
_setcritical:\t; void setcritical(int is_kernel, int bsod_on_kill, int is_system);
\tPUSH\tEBX
\tMOV\tEDX,14
\tMOV\tEBX,[ESP+8]
\tMOV\tESI,[ESP+12]
\tMOV\tEDI,[ESP+16]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_list_files
_list_files:\t; int list_files(void *buf, int buf_size);
\tPUSH\tEBX
\tMOV\tEDX,15
\tMOV\tEBX,[ESP+8]
\tMOV\tESI,[ESP+12]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_malloc
_malloc:\t; void *malloc(int size);
\tPUSH\tEBX
\tMOV\tEDX,16
\tMOV\tEBX,[ESP+8]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_free
_free:\t\t; void free(void *addr, int size);
\tPUSH\tEBX
\tMOV\tEDX,17
\tMOV\tEBX,[ESP+8]
\tMOV\tECX,[ESP+12]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_run_wda
_run_wda:\t; int run_wda(const char *fname);
\tPUSH\tEBX
\tMOV\tEDX,18
\tMOV\tEBX,[ESP+8]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_CreateProcess
_CreateProcess:\t; int CreateProcess(const char *fname);
\tPUSH\tEBX
\tMOV\tEDX,18
\tMOV\tEBX,[ESP+8]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_get_tasklist
_get_tasklist:\t; int get_tasklist(void *buf, int buf_size);
\tPUSH\tEBX
\tMOV\tEDX,19
\tMOV\tEBX,[ESP+8]
\tMOV\tESI,[ESP+12]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_kill_task
_kill_task:\t; int kill_task(int task_sel);
\tPUSH\tEBX
\tMOV\tEDX,20
\tMOV\tEBX,[ESP+8]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t_GetCurrentOSVersion
_GetCurrentOSVersion:\t; int GetCurrentOSVersion(void);
\tMOV\tEDX,21
\tINT\t0x40
\tRET

\tGLOBAL\t_is_window_valid
_is_window_valid:\t; int is_window_valid(int win);
\tPUSH\tEBX
\tMOV\tEDX,22
\tMOV\tEBX,[ESP+8]
\tINT\t0x40
\tPOP\tEBX
\tRET

\tGLOBAL\t__alloca
__alloca:
\tSUB\tESP,EAX
\tADD\tESP,-4
\tRET
'''

def ensure_file(filename, content):
    path = os.path.join(APPS_DIR, filename)
    need_create = False
    if not os.path.exists(path):
        need_create = True
    else:
        sz = os.path.getsize(path)
        if sz < 100:  # 文件太短，内容可能不对
            print(f'  ✗ {filename} 大小异常 ({sz} 字节)，将重建')
            need_create = True
        else:
            print(f'  [OK] {filename} exists ({sz} bytes)')
    if need_create:
        with open(path, 'w', newline='\r\n') as f:
            f.write(content)
        print(f'  [OK] {filename} created')

def main():
    os.makedirs(APPS_DIR, exist_ok=True)
    print('检查 apps/ 目录文件...')
    ensure_file('crt0.nas', CRT0_NAS)
    ensure_file('apilib.nas', APILIB_NAS)
    print('完成。')

if __name__ == '__main__':
    main()
