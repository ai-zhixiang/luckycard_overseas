from PIL import Image
import struct, os, sys
src = sys.argv[1]
dst = sys.argv[2]  # .raw or .c

img = Image.open(src).convert("RGBA")
white = Image.new("RGBA", img.size, (255, 255, 255, 255))
composite = Image.alpha_composite(white, img).resize((64, 64), Image.LANCZOS).convert("L")
data = [0 if v < 200 else 15 for v in list(composite.getdata())]

if dst.endswith('.raw'):
    raw = bytearray(struct.pack('<HH', 64, 64)) + bytes(data)
    open(dst, 'wb').write(raw)
    print(f"RAW: {dst} ({len(raw)}B)")
else:
    lines = ["static unsigned char icon[4096] = {"]
    for i in range(0, 4096, 16):
        lines.append("    " + ",".join(f"0x{v:02X}" for v in data[i:i+16]) + ",")
    lines.append("};")
    open(dst, 'w').write("\n".join(lines))
    print(f"C: {dst}")
