/* chinese_font.c - HZK16 中文字库渲染（直接链接进内核） */

#include "bootpack.h"
#include <string.h>

/* HZK16 字库数据（由 hzk16.obj 链接进内核） */
extern unsigned char hzk16[];

/* 汉字点阵缓存（用于绘制） */
static unsigned char g_font_buf[32];  /* 16x16 点阵 = 32 字节 */

/* ============================================================
 * 判断字符是否为 GB2312 汉字（区位码范围）
 *   GB2312 第一字节: 0xA1-0xF7 (区码)
 *   GB2312 第二字节: 0xA1-0xFE (位码)
 * ============================================================ */
int is_gb2312(unsigned char c1, unsigned char c2)
{
    return (c1 >= 0xA1 && c1 <= 0xF7 && c2 >= 0xA1 && c2 <= 0xFE);
}

/* ============================================================
 * 获取汉字在 HZK16 中的偏移量
 *   HZK16 排列顺序：按区位码
 *   GB2312 共 94区 × 94位，但 HZK16 只存了 87区 × 94位
 *   偏移 = ((区码-0xA1) * 94 + (位码-0xA1)) * 32
 * ============================================================ */
int hzk16_get_offset(unsigned char qu, unsigned char wei)
{
    int q = qu - 0xA1;   /* 0-based 区码 0~86 */
    int w = wei - 0xA1;  /* 0-based 位码 0~93 */
    return (q * 94 + w) * 32;
}

/* ============================================================
 * 获取汉字点阵数据
 *   ch1, ch2: GB2312 编码的两个字节
 *   buf: 输出缓冲区（至少 32 字节）
 *   返回 0 成功，-1 失败
 * ============================================================ */
int hzk16_get_font(unsigned char ch1, unsigned char ch2, unsigned char *buf)
{
    if (!is_gb2312(ch1, ch2)) {
        return -1;
    }

    int offset = hzk16_get_offset(ch1, ch2);
    memcpy(buf, &hzk16[offset], 32);
    return 0;
}

/* ============================================================
 * 在指定位置绘制一个汉字（16x16 点阵）
 *   buf:     图层缓冲区
 *   xsize:   图层宽度
 *   x, y:    绘制位置
 *   ch1, ch2: GB2312 编码
 *   col:      字体颜色（8位调色板索引）
 * ============================================================ */
void putfont8_hz(unsigned char *buf, int xsize, int x, int y,
                  unsigned char ch1, unsigned char ch2, unsigned char col)
{
    unsigned char font[32];
    int i, j;

    if (hzk16_get_font(ch1, ch2, font) != 0) {
        /* 取字模失败，画一个矩形占位 */
        boxfill8(buf, xsize, col, x, y, x + 15, y + 15);
        return;
    }

    /* font[0..31]：每两字节表示一行（16位 = 16像素）
     * font[0..1]   = 第0行
     * font[2..3]   = 第1行
     * ...
     * font[30..31] = 第15行
     */
    for (i = 0; i < 16; i++) {
        unsigned char b1 = font[i * 2];     /* 高8位 */
        unsigned char b2 = font[i * 2 + 1]; /* 低8位 */

        for (j = 0; j < 8; j++) {
            if (b1 & (0x80 >> j)) {
                buf[(y + i) * xsize + (x + j)] = col;
            }
        }
        for (j = 0; j < 8; j++) {
            if (b2 & (0x80 >> j)) {
                buf[(y + i) * xsize + (x + 8 + j)] = col;
            }
        }
    }
}

/* ============================================================
 * 绘制混合字符串（自动识别 ASCII / 汉字）
 *   buf:   图层缓冲区
 *   xsize: 图层宽度
 *   x, y:  绘制位置
 *   col:    字体颜色
 *   str:    字符串（支持 ASCII + GB2312 混合）
 *   返回：绘制完成后的 x 坐标（可用于连续绘制）
 * ============================================================ */
int putfonts8_asc_hz(unsigned char *buf, int xsize, int x, int y,
                      unsigned char col, unsigned char *str)
{
    int i = 0;
    while (str[i] != '\0') {
        if (str[i] >= 0x80 && str[i + 1] != '\0' &&
            is_gb2312(str[i], str[i + 1])) {
            /* 汉字：两个字节 */
            putfont8_hz(buf, xsize, x, y, str[i], str[i + 1], col);
            x += 16;   /* 汉字宽16像素 */
            i += 2;
        } else {
            /* ASCII：一个字节（使用原有 hankaku 字库） */
            putfonts8_asc(buf, xsize, x, y, col, (unsigned char *)&str[i]);
            x += 8;    /* ASCII 宽8像素 */
            i += 1;
        }
    }
    return x;
}

/* ============================================================
 * 检查 HZK16 字库是否可用（始终返回1，因为已链接进内核）
 * ============================================================ */
int hzk16_is_loaded(void)
{
    return 1;
}

/* ============================================================
 * 兼容性接口：hzk16_load()
 *   由于字库已链接进内核，此函数直接返回成功
 * ============================================================ */
int hzk16_load(void)
{
    return 0;
}
