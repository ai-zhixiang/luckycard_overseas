/* fat12.c - FAT12 读写（写在磁盘镜像上） */

#include "bootpack.h"
#include <string.h>

/* FAT12 常量 */
#define FAT_ENTRY_END    0xff8
#define FAT_ENTRY_FREE   0x000
#define ROOT_DIR_OFFSET  0x002600  /* 根目录在镜像中的偏移 */
#define FAT_OFFSET       0x000200  /* FAT表在镜像中的偏移 */

/* 读取FAT表到内存 */
void file_readfat(int *fat, unsigned char *img)
{
    int i, j = 0;
    for (i = 0; i < 2880; i += 2) {
        fat[i + 0] = (img[j + 0]      | img[j + 1] << 8) & 0xfff;
        fat[i + 1] = (img[j + 1] >> 4 | img[j + 2] << 4) & 0xfff;
        j += 3;
    }
    return;
}

/* 将内存中的FAT表写回磁盘镜像 */
void file_writefat(int *fat, unsigned char *img)
{
    int i, j = 0;
    for (i = 0; i < 2880; i += 2) {
        img[j + 0] = fat[i + 0] & 0xff;
        img[j + 1] = ((fat[i + 0] >> 8) & 0x0f) | ((fat[i + 1] & 0x0f) << 4);
        img[j + 2] = (fat[i + 1] >> 4) & 0xff;
        j += 3;
    }
    return;
}

/* 在FAT表中找空闲簇 */
int fat_find_free(int *fat)
{
    int i;
    for (i = 2; i < 2880; i++) {
        if (fat[i] == FAT_ENTRY_FREE) {
            return i;
        }
    }
    return -1;  /* 没空位了 */
}

/* 找根目录中的空闲项 */
int fat_find_free_entry(unsigned char *img)
{
    struct FILEINFO *finfo = (struct FILEINFO *) (img + ROOT_DIR_OFFSET);
    int i;
    for (i = 0; i < 224; i++) {
        if (finfo[i].name[0] == 0x00 || finfo[i].name[0] == 0xe5) {
            return i;
        }
    }
    return -1;
}

/* 创建文件（在根目录中写一个目录项，并分配起始簇） */
int fat_create(char *name, unsigned int size, int *fat, unsigned char *img)
{
    struct FILEINFO *finfo = (struct FILEINFO *) (img + ROOT_DIR_OFFSET);
    int entry, clust;
    int i, j;
    char s[12];

    /* 解析 8.3 文件名 */
    for (j = 0; j < 11; j++) s[j] = ' ';
    j = 0;
    for (i = 0; name[i] != 0; i++) {
        if (j >= 11) return -1;
        if (name[i] == '.' && j <= 8) {
            j = 8;
        } else {
            s[j] = name[i];
            if ('a' <= s[j] && s[j] <= 'z') s[j] -= 0x20;
            j++;
        }
    }

    /* 找空闲目录项 */
    entry = fat_find_free_entry(img);
    if (entry < 0) return -1;

    /* 分配起始簇 */
    clust = fat_find_free(fat);
    if (clust < 0) return -1;
    fat[clust] = FAT_ENTRY_END;

    /* 填写目录项 */
    for (j = 0; j < 8; j++)  finfo[entry].name[j] = s[j];
    for (j = 0; j < 3; j++)  finfo[entry].ext[j]  = s[8 + j];
    finfo[entry].type    = 0x20;  /* 普通文件 */
    finfo[entry].clustno = clust;
    finfo[entry].size    = size;
    for (j = 0; j < 10; j++) finfo[entry].reserve[j] = 0;
    finfo[entry].time = 0;
    finfo[entry].date = 0;

    return clust;
}

/* 分配一个新簇并追加到文件簇链末尾 */
int fat_append_cluster(int clust, int *fat)
{
    int new_clust, cur = clust;

    /* 找到链尾 */
    while (fat[cur] < FAT_ENTRY_END) {
        cur = fat[cur];
    }

    /* 分配新簇 */
    new_clust = fat_find_free(fat);
    if (new_clust < 0) return -1;

    fat[cur] = new_clust;
    fat[new_clust] = FAT_ENTRY_END;
    return new_clust;
}

/* 在FAT表中找文件 */
struct FILEINFO *file_search(char *name, struct FILEINFO *finfo, int max)
{
    int i, j;
    char s[12];
    for (j = 0; j < 11; j++) s[j] = ' ';
    j = 0;
    for (i = 0; name[i] != 0; i++) {
        if (j >= 11) return 0;
        if (name[i] == '.' && j <= 8) {
            j = 8;
        } else {
            s[j] = name[i];
            if ('a' <= s[j] && s[j] <= 'z') s[j] -= 0x20;
            j++;
        }
    }
    for (i = 0; i < max; i++) {
        if (finfo[i].name[0] == 0x00) break;
        if ((finfo[i].type & 0x18) == 0) {
            for (j = 0; j < 11; j++) {
                if (finfo[i].name[j] != s[j]) goto next;
            }
            return finfo + i;
        }
next:
        continue;
    }
    return 0;
}

/* 从磁盘读取文件到内存buf */
void file_loadfile(int clustno, int size, char *buf, int *fat, char *img)
{
    int i;
    for (;;) {
        if (size <= CLUSTER_SIZE) {
            for (i = 0; i < size; i++)  buf[i] = img[clustno * CLUSTER_SIZE + i];
            break;
        }
        for (i = 0; i < CLUSTER_SIZE; i++) buf[i] = img[clustno * CLUSTER_SIZE + i];
        size -= CLUSTER_SIZE;
        buf += CLUSTER_SIZE;
        clustno = fat[clustno];
    }
    return;
}

/* 将buf写入磁盘，自动分配簇 */
int fat_writefile(struct FILEINFO *finfo, char *buf, int size, int *fat, unsigned char *img)
{
    int clustno = finfo->clustno;
    int written = 0;
    int remaining = size;

    /* 先算需要多少簇 */
    int need = (size + CLUSTER_SIZE - 1) / CLUSTER_SIZE;
    int have = 0;
    int c = clustno;
    while (c < FAT_ENTRY_END) { have++; c = fat[c]; }

    /* 不够就分配 */
    while (have < need) {
        if (fat_append_cluster(clustno, fat) < 0) break;
        have++;
    }

    /* 写入数据 */
    c = clustno;
    while (written < size && c < FAT_ENTRY_END) {
        int chunk = (remaining > CLUSTER_SIZE) ? CLUSTER_SIZE : remaining;
        int i;
        for (i = 0; i < chunk; i++) {
            img[c * CLUSTER_SIZE + i] = buf[written + i];
        }
        written += chunk;
        remaining -= chunk;
        if (remaining > 0) c = fat[c];
    }

    /* 更新文件大小 */
    finfo->size = written;
    return written;
}

/* 将普通文件名（含 '.'）转换为 FAT12 8.3 格式（11 字节，无 '\0'）*/
static void filename_to_fat12(const char *src, char *dst)
{
	int i, j;
	for (i = 0; i < 11; i++) dst[i] = ' ';
	for (i = 0; i < 8 && src[i] && src[i] != '.'; i++) {
		dst[i] = (src[i] >= 'a' && src[i] <= 'z') ? src[i] - 0x20 : src[i];
	}
	/* 跳过超过 8 个字符的主文件名字符 */
	while (src[i] && src[i] != '.') i++;
	if (src[i] == '.') i++;
	for (j = 0; j < 3 && src[i]; j++, i++) {
		dst[8 + j] = (src[i] >= 'a' && src[i] <= 'z') ? src[i] - 0x20 : src[i];
	}
}

/* 生成 edimg 风格的 FAT12 名：取 chars 0-7 为主文件名，chars 8-10 为扩展名
 * （用于匹配 edimg 处理超长文件名时的行为）*/
static void filename_to_fat12_edimg(const char *src, char *dst)
{
	int i, j;
	for (i = 0; i < 11; i++) dst[i] = ' ';
	for (i = 0; i < 8 && src[i]; i++) {
		dst[i] = (src[i] >= 'a' && src[i] <= 'z') ? src[i] - 0x20 : src[i];
	}
	for (j = 0; j < 3 && src[i + j]; j++) {
		dst[8 + j] = (src[i + j] >= 'a' && src[i + j] <= 'z')
				? src[i + j] - 0x20 : src[i + j];
	}
}

/* 从磁盘读取文件到内存 buf，返回文件大小，失败返回 -1 */
int file_load(const char *fname, unsigned char *buf)
{
	char fat12_name[11], fat12_name_alt[11];
	struct FILEINFO *root_dir = (struct FILEINFO *)(ADR_DISKIMG + 0x002600);
	struct FILEINFO *finfo;
	int *fat = g_fat;
	int i, j;

	filename_to_fat12(fname, fat12_name);
	finfo = file_search(fat12_name, root_dir, MAX_FAT12_FILES);

	/* 如果精确搜索失败，尝试 edimg 风格转换（处理超长文件名）*/
	if (finfo == 0) {
		filename_to_fat12_edimg(fname, fat12_name_alt);
		finfo = file_search(fat12_name_alt, root_dir, MAX_FAT12_FILES);
	}

	/* 如果还失败，遍历目录逐个比较（不区分大小写）*/
	if (finfo == 0) {
		for (i = 0; i < MAX_FAT12_FILES; i++) {
			if (root_dir[i].name[0] == 0x00) break;
			if (root_dir[i].name[0] == 0xe5) continue;
			if ((root_dir[i].type & 0x18) != 0) continue;
			/* 标准格式比较 */
			for (j = 0; j < 11; j++) {
				char c1 = root_dir[i].name[j], c2 = fat12_name[j];
				if ('a' <= c1 && c1 <= 'z') c1 -= 0x20;
				if ('a' <= c2 && c2 <= 'z') c2 -= 0x20;
				if (c1 != c2) break;
			}
			if (j == 11) { finfo = &root_dir[i]; break; }
			/* edimg 格式比较 */
			if (fat12_name_alt[0] != ' ') {
				for (j = 0; j < 11; j++) {
					char c1 = root_dir[i].name[j], c2 = fat12_name_alt[j];
					if ('a' <= c1 && c1 <= 'z') c1 -= 0x20;
					if ('a' <= c2 && c2 <= 'z') c2 -= 0x20;
					if (c1 != c2) break;
				}
				if (j == 11) { finfo = &root_dir[i]; break; }
			}
		}
	}
	if (finfo == 0) return -1;

	file_readfat(fat, ADR_DISKIMG);
	/* 数据区从扇区 33 (0x4200) 开始，cluster 2 是第一个数据簇
	 * 所以正确的数据基址 = ADR_DISKIMG + DATA_OFFSET - 2 * CLUSTER_SIZE */
	file_loadfile(finfo->clustno, finfo->size, buf, fat,
			(unsigned char *)(ADR_DISKIMG + DATA_OFFSET - 2 * CLUSTER_SIZE));
	return finfo->size;
}
