/* png.c - Minimal PNG decoder for 8-bit RGBA */
#include "bootpack.h"

/* CRC32 */
static unsigned int crc32_tab[256];
static int crc32_init = 0;

static unsigned int crc32(const unsigned char *buf, int len) {
	int i; unsigned int c = 0xffffffff;
	if (!crc32_init) {
		for (i = 0; i < 256; i++) { int j, k=i; for(j=0;j<8;j++) k=(k>>1)^(k&1?0xedb88320:0); crc32_tab[i]=k; }
		crc32_init = 1;
	}
	for (i = 0; i < len; i++) c = crc32_tab[(c ^ buf[i]) & 0xff] ^ (c >> 8);
	return c ^ 0xffffffff;
}

/* Bit reader */
struct br { const unsigned char *b; int p, bit, bits; };
static int rb(struct br *r) { if(r->bit<=0){r->bits=r->b[r->p++];r->bit=8;} r->bit--; return (r->bits>>r->bit)&1; }
static int rbs(struct br *r, int n) { int v=0,i; for(i=0;i<n;i++)v|=rb(r)<<i; return v; }
static void rba(struct br *r) { rbs(r,(8-r->bit)&7); }

/* Decode PNG to RGBA. Returns non-zero on success. */
int load_png(const unsigned char *png, int pngsz, unsigned char *out, int *pw, int *ph)
{
	int pos = 8, w, h, i, j, out_pos = 0;
	unsigned char in[16384], out_buf[65536];
	int in_pos = 0, out_len;

	/* Validate signature */
	if (pngsz < 8 || png[0]!=0x89||png[1]!=0x50||png[2]!=0x4E||png[3]!=0x47||
	    png[4]!=0x0D||png[5]!=0x0A||png[6]!=0x1A||png[7]!=0x0A) return 0;

	/* Chunk loop */
	while (pos + 12 <= pngsz) {
		unsigned int len = (png[pos]<<24)|(png[pos+1]<<16)|(png[pos+2]<<8)|png[pos+3];
		unsigned char type[5] = {png[pos+4],png[pos+5],png[pos+6],png[pos+7],0};
		if (pos + 12 + len > (unsigned int)pngsz) break;

		if (type[0]=='I'&&type[1]=='H'&&type[2]=='D'&&type[3]=='R') {
			w=(png[pos+8]<<24)|(png[pos+9]<<16)|(png[pos+10]<<8)|png[pos+11];
			h=(png[pos+12]<<24)|(png[pos+13]<<16)|(png[pos+14]<<8)|png[pos+15];
			if (png[pos+16]!=8 || png[pos+17]!=6 || png[pos+20]!=0) return 0;
			*pw = w; *ph = h;
		} else if (type[0]=='I'&&type[1]=='D'&&type[2]=='A'&&type[3]=='T') {
			for (i = 0; i < (int)len && in_pos < 16384; i++)
				in[in_pos++] = png[pos+8+i];
		} else if (type[0]=='I'&&type[1]=='E'&&type[2]=='N'&&type[3]=='D') {
			break;
		}
		pos += 12 + len;
	}

	/* Inflate (minimal fixed Huffman only) */
	{
		struct br r = {in, 2, 0, 0};
		int out_ofs = 0;
		static int lb[29]={3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258};
		static int le[29]={0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0};
		static int db[30]={1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577};
		static int de[30]={0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13};
		int done = 0, sym, idx, len, dist;
		while (!done) {
			if(rbs(&r,2)==0){rba(&r);len=r.b[r.p]|(r.b[r.p+1]<<8);r.p+=4;for(i=0;i<len&&out_ofs<65536;i++)out_buf[out_ofs++]=r.b[r.p++];continue;}
			while (1) {
				int bl = 0, vv = 0;
				while (bl < 15) {
					vv = (vv << 1) | rb(&r); bl++;
					if (bl == 7 && (vv&0x7F)>=0x30&&(vv&0x7F)<=0xBF) { sym = (vv&0x7F)-0x30+256; break; }
					if (bl == 8 && (vv&0xFF)<=0x8F) { sym = vv&0xFF; break; }
					if (bl == 8 && (vv&0xFF)>=0xC0&&(vv&0xFF)<=0xC7) { sym = (vv&0xFF)-0xC0+280; break; }
					if (bl == 9 && (vv&0x1FF)>=0x190) { sym = (vv&0x1FF)-0x190+144; break; }
				}
				if (sym < 256) { if (out_ofs>=65536) return 0; out_buf[out_ofs++] = sym; }
				else if (sym == 256) break;
				else { idx=sym-257; len=lb[idx]+rbs(&r,le[idx]); dist=db[rbs(&r,5)]+rbs(&r,de[rbs(&r,5)]); for(i=0;i<len&&out_ofs<65536;i++)out_buf[out_ofs]=out_buf[out_ofs-dist];out_ofs++; }
			}
			done = rbs(&r, 1);
		}
		out_len = out_ofs;
	}

	/* PNG filter reconstruction */
	{
		int stride = w * 4 + 1, x;
		for (i = 0; i < h; i++) {
			unsigned char *row = out_buf + i * stride;
			unsigned char *prev = i > 0 ? out_buf + (i-1) * stride : 0;
			int filter = row[0];
			for (x = 1; x < stride; x++) {
				int a = x>4 ? row[x-4] : 0;
				int b = prev ? prev[x] : 0;
				int c = (x>4 && prev) ? prev[x-4] : 0;
				switch (filter) {
					case 0: break; /* None */
					case 1: row[x] += a; break; /* Sub */
					case 2: row[x] += b; break; /* Up */
					case 3: row[x] += (a+b)/2; break; /* Average */
					case 4: { /* Paeth */
						int p = a + b - c;
						int pa = p > a ? p - a : a - p;
						int pb = p > b ? p - b : b - p;
						int pc = p > c ? p - c : c - p;
						row[x] += (pa <= pb && pa <= pc) ? a : (pb <= pc) ? b : c;
					} break;
				}
			}
		}
		/* Copy to output: RGBA -> raw 4-bit grayscale */
		for (i = 0; i < h; i++) {
			unsigned char *row = out_buf + i * stride + 1;
			for (j = 0; j < w; j++) {
				int r = row[j*4], g = row[j*4+1], b = row[j*4+2], a = row[j*4+3];
				if (a < 128) out[i*w+j] = 0;
				else out[i*w+j] = ((r+g+b)/3 < 200) ? 15 : 0;
			}
		}
	}
	return 1;
}
