/* startmenuandbtn.c - 开始菜单和按钮实现 */

#include "bootpack.h"
#include <string.h>

/* 全局缓冲区指针（供 refresh_startmenu 使用） */
static unsigned char *g_buf_startmenu = 0;
static int g_menu_w = 360;
static int g_menu_h = 400;

/* 开始按钮全局变量 */
struct SHEET *g_sht_btn = 0;
static unsigned char *g_buf_btn = 0;
static unsigned char g_btn_title[8] = {0}; /* 按钮文字 */

/* 菜单项枚举 */
/* 使用 bootpack.h 中的定义 */
/* MENU_HOVER_NONE=0, COMP=1, DOCS=2, SEARCH=3, TASKMGR=4, CONSOLE=5, SHUTDOWN=6, RESTART=7 */

/* 计算混合字符串的像素宽度（ASCII=8px, 汉字=16px） */
static int str_width_hz(unsigned char *str)
{
    int width = 0;
    int i = 0;
    while (str[i] != '\0') {
        if (str[i] >= 0x80 && str[i + 1] != '\0' &&
            is_gb2312(str[i], str[i + 1])) {
            width += 16;
            i += 2;
        } else {
            width += 8;
            i += 1;
        }
    }
    return width;
}

/* 绘制按钮（支持中英文混排） */
void make_btn8(unsigned char *buf, int xsize, int ysize, unsigned char *title, int pressed)
{
	boxfill8(buf, xsize, pressed ? COL8_848484 : COL8_000000, 0, 0, xsize - 1, ysize - 1);
	{
		int tw = str_width_hz(title);
		int tx = (xsize - tw) / 2, ty = (ysize - 16) / 2 + 1;
		putfonts8_asc_hz(buf, xsize, tx, ty, COL8_FFFFFF, title);
	}
}
/* 绘制开始菜单（支持 hover_item 高亮） */
void make_startmenu8(unsigned char *buf, int xsize, int ysize, int hover_item)
{
	#ifndef txt_xpos
	#define txt_xpos 40
	#endif
	int mid = 180;
	boxfill8(buf, xsize, COL8_000000, 0, 0, xsize - 1, ysize - 1);
	boxfill8(buf, xsize, COL8_000000, 0, 0, mid - 1, ysize - 1);
	boxfill8(buf, xsize, COL8_000000, mid, 0, xsize - 1, ysize - 1);
	putfonts8_asc_hz(buf, xsize, txt_xpos, 12, COL8_FFFFFF, "此电脑");
	putfonts8_asc_hz(buf, xsize, txt_xpos, 42, COL8_FFFFFF, "文档");
	putfonts8_asc_hz(buf, xsize, txt_xpos, 72, COL8_FFFFFF, "搜索");
	putfonts8_asc_hz(buf, xsize, txt_xpos, 102, COL8_FFFFFF, "任务管理器");
	putfonts8_asc_hz(buf, xsize, txt_xpos, 132, COL8_FFFFFF, "控制台");
	boxfill8(buf, xsize, COL8_FFFFFF, 6, ysize - 80, 44, ysize - 50);
	boxfill8(buf, xsize, COL8_FFFFFF, 10, ysize - 38, 38, ysize - 14);
	putfonts8_asc_hz(buf, xsize, mid + 8, 12, COL8_000000, "浏览");
	boxfill8(buf, xsize, COL8_000084, mid + 8, 30, mid + 78, 102);
	putfonts8_asc(buf, xsize, mid + 14, 70, COL8_FFFFFF, "Cmd");
	boxfill8(buf, xsize, COL8_008400, mid + 88, 30, mid + 158, 102);
	putfonts8_asc(buf, xsize, mid + 94, 70, COL8_FFFFFF, "Exp");
	boxfill8(buf, xsize, COL8_840000, mid + 8, 116, mid + 78, 188);
	putfonts8_asc(buf, xsize, mid + 14, 156, COL8_FFFFFF, "Task");
	boxfill8(buf, xsize, COL8_000084, mid + 88, 116, mid + 158, 188);
	putfonts8_asc(buf, xsize, mid + 90, 156, COL8_FFFFFF, "Off");
}
/* 刷新开始菜单（根据 hover_item 重绘） */
void refresh_startmenu(int hover_item)
{
    if (g_buf_startmenu == 0 || g_sht_startmenu == 0) return;
    make_startmenu8(g_buf_startmenu, g_menu_w, g_menu_h, hover_item);
    sheet_refresh(g_sht_startmenu, 0, 0, g_menu_w, g_menu_h);
}

/* 更新开始按钮状态（按下/弹起） */
void update_btn_state(int pressed)
{
    if (g_buf_btn == 0 || g_sht_btn == 0) return;
    make_btn8(g_buf_btn, 40, 40, g_btn_title, pressed);
    sheet_refresh(g_sht_btn, 0, 0, 40, 40);
}

void init_startmenu(void)
{
    /* 开始按钮 */
    g_sht_btn = sheet_alloc(g_shtctl);
    g_buf_btn = (unsigned char *)memman_alloc_4k(g_memman, 40 * 40);
    sheet_setbuf(g_sht_btn, g_buf_btn, 40, 40, -1);
    /* "开始" */
    unsigned char btn_title[] = "s";
    memcpy(g_btn_title, btn_title, sizeof(btn_title));
    make_btn8(g_buf_btn, 40, 40, g_btn_title, 0);
    sheet_slide(g_sht_btn, 0, g_binfo->scrny - 40);
    sheet_updown(g_sht_btn, 2);

    /* 开始菜单 */
    g_sht_startmenu = sheet_alloc(g_shtctl);
    g_buf_startmenu = (unsigned char *)memman_alloc_4k(g_memman, g_menu_w * g_menu_h);
    sheet_setbuf(g_sht_startmenu, g_buf_startmenu, g_menu_w, g_menu_h, -1);
    make_startmenu8(g_buf_startmenu, g_menu_w, g_menu_h, MENU_HOVER_NONE);
    sheet_slide(g_sht_startmenu, 0, g_binfo->scrny - 440);
    sheet_updown(g_sht_startmenu, -1); /* 默认隐藏 */
}
