/* console.c - 从《30天自制操作系统》第30天移植，适配 WinDOS */
/* 核心功能：通过独立任务（TSS切换）启动 .hrb/.wda 应用 */

#include "bootpack.h"
#include <stdio.h>
#include <string.h>

void console_task(struct SHEET *sheet, int memtotal)
{
	struct TASK *task = task_now();
	struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
	int i, *fat = (int *) memman_alloc_4k(memman, 4 * 2880);
	struct FILEHANDLE fhandle[8];
	struct CONSOLE cons;
	char cmdline[30];

	/* 调试：直接在 VRAM 左上角画黄点确认任务运行 */
	if (g_binfo != 0) {
		g_binfo->vram[200] = COL8_FFFF00; /* 坐标 (200, 0) */
	}

	cons.sht = sheet;
	cons.cur_x =  8;
	cons.cur_y = 28;
	cons.cur_c = COL8_FFFFFF;  /* 光标初始显示 */
	task->cons = &cons;
	task->cmdline = cmdline;

	if (cons.sht != 0) {
		cons.timer = timer_alloc();
		timer_init(cons.timer, &task->fifo, 1);
		timer_settime(cons.timer, 50);
	}
	file_readfat(fat, (unsigned char *) (ADR_DISKIMG + 0x000200));
	for (i = 0; i < 8; i++) {
		fhandle[i].buf = 0; /* 未使用标记 */
	}
	task->fhandle = fhandle;
	task->fat = fat;
	task->langmode = 0;
	task->langbyte1 = 0;

	/* 显示提示符 */
	cons_putchar(&cons, '>', 1);

	for (;;) {
		io_cli();
		if (fifo32_status(&task->fifo) == 0) {
			task_sleep(task);
			io_sti();
		} else {
			i = fifo32_get(&task->fifo);
			io_sti();
			/* 光标闪烁定时器 */
			if (i <= 1 && cons.sht != 0) {
				if (i != 0) {
					timer_init(cons.timer, &task->fifo, 0);
					if (cons.cur_c >= 0) cons.cur_c = COL8_FFFFFF;
				} else {
					timer_init(cons.timer, &task->fifo, 1);
					if (cons.cur_c >= 0) cons.cur_c = COL8_000000;
				}
				timer_settime(cons.timer, 50);
			}
			if (i == 4) { /* 点击关闭按钮 */
				cmd_exit(&cons, fat);
			}
			if (256 <= i && i <= 511) { /* 键盘数据 */
				if (i == 8 + 256) {
					/* 退格键：允许删除第一个字符（cur_x >= 16）*/
					if (cons.cur_x >= 16) {
						if (cons.sht != 0) {
							/* 擦除光标 */
							boxfill8(cons.sht->buf, cons.sht->bxsize, COL8_000000,
								cons.cur_x, cons.cur_y, cons.cur_x + 1, cons.cur_y + 15);
							/* 擦除前一个字符（光标左边 8px 处）*/
							boxfill8(cons.sht->buf, cons.sht->bxsize, COL8_000000,
								cons.cur_x - 8, cons.cur_y, cons.cur_x - 1, cons.cur_y + 15);
							sheet_refresh(cons.sht, cons.cur_x - 8, cons.cur_y,
								cons.cur_x + 2, cons.cur_y + 16);
						}
						cons.cur_x -= 8;
						if (cons.cur_x < 16) cons.cur_x = 16;
					}
				} else if (i == 10 + 256) {
					/* 回车键 */
					if (cons.sht != 0) {
						boxfill8(cons.sht->buf, cons.sht->bxsize, COL8_000000,
							cons.cur_x, cons.cur_y, cons.cur_x + 1, cons.cur_y + 15);
					}
					cons_putchar(&cons, ' ', 0);
					cmdline[(cons.cur_x - 16) / 8] = 0;
					cons_newline(&cons);
					cons_runcmd(cmdline, &cons, fat, memtotal);
					if (cons.sht == 0) {
						cmd_exit(&cons, fat);
					}
					/* 显示提示符 */
					cons_putchar(&cons, '>', 1);
				} else {
					/* 一般字符 */
					if (cons.cur_x < 240) {
						/* 擦除旧光标 */
						if (cons.sht != 0) {
							boxfill8(cons.sht->buf, cons.sht->bxsize, COL8_000000,
								cons.cur_x, cons.cur_y, cons.cur_x + 1, cons.cur_y + 15);
						}
						cmdline[(cons.cur_x - 16) / 8] = i - 256;
						cons_putchar(&cons, i - 256, 1);
					}
				}
			}
			/* 绘制 2px 宽闪烁光标 */
			if (cons.sht != 0 && cons.cur_c >= 0) {
				boxfill8(cons.sht->buf, cons.sht->bxsize, cons.cur_c,
					cons.cur_x, cons.cur_y, cons.cur_x + 1, cons.cur_y + 15);
				sheet_refresh(cons.sht, cons.cur_x, cons.cur_y, cons.cur_x + 2, cons.cur_y + 16);
			}
		}
	}
}

void cons_putchar(struct CONSOLE *cons, int chr, char move)
{
	char s[2];
	s[0] = chr;
	s[1] = 0;
	if (s[0] == 0x09) { /* 制表符 */
		for (;;) {
			if (cons->sht != 0) {
				boxfill8(cons->sht->buf, cons->sht->bxsize, COL8_000000,
					cons->cur_x, cons->cur_y, cons->cur_x + 7, cons->cur_y + 15);
				putfonts8_asc(cons->sht->buf, cons->sht->bxsize,
					cons->cur_x, cons->cur_y, COL8_FFFFFF, " ");
				sheet_refresh(cons->sht, cons->cur_x, cons->cur_y,
					cons->cur_x + 8, cons->cur_y + 16);
			}
			cons->cur_x += 8;
			if (cons->cur_x == 8 + 240) {
				cons_newline(cons);
			}
			if (((cons->cur_x - 8) & 0x1f) == 0) {
				break;
			}
		}
	} else if (s[0] == 0x0a) { /* 换行 */
		cons_newline(cons);
	} else if (s[0] == 0x0d) { /* 回车 */
	} else { /* 一般字符 */
		if (cons->sht != 0) {
			boxfill8(cons->sht->buf, cons->sht->bxsize, COL8_000000,
				cons->cur_x, cons->cur_y, cons->cur_x + 7, cons->cur_y + 15);
			putfonts8_asc(cons->sht->buf, cons->sht->bxsize,
				cons->cur_x, cons->cur_y, COL8_FFFFFF, s);
			sheet_refresh(cons->sht, cons->cur_x, cons->cur_y,
				cons->cur_x + 8, cons->cur_y + 16);
		}
		if (move != 0) {
			cons->cur_x += 8;
			if (cons->cur_x == 8 + 240) {
				cons_newline(cons);
			}
		}
	}
	return;
}

void cons_newline(struct CONSOLE *cons)
{
	int x, y;
	struct SHEET *sheet = cons->sht;
	if (cons->cur_y < 28 + 112) {
		cons->cur_y += 16;
	} else {
		/* 滚动 */
		if (sheet != 0) {
			for (y = 28; y < 28 + 112; y++) {
				for (x = 8; x < 8 + 240; x++) {
					sheet->buf[x + y * sheet->bxsize] = sheet->buf[x + (y + 16) * sheet->bxsize];
				}
			}
			for (y = 28 + 112; y < 28 + 128; y++) {
				for (x = 8; x < 8 + 240; x++) {
					sheet->buf[x + y * sheet->bxsize] = COL8_000000;
				}
			}
			sheet_refresh(sheet, 8, 28, 8 + 240, 28 + 128);
		}
	}
	cons->cur_x = 8;
	return;
}

void cons_putstr0(struct CONSOLE *cons, char *s)
{
	for (; *s != 0; s++) {
		unsigned char c = *s;
		/* GB2312 双字节：首字节 0xA1-0xF7，第二字节 0xA0-0xFE */
		if (c >= 0xA1 && c <= 0xF7 && s[1] != 0 && (unsigned char)s[1] >= 0xA0) {
			unsigned char hz[3];
			hz[0] = c;
			hz[1] = s[1];
			hz[2] = 0;
			if (cons->sht != 0) {
				boxfill8(cons->sht->buf, cons->sht->bxsize, COL8_000000,
					cons->cur_x, cons->cur_y, cons->cur_x + 15, cons->cur_y + 15);
				putfonts8_asc_hz(cons->sht->buf, cons->sht->bxsize,
					cons->cur_x, cons->cur_y, COL8_FFFFFF, hz);
				sheet_refresh(cons->sht, cons->cur_x, cons->cur_y,
					cons->cur_x + 16, cons->cur_y + 16);
			}
			cons->cur_x += 16;
			if (cons->cur_x >= 8 + 240 - 7) cons_newline(cons);
			s++;
		} else {
			cons_putchar(cons, c, 1);
		}
	}
	return;
}

void cons_putstr1(struct CONSOLE *cons, char *s, int l)
{
	int i;
	for (i = 0; i < l; i++) {
		cons_putchar(cons, s[i], 1);
	}
	return;
}

void cons_runcmd(char *cmdline, struct CONSOLE *cons, int *fat, int memtotal)
{
	if (strcmp(cmdline, "mem") == 0 && cons->sht != 0) {
		/* cmd_mem - 中文输出：总共 / 可用 */
		struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
		char s[60];
		sprintf(s, "总共   %dMB\n可用 %dKB\n\n",
			memtotal / (1024 * 1024), memman_total(memman) / 1024);
		cons_putstr0(cons, s);
	} else if (strcmp(cmdline, "cls") == 0 && cons->sht != 0) {
		/* cmd_cls */
		int x, y;
		struct SHEET *sheet = cons->sht;
		for (y = 28; y < 28 + 128; y++) {
			for (x = 8; x < 8 + 240; x++) {
				sheet->buf[x + y * sheet->bxsize] = COL8_000000;
			}
		}
		sheet_refresh(sheet, 8, 28, 8 + 240, 28 + 128);
		cons->cur_y = 28;
	} else if ((strcmp(cmdline, "dir") == 0 || strcmp(cmdline, "ls") == 0) && cons->sht != 0) {
		/* cmd_dir */
		struct FILEINFO *finfo = (struct FILEINFO *) (ADR_DISKIMG + 0x002600);
		int i, j;
		char s[30];
		for (i = 0; i < 224; i++) {
			if (finfo[i].name[0] == 0x00) break;
			if (finfo[i].name[0] != 0xe5) {
				if ((finfo[i].type & 0x18) == 0) {
					sprintf(s, "filename.ext   %7d\n", finfo[i].size);
					for (j = 0; j < 8; j++) s[j] = finfo[i].name[j];
					s[ 9] = finfo[i].ext[0];
					s[10] = finfo[i].ext[1];
					s[11] = finfo[i].ext[2];
					cons_putstr0(cons, s);
				}
			}
		}
		cons_newline(cons);
	} else if (strcmp(cmdline, "exit") == 0) {
		cmd_exit(cons, fat);
	} else if (strncmp(cmdline, "start ", 6) == 0) {
		/* cmd_start - 在新控制台里运行 */
		struct SHTCTL *shtctl = (struct SHTCTL *) *((int *) 0x0fe4);
		struct SHEET *sht = open_console(shtctl, memtotal);
		struct FIFO32 *fifo = &sht->task->fifo;
		int si;
		sheet_slide(sht, 32, 4);
		sheet_updown(sht, shtctl->top);
		for (si = 6; cmdline[si] != 0; si++) {
			fifo32_put(fifo, cmdline[si] + 256);
		}
		fifo32_put(fifo, 10 + 256); /* 回车 */
		cons_newline(cons);
	} else if (cmdline[0] != 0) {
			/* 命令无法识别 */
			if (cmd_app(cons, fat, cmdline) == 0) {
				cons_putstr0(cons, "无效命令：\"");
				cons_putstr0(cons, cmdline);
				cons_putstr0(cons, "\"\n\n");
			}
	}
	return;
}

int cmd_app(struct CONSOLE *cons, int *fat, char *cmdline)
{
	struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
	struct FILEINFO *finfo;
	char name[18], *p, *q;
	struct TASK *task = task_now();
	int i, segsiz, datsiz, esp, dathrb, appsiz;
	struct SHTCTL *shtctl;
	struct SHEET *sht;

	/* 根据命令行生成文件名 */
	for (i = 0; i < 13; i++) {
		if (cmdline[i] <= ' ') break;
		name[i] = cmdline[i];
	}
	name[i] = 0;

	/* 寻找文件 */
	finfo = file_search(name, (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
	if (finfo == 0 && name[i - 1] != '.') {
		name[i    ] = '.';
		name[i + 1] = 'H';
		name[i + 2] = 'R';
		name[i + 3] = 'B';
		name[i + 4] = 0;
		finfo = file_search(name, (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
	}
	if (finfo == 0 && name[i - 1] != '.') {
		name[i    ] = '.';
		name[i + 1] = 'W';
		name[i + 2] = 'D';
		name[i + 3] = 'A';
		name[i + 4] = 0;
		finfo = file_search(name, (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
	}

	if (finfo != 0) {
		appsiz = finfo->size;
		/* 用簇号直接加载（不用文件名，避免 name 无终止符问题）*/
		p = (char *) memman_alloc_4k(memman, appsiz);
		if (p == 0) { cons_putstr0(cons, "mem alloc error.\n"); return 1; }
		file_loadfile(finfo->clustno, finfo->size, p, fat,
			(unsigned char *)(ADR_DISKIMG + DATA_OFFSET - 2 * CLUSTER_SIZE));

		if (appsiz >= 36 && strncmp(p + 4, "Hari", 4) == 0 && *p == 0x00) {
			segsiz = *((int *) (p + 0x0000));
			esp    = *((int *) (p + 0x000c));
			datsiz = *((int *) (p + 0x0010));
			dathrb = *((int *) (p + 0x0014));
			q = (char *) memman_alloc_4k(memman, segsiz);
			if (q == 0) { memman_free_4k(memman, (int)p, appsiz); return 1; }
			task->ds_base = (int) q;
			set_segmdesc(task->ldt + 0, finfo->size - 1, (int) p, AR_CODE32_ER + 0x60);
			set_segmdesc(task->ldt + 1, segsiz - 1, (int) q, AR_DATA32_RW + 0x60);
			for (i = 0; i < datsiz; i++) {
				q[esp + i] = p[dathrb + i];
			}
			task->heap_top = esp + datsiz; /* 堆从数据段尾部开始 */
			start_app(0x1b, 0 * 8 + 4, esp, 1 * 8 + 4, &(task->tss.esp0));
			shtctl = (struct SHTCTL *) *((int *) 0x0fe4);
			for (i = 0; i < MAX_SHEETS; i++) {
				sht = &(shtctl->sheets0[i]);
				if ((sht->flags & 0x11) == 0x11 && sht->task == task) {
					sheet_free(sht);
				}
			}
			for (i = 0; i < 8; i++) {
				if (task->fhandle[i].buf != 0) {
					memman_free_4k(memman, (int) task->fhandle[i].buf, task->fhandle[i].size);
					task->fhandle[i].buf = 0;
				}
			}
			timer_cancelall(&task->fifo);
			memman_free_4k(memman, (int) q, segsiz);
			task->langbyte1 = 0;
		} else {
			cons_putstr0(cons, ".hrb file format error.\n");
		}
		memman_free_4k(memman, (int) p, appsiz);
		cons_newline(cons);
		return 1;
	}
	return 0;
}

void cmd_exit(struct CONSOLE *cons, int *fat)
{
	struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
	struct TASK *task = task_now();
	struct SHTCTL *shtctl = (struct SHTCTL *) *((int *) 0x0fe4);
	struct FIFO32 *fifo = (struct FIFO32 *) *((int *) 0x0fec);
	if (cons->sht != 0) {
		timer_cancel(cons->timer);
	}
	memman_free_4k(memman, (int) fat, 4 * 2880);
	io_cli();
	if (cons->sht != 0) {
		fifo32_put(fifo, cons->sht - shtctl->sheets0 + 768); /* 768〜1023 */
	} else {
		fifo32_put(fifo, task - taskctl->tasks0 + 1024); /* 1024〜2023 */
	}
	io_sti();
	for (;;) {
		task_sleep(task);
	}
}
