/* explorer.c - WinDOS 文件浏览器应用 */
#include "bootpack.h"
#include <stdio.h>
#include <string.h>

/* 窗口布局常量 */
#define TITLE_BAR_H    21    /* 标题栏高度 */
#define PATH_BAR_Y      24    /* 路径栏 y 坐标 */
#define FILE_LIST_Y     42    /* 文件列表起始 y */
#define SCROLLBAR_W     14    /* 滚动条宽度 */
#define BORDER          2     /* 3D 边框厚度 */
#define LINE_HEIGHT     16    /* 每行文件高度 */

/* 文件浏览器窗口全局变量 */
struct SHEET *g_sht_explorer = 0;
unsigned char *g_buf_explorer = 0;
int g_explorer_opened = 0;

static int g_explorer_buf_size = 0;
static int g_explorer_w = 0;
static int g_explorer_h = 0;

/* 滚动状态 */
static int g_scroll_offset = 0;   /* 滚动偏移（文件行数） */
static int g_total_files = 0;
static int g_visible_lines = 0;

/* 选中状态 */
static int g_selected_idx = -1;   /* 选中的文件索引（-1=无选中） */

/* FAT 表（写盘用） */
static unsigned char *g_img = 0;

/* 创建新文件（NEW1.TXT → NEW99.TXT） */
static void make_new_filename(char *buf)
{
    int i;
    for (i = 1; i <= 99; i++) {
        struct FILEINFO *finfo = (struct FILEINFO *) (ADR_DISKIMG + 0x002600);
        sprintf(buf, "NEW%d   TXT", i);
        buf[11] = 0;
        /* 检查是否已存在 */
        if (file_search(buf, finfo, MAX_FAT12_FILES) == 0) {
            /* 转成 8.3 格式 */
            buf[3] = ' ';
            buf[4] = ' ';
            buf[5] = ' ';
            buf[6] = ' ';
            buf[7] = ' ';
            return;
        }
    }
    sprintf(buf, "NEW99  TXT");
    buf[11] = 0;
}

/* 生成新目录名（DIR1 → DIR99） */
static void make_new_dirname(char *buf)
{
    int i;
    for (i = 1; i <= 99; i++) {
        struct FILEINFO *finfo = (struct FILEINFO *) (ADR_DISKIMG + 0x002600);
        int len;
        sprintf(buf, "DIR%d", i);
        for (len = 0; buf[len] != 0; len++) {}
        while (len < 11) buf[len++] = ' ';
        buf[11] = 0;
        if (file_search(buf, finfo, MAX_FAT12_FILES) == 0) {
            return;
        }
    }
    sprintf(buf, "DIR99      ");
    buf[11] = 0;
}

void explorer_new_file(void)
{
    char name[12];
    unsigned char *img = (unsigned char *) ADR_DISKIMG;

    /* 确保 FAT 已加载 */
    if (g_fat == 0) {
        g_fat = (int *) memman_alloc_4k(g_memman, 4 * 2880);
        if (g_fat == 0) return;
        file_readfat(g_fat, img);
    }

    make_new_filename(name);
    if (fat_create(name, 0, g_fat, img) >= 0) {
        file_writefat(g_fat, img);
        g_scroll_offset = 0;
        redraw_explorer();
    }
}

/* 创建新目录（DIR1 → DIR99） */
void explorer_new_dir(void)
{
    char name[12];
    unsigned char *img = (unsigned char *) ADR_DISKIMG;
    struct FILEINFO *finfo;
    int entry, clust, j;

    if (g_fat == 0) {
        g_fat = (int *) memman_alloc_4k(g_memman, 4 * 2880);
        if (g_fat == 0) return;
        file_readfat(g_fat, img);
    }

    make_new_dirname(name);

    finfo = (struct FILEINFO *) (img + 0x002600);
    entry = fat_find_free_entry(img);
    if (entry < 0) return;

    clust = fat_find_free(g_fat);
    if (clust < 0) return;
    g_fat[clust] = 0xFF8;

    for (j = 0; j < 11; j++) finfo[entry].name[j] = name[j];
    finfo[entry].type    = 0x10;  /* 目录属性 */
    finfo[entry].clustno = clust;
    finfo[entry].size    = 0;
    for (j = 0; j < 10; j++) finfo[entry].reserve[j] = 0;
    finfo[entry].time = 0;
    finfo[entry].date = 0;

    file_writefat(g_fat, img);
    g_scroll_offset = 0;
    redraw_explorer();
}

/* 统计 FAT12 目录中的文件数 */
static int count_files(void)
{
    struct FILEINFO *finfo = (struct FILEINFO *) (ADR_DISKIMG + 0x002600);
    int count = 0, i;
    for (i = 0; i < MAX_FAT12_FILES; i++) {
        if (finfo[i].name[0] == 0x00) break;
        if (finfo[i].name[0] == 0xe5) continue;
        if ((finfo[i].type & 0x18) != 0) continue;
        count++;
    }
    return count;
}

/* 绘制文件浏览器内容（含滚动条） */
static void draw_explorer_content(unsigned char *buf, int xsize, int ysize)
{
    struct FILEINFO *finfo = (struct FILEINFO *) (ADR_DISKIMG + 0x002600);
    int i, y, file_idx;
    int content_right;
    int sb_left, sb_right, sb_top, sb_bottom;
    int sb_height, thumb_h, thumb_y;
    int need_scrollbar;

    g_total_files = count_files();

    /* 内容区域右边界（不含滚动条） */
    content_right = xsize - 1 - BORDER - SCROLLBAR_W;

    /* 白色背景（不覆盖 3D 边框） */
    boxfill8(buf, xsize, COL8_FFFFFF, BORDER, TITLE_BAR_H,
             content_right, ysize - 1 - BORDER);

	/* 显示当前路径 */
	putfonts8_asc(buf, xsize, 6, PATH_BAR_Y, COL8_000000, "A:\\");

    /* 计算可见行数 */
    {
        int content_height = ysize - 1 - BORDER - FILE_LIST_Y;
        if (content_height < 0) content_height = 0;
        g_visible_lines = content_height / LINE_HEIGHT;
    }

    /* 遍历 FAT12 目录项，跳过滚动偏移之前的文件 */
    file_idx = 0;
    y = FILE_LIST_Y;
    for (i = 0; i < MAX_FAT12_FILES; i++) {
        char s[30];
        int j;

        if (finfo[i].name[0] == 0x00) break;
        if (finfo[i].name[0] == 0xe5) continue;
        if ((finfo[i].type & 0x18) != 0) continue;

        /* 跳过滚动偏移之前的文件 */
        if (file_idx < g_scroll_offset) {
            file_idx++;
            continue;
        }

        /* 超出可见区域则停止绘制 */
        if (y + LINE_HEIGHT > ysize - 1 - BORDER) break;

        /* 组装文件名：去尾随空格，15字符固定宽度 + 右对齐大小 */
        {
            int p, ni;
            char name_part[16];
            /* 先复制完整 8.3 名到 name_part */
            for (p = 0; p < 8; p++) name_part[p] = finfo[i].name[p];
            /* 去掉 name 尾随空格 */
            while (p > 0 && name_part[p-1] == ' ') p--;
            /* 加 '.' + 扩展名（去空格） */
            if (finfo[i].ext[0] != ' ') {
                name_part[p++] = '.';
                name_part[p++] = finfo[i].ext[0];
                if (finfo[i].ext[1] != ' ') {
                    name_part[p++] = finfo[i].ext[1];
                    if (finfo[i].ext[2] != ' ') {
                        name_part[p++] = finfo[i].ext[2];
                    }
                }
            }
            /* 补齐到 15 字符 */
            while (p < 15) name_part[p++] = ' ';
            name_part[15] = '\0';
            /* 复制到 s：15 字符文件名 + 7 字符右对齐大小 */
            for (ni = 0; ni < 15; ni++) s[ni] = name_part[ni];
            sprintf(s + 15, "%7d", finfo[i].size);
            s[22] = '\0';
        }

        /* 选中高亮 */
        if (file_idx == g_selected_idx) {
            boxfill8(buf, xsize, COL8_000084, BORDER, y, xsize - BORDER - 1, y + LINE_HEIGHT - 1);
            putfonts8_asc(buf, xsize, 6, y, COL8_FFFFFF, s);
        } else {
            putfonts8_asc(buf, xsize, 6, y, COL8_000000, s);
        }
        y += LINE_HEIGHT;
        file_idx++;
    }

    /* 显示文件总数 */
    {
        char count_str[30];
        sprintf(count_str, "%d file(s)", g_total_files);
        if (y + LINE_HEIGHT <= ysize - 1 - BORDER) {
            putfonts8_asc(buf, xsize, 6, y, COL8_848484, count_str);
        }
    }

    /* ---- 绘制滚动条 ---- */
    sb_left = content_right + 1;
    sb_right = xsize - 1 - BORDER;
    sb_top = TITLE_BAR_H;
    sb_bottom = ysize - 1 - BORDER;
    sb_height = sb_bottom - sb_top;
    need_scrollbar = (g_total_files > g_visible_lines && g_visible_lines > 0);

    if (need_scrollbar) {
        /* 计算滑块高度和位置 */
        thumb_h = (g_visible_lines * sb_height) / g_total_files;
        if (thumb_h < LINE_HEIGHT) thumb_h = LINE_HEIGHT;
        if (thumb_h > sb_height) thumb_h = sb_height;

        if (g_total_files - g_visible_lines > 0) {
            thumb_y = sb_top + (g_scroll_offset * (sb_height - thumb_h))
                      / (g_total_files - g_visible_lines);
        } else {
            thumb_y = sb_top;
        }

        /* 滚动条轨道背景 */
        boxfill8(buf, xsize, COL8_C6C6C6, sb_left, sb_top, sb_right, sb_bottom);

        /* 上下箭头区域（深灰色块） */
        boxfill8(buf, xsize, COL8_848484, sb_left, sb_top, sb_right, sb_top + LINE_HEIGHT - 1);
        boxfill8(buf, xsize, COL8_848484, sb_left, sb_bottom - LINE_HEIGHT + 1, sb_right, sb_bottom);

        /* 上箭头（三角形） */
        {
            int cx = (sb_left + sb_right) / 2;
            int cy = sb_top + LINE_HEIGHT / 2;
            int r;
            for (r = 0; r < 4; r++) {
                buf[(cy + r) * xsize + (cx - r)] = COL8_FFFFFF;
                buf[(cy + r) * xsize + (cx + r)] = COL8_FFFFFF;
            }
        }
        /* 下箭头（倒三角） */
        {
            int cx = (sb_left + sb_right) / 2;
            int cy = sb_bottom - LINE_HEIGHT / 2;
            int r;
            for (r = 0; r < 4; r++) {
                buf[(cy - r) * xsize + (cx - r)] = COL8_FFFFFF;
                buf[(cy - r) * xsize + (cx + r)] = COL8_FFFFFF;
            }
        }

        /* 滑块（3D 效果） */
        boxfill8(buf, xsize, COL8_C6C6C6,
                 sb_left + 1, thumb_y, sb_right - 1, thumb_y + thumb_h - 1);
        /* 高光（左上） */
        boxfill8(buf, xsize, COL8_FFFFFF,
                 sb_left + 2, thumb_y + 1, sb_right - 2, thumb_y + 1);
        boxfill8(buf, xsize, COL8_FFFFFF,
                 sb_left + 1, thumb_y + 1, sb_left + 1, thumb_y + thumb_h - 2);
        /* 阴影（右下） */
        boxfill8(buf, xsize, COL8_848484,
                 sb_left + 2, thumb_y + thumb_h - 2, sb_right - 2, thumb_y + thumb_h - 2);
        boxfill8(buf, xsize, COL8_848484,
                 sb_right - 2, thumb_y + 1, sb_right - 2, thumb_y + thumb_h - 2);
    } else {
        /* 没有滚动条时，右侧填白色 */
        boxfill8(buf, xsize, COL8_FFFFFF,
                 content_right + 1, TITLE_BAR_H,
                 xsize - 1 - BORDER, ysize - 1 - BORDER);
    }
}

/* 重绘整个文件管理器窗口（标题栏 + 内容） */
static void redraw_explorer(void)
{
    if (!g_buf_explorer || !g_sht_explorer) return;
    make_window8(g_buf_explorer, g_explorer_w, g_explorer_h, "文件管理器", 1);
    { int _i; char *_t = "文件管理器"; for (_i = 0; _t[_i]; _i++) g_sht_explorer->title[_i] = _t[_i]; g_sht_explorer->title[_i] = 0; }
    draw_explorer_content(g_buf_explorer, g_explorer_w, g_explorer_h);
    sheet_refresh(g_sht_explorer, 0, 0, g_explorer_w, g_explorer_h);
}

/* 打开文件浏览器 */
void explorer_open(void)
{
    int scrnx, scrny, pos_x, pos_y;

    scrnx = g_binfo->scrnx;
    scrny = g_binfo->scrny;

    /* 根据分辨率调整窗口大小 */
    if (scrnx <= 320) {
        g_explorer_w = 240;
        g_explorer_h = 150;
    } else if (scrnx <= 640) {
        g_explorer_w = 350;
        g_explorer_h = 220;
    } else {
        g_explorer_w = 500;
        g_explorer_h = 350;
    }

    /* 居中放置 */
    pos_x = (scrnx - g_explorer_w) / 2;
    pos_y = (scrny - g_explorer_h) / 2;
    if (pos_x < 2) pos_x = 2;
    if (pos_y < 2) pos_y = 2;

    g_explorer_buf_size = g_explorer_w * g_explorer_h;
    g_sht_explorer = sheet_alloc(g_shtctl);
    g_buf_explorer = (unsigned char *)memman_alloc_4k(g_memman, g_explorer_buf_size);
    if (g_buf_explorer == 0) return;

    sheet_setbuf(g_sht_explorer, g_buf_explorer, g_explorer_w, g_explorer_h, 0xFF);

    /* 重置状态 */
    g_scroll_offset = 0;

    /* 绘制并显示 */
    redraw_explorer();
    sheet_slide(g_sht_explorer, pos_x, pos_y);
    sheet_updown(g_sht_explorer, 3);
    g_explorer_opened = 1;
}

/* 关闭文件浏览器 */
void explorer_close(void)
{
    if (g_sht_explorer && g_explorer_opened) {
        sheet_free(g_sht_explorer);
        if (g_buf_explorer && g_explorer_buf_size > 0) {
            memman_free_4k(g_memman, (unsigned int)g_buf_explorer, g_explorer_buf_size);
        }
        g_sht_explorer = 0;
        g_buf_explorer = 0;
        g_explorer_buf_size = 0;
        g_explorer_w = 0;
        g_explorer_h = 0;
        g_explorer_opened = 0;
        g_scroll_offset = 0;
        if (g_fat) { memman_free_4k(g_memman, (unsigned int)g_fat, 4 * 2880); g_fat = 0; }
    }
}

/* 刷新文件浏览器 */
void explorer_refresh(void)
{
    if (!g_explorer_opened) return;
    redraw_explorer();
}

/* 在鼠标位置打开/运行文件（用于双击 .wda）*/
void explorer_open_file_at(int mx, int my)
{
    char fname[32];
    int rx, ry, row, idx, file_i, file_count, j;
    struct FILEINFO *finfo;

    if (!g_sht_explorer || !g_explorer_opened) return;
    rx = mx - g_sht_explorer->vx0;
    ry = my - g_sht_explorer->vy0;
    if (rx < 0 || rx >= g_sht_explorer->bxsize) return;
    if (ry < FILE_LIST_Y || ry >= g_sht_explorer->bysize - BORDER) return;

    row = (ry - FILE_LIST_Y) / LINE_HEIGHT;
    idx = row + g_scroll_offset;

    finfo = (struct FILEINFO *)(ADR_DISKIMG + 0x002600);
    file_count = 0;
    for (file_i = 0; file_i < MAX_FAT12_FILES; file_i++) {
        if (finfo[file_i].name[0] == 0x00) break;
        if (finfo[file_i].name[0] == 0xe5) continue;
        if ((finfo[file_i].type & 0x18) != 0) continue;
        if (file_count == idx) break;  /* 找到了 */
        file_count++;
    }
    if (file_i >= MAX_FAT12_FILES) return;
    if (finfo[file_i].name[0] == 0x00) return;

    /* 更新选中状态并重绘 */
    g_selected_idx = idx;
    redraw_explorer();

    /* 检查扩展名是否为 .WDA 或 .HRB */
    if (finfo[file_i].ext[0] == 'W' && finfo[file_i].ext[1] == 'D' && finfo[file_i].ext[2] == 'A') {
        /* .wda 标准 8.3 格式 */
    } else if (finfo[file_i].ext[0] == '_' && finfo[file_i].ext[1] == 'W' && finfo[file_i].ext[2] == 'D') {
        /* .wda edimg 超长截断格式 */
    } else if (finfo[file_i].ext[0] == 'H' && finfo[file_i].ext[1] == 'R' && finfo[file_i].ext[2] == 'B') {
        /* .hrb 格式（原书兼容）*/
    } else if (finfo[file_i].ext[0] == '_' && finfo[file_i].ext[1] == 'H' && finfo[file_i].ext[2] == 'R') {
        /* .hrb edimg 截断格式 */
    } else {
        return;  /* 不是可执行文件 */
    }

    /* 构造 "filename.wda" 小写文件名 */
    for (j = 0; j < 8 && finfo[file_i].name[j] != ' '; j++) {
        fname[j] = finfo[file_i].name[j];
        if ('A' <= fname[j] && fname[j] <= 'Z') fname[j] += 0x20;
    }
    fname[j] = '.';
    fname[j+1] = finfo[file_i].ext[0] | 0x20;  /* 转小写 */
    fname[j+2] = finfo[file_i].ext[1] | 0x20;
    fname[j+3] = finfo[file_i].ext[2] | 0x20;
    fname[j+4] = '\0';

    /* ncst：后台控制台启动，不显示窗口 */
    {
        struct SHEET *sht = open_console(g_shtctl, g_memtotal);
        struct FIFO32 *fifo = &sht->task->fifo;
        int si;
        sheet_updown(sht, -1);  /* 隐藏控制台窗口 */
        for (si = 0; fname[si]; si++)
            fifo32_put(fifo, fname[si] + 256);
        fifo32_put(fifo, 10 + 256); /* 回车 */
    }
}

/* 鼠标事件处理（拖动、滚动条、关闭按钮） */


