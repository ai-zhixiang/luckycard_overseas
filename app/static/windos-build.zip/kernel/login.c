/* login.c - 开机动画 + 登录（用 keyfifo） */
#include "bootpack.h"

#define IW 96
#define IH 96
#include <icon_data.inc>

static void di(unsigned char *v, int xs, int dx, int dy) {
	int x, y;
	for (y = 0; y < IH; y++)
		for (x = 0; x < IW; x++) {
			int c = icon[y * IW + x];
			v[(dy + y) * xs + (dx + x)] = (c < 6) ? 0 : 15;
		}
}


static void dly(int n) { volatile int d; for (d = 0; d < n; d++) {} }

void show_boot_screen(struct SHTCTL *shtctl, struct BOOTINFO *binfo)
{
	unsigned char *v = binfo->vram;
	int xs = binfo->scrnx, ys = binfo->scrny;
	int cx = xs / 2, cy = ys / 2;
	int f, x, y;
	extern unsigned char anim_data[];
#define ANIM_FRAMES 122
	int bx = cx - 16, by = cy + 20;
	boxfill8(v, xs, COL8_000000, 0, 0, xs - 1, ys - 1);

	/* icon 96x96 */
	for (y = 0; y < IH; y++)
		for (x = 0; x < IW; x++) {
			int c = icon[y * IW + x];
			if (c > 0) v[(cy - 100 + y) * xs + (cx - 48 + x)] = COL8_FFFFFF;
		}

	/* anim */
	for (f = 0; f < ANIM_FRAMES * 3; f++) {
		int fi = f % ANIM_FRAMES;
		int off = 4 + fi * 128;
		boxfill8(v, xs, COL8_000000, bx, by, bx + 31, by + 31);
		for (y = 0; y < 32; y++)
			for (x = 0; x < 32; x++) {
				int bi = off + y * 4 + x / 8;
				if (anim_data[bi] & (0x80 >> (x & 7)))
					v[(by + y) * xs + (bx + x)] = COL8_FFFFFF;
			}
		{volatile int d; for(d=0; d<5000000; d++){}}
	}
}

void login_screen(struct SHTCTL *shtctl, struct BOOTINFO *binfo)
{
	unsigned char *v = binfo->vram;
	int xs = binfo->scrnx, ys = binfo->scrny;
	int cx = xs / 2, cy = ys / 2;
	char user[32] = "", pass[32] = "", pd[32];
	int ul = 0, pl = 0, f = 0, i, kc, redraw = 1;

	for (;;) {
		io_cli();
		/* 消费 FIFO */
		if (fifo8_status(&keyfifo)) {
			kc = fifo8_get(&keyfifo);
			io_sti();
			if (kc < 0x80) {
				if (kc == 0x0F) f = (f + 1) % 3;
				else if (kc == 0x1C) { if (ul) return; }
				else if (kc == 0x0E) {
					if (f == 0 && ul) user[--ul] = 0;
					if (f == 1 && pl) pass[--pl] = 0;
				} else {
					char c = 0;
					if (kc == 0x39) c = ' ';
					else if (kc >= 0x02 && kc <= 0x0B) c = "1234567890-="[kc-2];
					else if (kc >= 0x10 && kc <= 0x1A) c = "QWERTYUIOP[]"[kc-0x10];
					else if (kc >= 0x1E && kc <= 0x28) c = "ASDFGHJKL;'`"[kc-0x1E];
					else if (kc >= 0x2C && kc <= 0x35) c = "ZXCVBNM,./"[kc-0x2C];
					if (c) {
						if (f == 0 && ul < 30) { user[ul++] = c; user[ul] = 0; }
						if (f == 1 && pl < 30) { pass[pl++] = c; pass[pl] = 0; }
					}
				}
			}
			redraw = 1;
		}
		io_sti();

		/* 只在有变化时重画 */
		if (redraw) {
			redraw = 0;
			boxfill8(v, xs, COL8_000084, 0, 0, xs - 1, ys - 1);
			di(v, xs, cx - 32, cy - 100);
			putfonts8_asc(v, xs, cx - 20, cy - 30, COL8_FFFFFF, "WinDOS");
			putfonts8_asc(v, xs, cx - 60, cy + 5, COL8_FFFFFF, (unsigned char *)"User:");
			boxfill8(v, xs, f == 0 ? COL8_FFFFFF : COL8_848484, cx - 30, cy + 5, cx + 69, cy + 21);
			boxfill8(v, xs, COL8_000000, cx - 28, cy + 7, cx + 67, cy + 19);
			if (ul) putfonts8_asc(v, xs, cx - 26, cy + 8, COL8_FFFFFF, (unsigned char *)user);
			putfonts8_asc(v, xs, cx - 60, cy + 28, COL8_FFFFFF, (unsigned char *)"Pass:");
			boxfill8(v, xs, f == 1 ? COL8_FFFFFF : COL8_848484, cx - 30, cy + 28, cx + 69, cy + 44);
			boxfill8(v, xs, COL8_000000, cx - 28, cy + 30, cx + 67, cy + 42);
			if (pl) {
				for (i = 0; i < pl; i++) pd[i] = '*'; pd[pl] = 0;
				putfonts8_asc(v, xs, cx - 26, cy + 31, COL8_FFFFFF, (unsigned char *)pd);
			}
			{ int bx = cx - 18, by = cy + 55;
			  boxfill8(v, xs, f == 2 ? COL8_00FF00 : COL8_FFFFFF, bx, by, bx + 36, by + 16);
			  boxfill8(v, xs, COL8_000000, bx + 2, by + 2, bx + 34, by + 14);
			  putfonts8_asc(v, xs, bx + 5, by + 3, COL8_FFFFFF, "OK"); }
			putfonts8_asc(v, xs, cx - 90, cy + 85, COL8_848484,
				(unsigned char *)"Tab:Switch  Enter:Login");
		}

		io_stihlt();
	}
}
