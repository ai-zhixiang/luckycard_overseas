/* loader.c - 完全参照《30天自制操作系统》cmd_app 实现 */

#include "bootpack.h"

int load_wda(const char *fname, struct SHEET *sht)
{
	struct MEMMAN *memman = g_memman;
	struct FILEINFO *finfo;
	unsigned char *p, *q;
	struct TASK *task = task_now();
	int i, fsize, segsiz, esp, datsiz, dathrb;
	char name[18];

	/* 构造文件名 */
	for (i = 0; i < 13 && fname[i] > ' '; i++) name[i] = fname[i];
	name[i] = 0;

	/* 找文件 */
	finfo = file_search(name, (struct FILEINFO *)(ADR_DISKIMG + 0x002600), 224);
	if (finfo == 0) {
		name[i] = '.'; name[i+1] = 'W'; name[i+2] = 'D';
		name[i+3] = 'A'; name[i+4] = 0;
		finfo = file_search(name, (struct FILEINFO *)(ADR_DISKIMG + 0x002600), 224);
	}
	if (finfo == 0) {
		name[i] = '.'; name[i+1] = 'H'; name[i+2] = 'R';
		name[i+3] = 'B'; name[i+4] = 0;
		finfo = file_search(name, (struct FILEINFO *)(ADR_DISKIMG + 0x002600), 224);
	}
	if (finfo == 0) return -2;

	/* 原封不动照搬原书 cmd_app 逻辑 */
	fsize = finfo->size;
	p = (unsigned char *)memman_alloc_4k(memman, fsize);
	if (p == 0) return -1;
	file_load(fname, p);

	if (fsize >= 36 && p[4] == 'H' && p[5] == 'a' && p[6] == 'r' && p[7] == 'i' && (p[0] & 0xff) == 0) {
		segsiz = *(int *)(p + 0x00);
		esp    = *(int *)(p + 0x0c);
		datsiz = *(int *)(p + 0x10);
		dathrb = *(int *)(p + 0x14);
		q = (unsigned char *)memman_alloc_4k(memman, segsiz);
		if (q == 0) { memman_free_4k(memman, (int)p, fsize); return -4; }
		task->ds_base = (int)q;
		set_segmdesc(task->ldt + 0, fsize - 1, (int)p, AR_CODE32_ER + 0x60);
		set_segmdesc(task->ldt + 1, segsiz - 1, (int)q, AR_DATA32_RW + 0x60);
		for (i = 0; i < datsiz; i++) q[esp + i] = p[dathrb + i];
		task->heap_top = esp + datsiz; /* 堆从数据段尾部开始 */
		load_ldt(task->sel_ldt);	/* 显式加载 LDT（原书通过 TSS 切换自动加载，但我们直接调用 start_app 需要手动加载） */
		start_app(0x1b, 0 * 8 + 4, esp, 1 * 8 + 4, &(task->tss.esp0));
		/* 清理 */
		{
			struct SHTCTL *shtctl = (struct SHTCTL *)*((int *)0x0fe4);
			struct SHEET *sht;
			for (i = 0; i < MAX_SHEETS; i++) {
				sht = &(shtctl->sheets0[i]);
				if ((sht->flags & 0x11) == 0x11 && sht->task == task) {
					sheet_free(sht);
				}
			}
		}
		memman_free_4k(memman, (int)q, segsiz);
		memman_free_4k(memman, (int)p, fsize);
		return 0;
	}
	memman_free_4k(memman, (int)p, fsize);
	return -3;
}
