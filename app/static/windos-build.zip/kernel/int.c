/*初始化关系 */

#include "bootpack.h"

/* 预声明 BSOD（在 bootpack.c 中）*/
extern void BSOD(int stopcode, struct BOOTINFO *binfo);

void init_pic(void)
/* PIC初始化 */
{
	io_out8(PIC0_IMR,  0xff  ); /* 禁止所有中断 */
	io_out8(PIC1_IMR,  0xff  ); /* 禁止所有中断 */

	io_out8(PIC0_ICW1, 0x11  ); /* 边缘触发模式（edge trigger mode） */
	io_out8(PIC0_ICW2, 0x20  ); /* IRQ0-7由INT20-27接收 */
	io_out8(PIC0_ICW3, 1 << 2); /* PIC1由IRQ2相连 */
	io_out8(PIC0_ICW4, 0x01  ); /* 无缓冲区模式 */

	io_out8(PIC1_ICW1, 0x11  ); /* 边缘触发模式（edge trigger mode） */
	io_out8(PIC1_ICW2, 0x28  ); /* IRQ8-15由INT28-2f接收 */
	io_out8(PIC1_ICW3, 2     ); /* PIC1由IRQ2连接 */
	io_out8(PIC1_ICW4, 0x01  ); /* 无缓冲区模式 */

	io_out8(PIC0_IMR,  0xfb  ); /* 11111011 PIC1以外全部禁止 */
	io_out8(PIC1_IMR,  0xff  ); /* 11111111 禁止所有中断 */

	return;
}

#define PORT_KEYDAT		0x0060

void inthandler27(int *esp)
/* PIC0中断的不完整策略 */
/* 这个中断在Athlon64X2上通过芯片组提供的便利，只需执行一次 */
/* 这个中断只是接收，不执行任何操作 */
/* 为什么不处理？
	→  因为这个中断可能是电气噪声引发的、只是处理一些重要的情况。*/
{
	io_out8(PIC0_OCW2, 0x67); /* 通知PIC的IRQ-07（参考7-1） */
	return;
}

/* CPU 异常处理程序 — #GP (0x0D) */
/* 尝试优雅结束应用，并显示故障信息 */
int *inthandler0d(int *esp)
{
	struct TASK *task = task_now();
	struct BOOTINFO *binfo = (struct BOOTINFO *) ADR_BOOTINFO;
	struct SHTCTL *shtctl = (struct SHTCTL *)*((int *)0x0fe4);
	char s[40];

	/* esp[0..7] = PUSHAD, esp[8]=DS, esp[9]=ES, esp[10]=err, esp[11]=EIP, esp[12]=CS */
	int fault_eip = esp[11];
	int fault_cs  = esp[12];
	int err_code  = esp[10];

	/* 在屏幕上显示故障地址 */
	sprintf(s, "GP: EIP=%08X CS=%d err=%04X", fault_eip, fault_cs & 3, err_code);
	putfonts8_asc(binfo->vram, binfo->scrnx, 0, 180, COL8_FF0000, s);

	return &(task->tss.esp0);
}
