/* WinDOS 简单文件系统实现 */
/* 基于内存的简易文件系统 */

#include "bootpack.h"
#include <stdio.h>
#include <string.h>

/* 文件系统常量定义 */
#define FS_MAGIC           0x5744  /* 魔数 "WD" (WinDOS) */

/* 文件状态标志 */
#define FS_FLAG_OPEN       0x01    /* 文件已打开 */
#define FS_FLAG_DIRTY      0x02    /* 文件已修改 */

/* 文件系统控制结构 (内部使用) */
struct FS_CONTROL {
    struct FS_SUPERBLOCK *sb;     /* 超级块 */
    struct FS_INODE *inodes;       /* inode数组 */
    unsigned char *data_blocks;    /* 数据块区 */
    unsigned char *block_bitmap;   /* 块位图 */
    unsigned char *inode_bitmap;   /* inode位图 */
    struct FS_FILE *fd_table;      /* 文件描述符表 */
    int initialized;                /* 是否已初始化 */
    int fd_count;                  /* 已打开文件数 */
};

/* 全局文件系统控制结构 */
static struct FS_CONTROL fs_ctrl;

/* 前向声明 */
static int fs_alloc_block(void);
static void fs_free_block(unsigned int block_id);
static int fs_alloc_inode(void);
static void fs_free_inode(unsigned short inode);
static struct FS_INODE *fs_get_inode(unsigned short inode);
static void fs_sync_inode(struct FS_INODE *inode, unsigned short inode_id);
static unsigned int fs_get_time(void);
static int fs_find_in_dir(unsigned short dir_inode, const char *name, struct FS_DIRENT *dirent);
static int fs_add_dirent(unsigned short dir_inode, const char *name, 
                         unsigned short file_inode, unsigned char type, 
                         unsigned char attr, unsigned int size);
static int fs_del_dirent(unsigned short dir_inode, const char *name);

/* 初始化文件系统 */
int fs_init(const char *volume_name)
{
    int i;
    unsigned int total_mem;
    unsigned int blocks;
    
    if (fs_ctrl.initialized) {
        return 0;  /* 已经初始化 */
    }
    
    /* 分配内存区域 (64KB) */
    total_mem = 64 * 1024;
    blocks = (total_mem - sizeof(struct FS_SUPERBLOCK) - 
              sizeof(struct FS_INODE) * FS_MAX_FILES) / FS_BLOCK_SIZE;
    
    /* 分配超级块 */
    fs_ctrl.sb = (struct FS_SUPERBLOCK *)memman_alloc_4k((struct MEMMAN *)MEMMAN_ADDR, 
                                                          sizeof(struct FS_SUPERBLOCK));
    if (fs_ctrl.sb == 0) {
        return -1;
    }
    
    /* 初始化超级块 */
    fs_ctrl.sb->magic = FS_MAGIC;
    fs_ctrl.sb->total_blocks = blocks;
    fs_ctrl.sb->free_blocks = blocks - 1;  /* 保留根目录块 */
    fs_ctrl.sb->inode_count = FS_MAX_FILES;
    fs_ctrl.sb->block_size = FS_BLOCK_SIZE;
    fs_ctrl.sb->create_time = fs_get_time();
    if (volume_name) {
        for (i = 0; i < 31 && volume_name[i]; i++) {
            fs_ctrl.sb->volume_name[i] = volume_name[i];
        }
        fs_ctrl.sb->volume_name[i] = 0;
    } else {
        strcpy(fs_ctrl.sb->volume_name, "WinDOS");
    }
    
    /* 分配inode数组 */
    fs_ctrl.inodes = (struct FS_INODE *)memman_alloc_4k((struct MEMMAN *)MEMMAN_ADDR,
                                                        sizeof(struct FS_INODE) * FS_MAX_FILES);
    if (fs_ctrl.inodes == 0) {
        return -1;
    }
    memset(fs_ctrl.inodes, 0, sizeof(struct FS_INODE) * FS_MAX_FILES);
    
    /* 分配数据块区 */
    fs_ctrl.data_blocks = (unsigned char *)memman_alloc_4k((struct MEMMAN *)MEMMAN_ADDR, 
                                                           blocks * FS_BLOCK_SIZE);
    if (fs_ctrl.data_blocks == 0) {
        return -1;
    }
    
    /* 分配位图 */
    fs_ctrl.block_bitmap = (unsigned char *)memman_alloc_4k((struct MEMMAN *)MEMMAN_ADDR, 
                                                            (blocks + 7) / 8);
    fs_ctrl.inode_bitmap = (unsigned char *)memman_alloc_4k((struct MEMMAN *)MEMMAN_ADDR, 
                                                             (FS_MAX_FILES + 7) / 8);
    if (fs_ctrl.block_bitmap == 0 || fs_ctrl.inode_bitmap == 0) {
        return -1;
    }
    memset(fs_ctrl.block_bitmap, 0, (blocks + 7) / 8);
    memset(fs_ctrl.inode_bitmap, 0, (FS_MAX_FILES + 7) / 8);
    
    /* 分配文件描述符表 */
    fs_ctrl.fd_table = (struct FS_FILE *)memman_alloc_4k((struct MEMMAN *)MEMMAN_ADDR,
                                                         sizeof(struct FS_FILE) * FS_MAX_FILES);
    if (fs_ctrl.fd_table == 0) {
        return -1;
    }
    memset(fs_ctrl.fd_table, 0, sizeof(struct FS_FILE) * FS_MAX_FILES);
    
    /* 标记根目录inode (inode 0) */
    fs_ctrl.inode_bitmap[0] |= 0x01;
    fs_ctrl.inodes[0].mode = FS_TYPE_DIR;
    fs_ctrl.inodes[0].size = 0;
    fs_ctrl.inodes[0].blocks = 1;
    fs_ctrl.inodes[0].ctime = fs_get_time();
    fs_ctrl.inodes[0].mtime = fs_ctrl.inodes[0].ctime;
    fs_ctrl.inodes[0].flags = 0;
    
    /* 分配根目录的数据块 */
    fs_ctrl.inodes[0].block_ptr[0] = fs_alloc_block();
    
    fs_ctrl.initialized = 1;
    fs_ctrl.fd_count = 0;
    
    return 0;
}

/* 获取当前时间 (简化版本) */
static unsigned int fs_get_time(void)
{
    /* 在实际系统中，这里应该从RTC读取时间 */
    /* 这里返回一个简单的时间戳 */
    static unsigned int sys_time = 0;
    return ++sys_time + 1000000;
}

/* 分配一个数据块 */
static int fs_alloc_block(void)
{
    int i;
    int byte_idx, bit_idx;
    
    for (i = 0; i < (int)fs_ctrl.sb->total_blocks; i++) {
        byte_idx = i / 8;
        bit_idx = i % 8;
        
        if (!(fs_ctrl.block_bitmap[byte_idx] & (1 << bit_idx))) {
            fs_ctrl.block_bitmap[byte_idx] |= (1 << bit_idx);
            fs_ctrl.sb->free_blocks--;
            return i;
        }
    }
    
    return -1;  /* 没有空闲块 */
}

/* 释放一个数据块 */
static void fs_free_block(unsigned int block_id)
{
    int byte_idx, bit_idx;
    
    if (block_id >= fs_ctrl.sb->total_blocks) {
        return;
    }
    
    byte_idx = block_id / 8;
    bit_idx = block_id % 8;
    
    fs_ctrl.block_bitmap[byte_idx] &= ~(1 << bit_idx);
    fs_ctrl.sb->free_blocks++;
}

/* 分配一个inode */
static int fs_alloc_inode(void)
{
    int i;
    int byte_idx, bit_idx;
    
    for (i = 1; i < FS_MAX_FILES; i++) {  /* inode 0 保留给根目录 */
        byte_idx = i / 8;
        bit_idx = i % 8;
        
        if (!(fs_ctrl.inode_bitmap[byte_idx] & (1 << bit_idx))) {
            fs_ctrl.inode_bitmap[byte_idx] |= (1 << bit_idx);
            memset(&fs_ctrl.inodes[i], 0, sizeof(struct FS_INODE));
            return i;
        }
    }
    
    return -1;  /* 没有空闲inode */
}

/* 释放一个inode */
static void fs_free_inode(unsigned short inode)
{
    int byte_idx, bit_idx;
    
    if (inode >= FS_MAX_FILES || inode == 0) {
        return;
    }
    
    byte_idx = inode / 8;
    bit_idx = inode % 8;
    
    fs_ctrl.inode_bitmap[byte_idx] &= ~(1 << bit_idx);
    memset(&fs_ctrl.inodes[inode], 0, sizeof(struct FS_INODE));
}

/* 获取inode指针 */
static struct FS_INODE *fs_get_inode(unsigned short inode)
{
    if (inode >= FS_MAX_FILES) {
        return 0;
    }
    return &fs_ctrl.inodes[inode];
}

/* 同步inode到磁盘 (这里只是标记) */
static void fs_sync_inode(struct FS_INODE *inode, unsigned short inode_id)
{
    /* 在实际文件系统中，这里会将inode写入磁盘 */
    /* 我们的内存文件系统不需要这个操作 */
    (void)inode;
    (void)inode_id;
}

/* 在目录中查找文件 */
static int fs_find_in_dir(unsigned short dir_inode, const char *name, struct FS_DIRENT *dirent)
{
    struct FS_INODE *inode_ptr;
    struct FS_DIRENT *dir_entries;
    int i, entries_count;
    
    if (dir_inode >= FS_MAX_FILES) {
        return -1;
    }
    
    inode_ptr = fs_get_inode(dir_inode);
    if (!inode_ptr || (inode_ptr->mode != FS_TYPE_DIR)) {
        return -1;
    }
    
    /* 读取目录的数据块 */
    if (inode_ptr->block_ptr[0] == 0) {
        return -1;
    }
    
    dir_entries = (struct FS_DIRENT *)(fs_ctrl.data_blocks + 
                                       inode_ptr->block_ptr[0] * FS_BLOCK_SIZE);
    entries_count = inode_ptr->size / sizeof(struct FS_DIRENT);
    
    for (i = 0; i < entries_count; i++) {
        if (strcmp(dir_entries[i].name, name) == 0) {
            if (dirent) {
                *dirent = dir_entries[i];
            }
            return dir_entries[i].inode;
        }
    }
    
    return -1;  /* 未找到 */
}

/* 在目录中添加目录项 */
static int fs_add_dirent(unsigned short dir_inode, const char *name, 
                         unsigned short file_inode, unsigned char type, 
                         unsigned char attr, unsigned int size)
{
    struct FS_INODE *dir_inode_ptr;
    struct FS_DIRENT *dir_entries;
    int entries_count;
    
    if (dir_inode >= FS_MAX_FILES) {
        return -1;
    }
    
    dir_inode_ptr = fs_get_inode(dir_inode);
    if (!dir_inode_ptr || (dir_inode_ptr->mode != FS_TYPE_DIR)) {
        return -1;
    }
    
    /* 检查目录是否已满 */
    if (dir_inode_ptr->size >= FS_BLOCK_SIZE) {
        return -1;  /* 目录项已满 (一个块) */
    }
    
    /* 读取目录的数据块 */
    dir_entries = (struct FS_DIRENT *)(fs_ctrl.data_blocks + 
                                       dir_inode_ptr->block_ptr[0] * FS_BLOCK_SIZE);
    entries_count = dir_inode_ptr->size / sizeof(struct FS_DIRENT);
    
    /* 添加新目录项 */
    dir_entries[entries_count].inode = file_inode;
    strcpy(dir_entries[entries_count].name, name);
    dir_entries[entries_count].type = type;
    dir_entries[entries_count].attr = attr;
    dir_entries[entries_count].size = size;
    dir_entries[entries_count].mtime = fs_get_time();
    
    /* 更新目录inode */
    dir_inode_ptr->size += sizeof(struct FS_DIRENT);
    dir_inode_ptr->mtime = fs_get_time();
    fs_sync_inode(dir_inode_ptr, dir_inode);
    
    return 0;
}

/* 从目录中删除目录项 */
static int fs_del_dirent(unsigned short dir_inode, const char *name)
{
    struct FS_INODE *dir_inode_ptr;
    struct FS_DIRENT *dir_entries;
    int i, entries_count;
    
    if (dir_inode >= FS_MAX_FILES) {
        return -1;
    }
    
    dir_inode_ptr = fs_get_inode(dir_inode);
    if (!dir_inode_ptr || (dir_inode_ptr->mode != FS_TYPE_DIR)) {
        return -1;
    }
    
    /* 读取目录的数据块 */
    dir_entries = (struct FS_DIRENT *)(fs_ctrl.data_blocks + 
                                       dir_inode_ptr->block_ptr[0] * FS_BLOCK_SIZE);
    entries_count = dir_inode_ptr->size / sizeof(struct FS_DIRENT);
    
    /* 查找并删除目录项 */
    for (i = 0; i < entries_count; i++) {
        if (strcmp(dir_entries[i].name, name) == 0) {
            /* 将最后一项移到当前位置 */
            if (i < entries_count - 1) {
                dir_entries[i] = dir_entries[entries_count - 1];
            }
            memset(&dir_entries[entries_count - 1], 0, sizeof(struct FS_DIRENT));
            
            /* 更新目录inode */
            dir_inode_ptr->size -= sizeof(struct FS_DIRENT);
            dir_inode_ptr->mtime = fs_get_time();
            fs_sync_inode(dir_inode_ptr, dir_inode);
            
            return 0;
        }
    }
    
    return -1;  /* 未找到 */
}

/* 创建文件 */
int fs_create(const char *path, unsigned char attr)
{
    char filename[FS_FILENAME_LEN];
    const char *p;
    int inode_id;
    struct FS_INODE *inode_ptr;
    
    if (!fs_ctrl.initialized) {
        return -1;
    }
    
    /* 简化路径处理：只支持根目录 */
    if (path[0] == '/') {
        p = path + 1;
    } else {
        p = path;
    }
    
    /* 检查文件名长度 */
    if (strlen(p) >= FS_FILENAME_LEN) {
        return -1;
    }
    
    /* 检查文件是否已存在 */
    if (fs_find_in_dir(0, p, 0) >= 0) {
        return -2;  /* 文件已存在 */
    }
    
    /* 分配inode */
    inode_id = fs_alloc_inode();
    if (inode_id < 0) {
        return -1;
    }
    
    /* 初始化inode */
    inode_ptr = fs_get_inode(inode_id);
    inode_ptr->mode = FS_TYPE_FILE;
    inode_ptr->size = 0;
    inode_ptr->blocks = 0;
    inode_ptr->ctime = fs_get_time();
    inode_ptr->mtime = inode_ptr->ctime;
    inode_ptr->flags = 0;
    
    /* 添加到根目录 */
    if (fs_add_dirent(0, p, inode_id, FS_TYPE_FILE, attr, 0) < 0) {
        fs_free_inode(inode_id);
        return -1;
    }
    
    return 0;
}

/* 创建目录 */
int fs_mkdir(const char *path, unsigned char attr)
{
    char dirname[FS_FILENAME_LEN];
    const char *p;
    int inode_id;
    struct FS_INODE *inode_ptr;
    int block_id;
    
    if (!fs_ctrl.initialized) {
        return -1;
    }
    
    /* 简化路径处理：只支持根目录 */
    if (path[0] == '/') {
        p = path + 1;
    } else {
        p = path;
    }
    
    /* 检查目录名长度 */
    if (strlen(p) >= FS_FILENAME_LEN) {
        return -1;
    }
    
    /* 检查目录是否已存在 */
    if (fs_find_in_dir(0, p, 0) >= 0) {
        return -2;  /* 目录已存在 */
    }
    
    /* 分配inode */
    inode_id = fs_alloc_inode();
    if (inode_id < 0) {
        return -1;
    }
    
    /* 初始化inode */
    inode_ptr = fs_get_inode(inode_id);
    inode_ptr->mode = FS_TYPE_DIR;
    inode_ptr->size = 0;
    inode_ptr->blocks = 1;
    inode_ptr->ctime = fs_get_time();
    inode_ptr->mtime = inode_ptr->ctime;
    inode_ptr->flags = 0;
    
    /* 分配数据块 */
    block_id = fs_alloc_block();
    if (block_id < 0) {
        fs_free_inode(inode_id);
        return -1;
    }
    inode_ptr->block_ptr[0] = block_id;
    
    /* 添加到根目录 */
    if (fs_add_dirent(0, p, inode_id, FS_TYPE_DIR, attr | FS_ATTR_DIRECTORY, 0) < 0) {
        fs_free_block(block_id);
        fs_free_inode(inode_id);
        return -1;
    }
    
    return 0;
}

/* 删除文件 */
int fs_unlink(const char *path)
{
    char filename[FS_FILENAME_LEN];
    const char *p;
    int inode_id;
    struct FS_INODE *inode_ptr;
    int i;
    
    if (!fs_ctrl.initialized) {
        return -1;
    }
    
    /* 简化路径处理：只支持根目录 */
    if (path[0] == '/') {
        p = path + 1;
    } else {
        p = path;
    }
    
    /* 查找文件 */
    inode_id = fs_find_in_dir(0, p, 0);
    if (inode_id < 0) {
        return -1;  /* 文件不存在 */
    }
    
    /* 获取inode */
    inode_ptr = fs_get_inode(inode_id);
    if (!inode_ptr) {
        return -1;
    }
    
    /* 释放数据块 */
    for (i = 0; i < 8; i++) {
        if (inode_ptr->block_ptr[i]) {
            fs_free_block(inode_ptr->block_ptr[i]);
        }
    }
    
    /* 从目录中删除 */
    fs_del_dirent(0, p);
    
    /* 释放inode */
    fs_free_inode(inode_id);
    
    return 0;
}

/* 打开文件 */
int fs_open(const char *path, unsigned char mode)
{
    char filename[FS_FILENAME_LEN];
    const char *p;
    int inode_id;
    int fd;
    struct FS_FILE *file;
    
    if (!fs_ctrl.initialized) {
        return -1;
    }
    
    /* 简化路径处理：只支持根目录 */
    if (path[0] == '/') {
        p = path + 1;
    } else {
        p = path;
    }
    
    /* 查找文件 */
    inode_id = fs_find_in_dir(0, p, 0);
    if (inode_id < 0) {
        /* 文件不存在，如果是创建模式则创建 */
        if (mode & FS_WRITE) {
            if (fs_create(path, FS_ATTR_ARCHIVE) < 0) {
                return -1;
            }
            inode_id = fs_find_in_dir(0, p, 0);
            if (inode_id < 0) {
                return -1;
            }
        } else {
            return -1;
        }
    }
    
    /* 分配文件描述符 */
    for (fd = 0; fd < FS_MAX_FILES; fd++) {
        if (fs_ctrl.fd_table[fd].flags == 0) {
            break;
        }
    }
    if (fd >= FS_MAX_FILES) {
        return -1;  /* 文件描述符用完 */
    }
    
    /* 初始化文件描述符 */
    file = &fs_ctrl.fd_table[fd];
    file->fd = fd;
    file->inode = inode_id;
    file->pos = 0;
    file->mode = mode;
    file->flags = FS_FLAG_OPEN;
    file->inode_ptr = fs_get_inode(inode_id);
    
    fs_ctrl.fd_count++;
    
    return fd;
}

/* 关闭文件 */
int fs_close(int fd)
{
    if (fd < 0 || fd >= FS_MAX_FILES) {
        return -1;
    }
    
    if (fs_ctrl.fd_table[fd].flags == 0) {
        return -1;  /* 文件未打开 */
    }
    
    /* 如果文件被修改，同步inode */
    if (fs_ctrl.fd_table[fd].flags & FS_FLAG_DIRTY) {
        fs_sync_inode(fs_ctrl.fd_table[fd].inode_ptr, fs_ctrl.fd_table[fd].inode);
    }
    
    /* 清空文件描述符 */
    memset(&fs_ctrl.fd_table[fd], 0, sizeof(struct FS_FILE));
    
    fs_ctrl.fd_count--;
    
    return 0;
}

/* 读取文件 */
int fs_read(int fd, void *buf, unsigned int count)
{
    struct FS_FILE *file;
    struct FS_INODE *inode_ptr;
    unsigned int bytes_read;
    unsigned int block_id;
    unsigned int block_offset;
    unsigned int to_read;
    unsigned char *data;
    
    if (fd < 0 || fd >= FS_MAX_FILES) {
        return -1;
    }
    
    file = &fs_ctrl.fd_table[fd];
    if (file->flags == 0) {
        return -1;  /* 文件未打开 */
    }
    
    if (!(file->mode & FS_READ)) {
        return -1;  /* 文件不是以读模式打开的 */
    }
    
    inode_ptr = file->inode_ptr;
    if (!inode_ptr) {
        return -1;
    }
    
    /* 检查是否到达文件末尾 */
    if (file->pos >= inode_ptr->size) {
        return 0;  /* EOF */
    }
    
    /* 调整读取字节数 */
    if (file->pos + count > inode_ptr->size) {
        count = inode_ptr->size - file->pos;
    }
    
    bytes_read = 0;
    data = (unsigned char *)buf;
    
    while (bytes_read < count) {
        /* 计算当前位置所在的块和块内偏移 */
        block_id = file->pos / FS_BLOCK_SIZE;
        block_offset = file->pos % FS_BLOCK_SIZE;
        
        /* 获取块指针 */
        if (block_id < 8) {
            if (inode_ptr->block_ptr[block_id] == 0) {
                break;  /* 没有分配块 */
            }
            block_id = inode_ptr->block_ptr[block_id];
        } else {
            break;  /* 不支持间接指针 (简化) */
        }
        
        /* 计算本次读取的字节数 */
        to_read = FS_BLOCK_SIZE - block_offset;
        if (to_read > count - bytes_read) {
            to_read = count - bytes_read;
        }
        
        /* 从数据块读取数据 */
        memcpy(data + bytes_read, 
               fs_ctrl.data_blocks + block_id * FS_BLOCK_SIZE + block_offset,
               to_read);
        
        bytes_read += to_read;
        file->pos += to_read;
    }
    
    return bytes_read;
}

/* 写入文件 */
int fs_write(int fd, const void *buf, unsigned int count)
{
    struct FS_FILE *file;
    struct FS_INODE *inode_ptr;
    unsigned int bytes_written;
    unsigned int block_id;
    unsigned int block_offset;
    unsigned int to_write;
    unsigned char *data;
    int new_block;
    
    if (fd < 0 || fd >= FS_MAX_FILES) {
        return -1;
    }
    
    file = &fs_ctrl.fd_table[fd];
    if (file->flags == 0) {
        return -1;  /* 文件未打开 */
    }
    
    if (!(file->mode & FS_WRITE)) {
        return -1;  /* 文件不是以写模式打开的 */
    }
    
    inode_ptr = file->inode_ptr;
    if (!inode_ptr) {
        return -1;
    }
    
    bytes_written = 0;
    data = (unsigned char *)buf;
    
    while (bytes_written < count) {
        /* 计算当前位置所在的块和块内偏移 */
        block_id = file->pos / FS_BLOCK_SIZE;
        block_offset = file->pos % FS_BLOCK_SIZE;
        
        /* 获取或分配块指针 */
        if (block_id < 8) {
            if (inode_ptr->block_ptr[block_id] == 0) {
                /* 分配新块 */
                new_block = fs_alloc_block();
                if (new_block < 0) {
                    break;  /* 没有空闲块 */
                }
                inode_ptr->block_ptr[block_id] = new_block;
                inode_ptr->blocks++;
            }
            block_id = inode_ptr->block_ptr[block_id];
        } else {
            break;  /* 不支持间接指针 (简化) */
        }
        
        /* 计算本次写入的字节数 */
        to_write = FS_BLOCK_SIZE - block_offset;
        if (to_write > count - bytes_written) {
            to_write = count - bytes_written;
        }
        
        /* 写入数据块 */
        memcpy(fs_ctrl.data_blocks + block_id * FS_BLOCK_SIZE + block_offset,
               data + bytes_written,
               to_write);
        
        bytes_written += to_write;
        file->pos += to_write;
    }
    
    /* 更新文件大小 */
    if (file->pos > inode_ptr->size) {
        inode_ptr->size = file->pos;
    }
    
    /* 更新inode时间戳 */
    inode_ptr->mtime = fs_get_time();
    file->flags |= FS_FLAG_DIRTY;
    
    return bytes_written;
}

/* 移动文件指针 */
int fs_seek(int fd, int offset, int whence)
{
    struct FS_FILE *file;
    unsigned int new_pos;
    
    if (fd < 0 || fd >= FS_MAX_FILES) {
        return -1;
    }
    
    file = &fs_ctrl.fd_table[fd];
    if (file->flags == 0) {
        return -1;  /* 文件未打开 */
    }
    
    switch (whence) {
        case 0:  /* SEEK_SET */
            new_pos = offset;
            break;
        case 1:  /* SEEK_CUR */
            new_pos = file->pos + offset;
            break;
        case 2:  /* SEEK_END */
            new_pos = file->inode_ptr->size + offset;
            break;
        default:
            return -1;
    }
    
    if (new_pos > file->inode_ptr->size) {
        return -1;  /* 位置超出文件范围 */
    }
    
    file->pos = new_pos;
    return 0;
}

/* 获取文件信息 */
int fs_stat(const char *path, struct FS_DIRENT *stat)
{
    char name[FS_FILENAME_LEN];
    const char *p;
    int inode_id;
    
    if (!fs_ctrl.initialized) {
        return -1;
    }
    
    /* 简化路径处理：只支持根目录 */
    if (path[0] == '/') {
        p = path + 1;
    } else {
        p = path;
    }
    
    /* 查找文件 */
    inode_id = fs_find_in_dir(0, p, stat);
    if (inode_id < 0) {
        return -1;  /* 文件不存在 */
    }
    
    return 0;
}

/* 列出目录内容 */
int fs_list_dir(const char *path, struct FS_DIRENT *dirs, int max_entries)
{
    unsigned short dir_inode;
    struct FS_INODE *inode_ptr;
    struct FS_DIRENT *dir_entries;
    int entries_count;
    int i;
    
    if (!fs_ctrl.initialized) {
        return -1;
    }
    
    /* 简化路径处理：只支持根目录 */
    dir_inode = 0;  /* 根目录 */
    
    inode_ptr = fs_get_inode(dir_inode);
    if (!inode_ptr || (inode_ptr->mode != FS_TYPE_DIR)) {
        return -1;
    }
    
    /* 读取目录的数据块 */
    if (inode_ptr->block_ptr[0] == 0) {
        return 0;
    }
    
    dir_entries = (struct FS_DIRENT *)(fs_ctrl.data_blocks + 
                                       inode_ptr->block_ptr[0] * FS_BLOCK_SIZE);
    entries_count = inode_ptr->size / sizeof(struct FS_DIRENT);
    
    /* 复制目录项 */
    for (i = 0; i < entries_count && i < max_entries; i++) {
        dirs[i] = dir_entries[i];
    }
    
    return entries_count;
}

/* 格式化文件系统 */
int fs_mkfs(const char *volume_name)
{
    /* 重新初始化文件系统 */
    fs_ctrl.initialized = 0;
    return fs_init(volume_name);
}

/* 获取文件系统信息 */
int fs_get_info(char *buf, int buf_size)
{
    if (!fs_ctrl.initialized) {
        return -1;
    }
    
    sprintf(buf, "WinDOS File System\n"
                 "Volume: %s\n"
                 "Total Blocks: %d\n"
                 "Free Blocks: %d\n"
                 "Block Size: %d bytes\n"
                 "Max Files: %d\n"
                 "Open Files: %d\n",
            fs_ctrl.sb->volume_name,
            fs_ctrl.sb->total_blocks,
            fs_ctrl.sb->free_blocks,
            fs_ctrl.sb->block_size,
            FS_MAX_FILES,
            fs_ctrl.fd_count);
    
    return 0;
}

/* 检查文件系统是否初始化 */
int fs_is_initialized(void)
{
    return fs_ctrl.initialized;
}
