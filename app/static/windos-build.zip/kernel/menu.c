/* menu.c - WinDOS 右键上下文菜单（支持多级子菜单） */
#include "bootpack.h"

#define MENU_BORDER   2       /* 菜单边框宽度 */
#define MENU_ITEM_H   22      /* 每项高度 */
#define MENU_MAX      16      /* 最大菜单项数 */
#define MENU_TEXT_X   8       /* 文字左缩进 */
#define MENU_TEXT_Y   3       /* 文字上缩进 */
#define MENU_NEST_MAX 4       /* 最大嵌套层数 */

/* 内部菜单层状态 */
struct MENU_LAYER {
	struct SHEET *sht;       /* 图层 */
	struct MENU_ITEM *items; /* 菜单项数组 */
	int count;               /* 菜单项数 */
	int hover;               /* 当前 hover 项索引 (-1 = none) */
	int w, h;                /* 尺寸 */
	int parent_idx;          /* 父菜单中的项索引 (-1 = 根菜单) */
};

static struct MENU_LAYER g_layer[MENU_NEST_MAX];
static int g_depth = 0;          /* 0 = 无菜单 */

/* ============================================================
 * 辅助函数
 * ============================================================ */

/* 计算字符串显示宽度（ASCII 8px，汉字 16px） */
static int text_w(unsigned char *str)
{
	int w = 0, i;
	for (i = 0; str[i] != 0; i++) {
		if (str[i] >= 0x80) { w += 16; i++; }
		else { w += 8; }
	}
	return w;
}

/* 判断某项是否有子菜单 */
static int item_has_sub(struct MENU_ITEM *items, int idx)
{
	return items[idx].action == -2 &&
	       items[idx].sub != 0 &&
	       items[idx].sub_count > 0;
}

/* ============================================================
 * 图层创建 & 销毁
 * ============================================================ */

/* 创建菜单图层（不含绘制） */
static struct SHEET *layer_create(int x, int y, struct MENU_ITEM *items, int count)
{
	int i, max_w = 120, mw, mh;
	unsigned char *buf;
	struct SHEET *sht;

	if (count > MENU_MAX) count = MENU_MAX;

	/* 计算宽度 */
	for (i = 0; i < count; i++) {
		int w = text_w(items[i].text) + MENU_TEXT_X * 2 + MENU_BORDER * 2;
		if (items[i].action == -2) w += 18;  /* 子菜单箭头 ">" */
		if (w > max_w) max_w = w;
	}
	mw = max_w;
	mh = MENU_BORDER * 2 + count * MENU_ITEM_H;

	/* 限制在屏幕内 */
	if (x + mw > g_binfo->scrnx) x = g_binfo->scrnx - mw;
	if (y + mh > g_binfo->scrny) y = g_binfo->scrny - mh;
	if (x < 0) x = 0;
	if (y < 0) y = 0;

	buf = (unsigned char *) memman_alloc_4k(g_memman, mw * mh);
	if (buf == 0) return 0;

	sht = sheet_alloc(g_shtctl);
	sheet_setbuf(sht, buf, mw, mh, 0xFF);
	sheet_slide(sht, x, y);
	sheet_updown(sht, g_shtctl->top);
	return sht;
}

/* 销毁图层 */
static void layer_destroy(struct MENU_LAYER *l)
{
	if (l->sht == 0) return;
	memman_free_4k(g_memman, (unsigned int) l->sht->buf, l->w * l->h);
	sheet_free(l->sht);
	l->sht = 0;
}

/* ============================================================
 * 绘制
 * ============================================================ */

static void layer_draw(struct MENU_LAYER *l)
{
	int i, y;
	unsigned char *buf = l->sht->buf;
	int xsize = l->w, ysize = l->h;

	/* 3D 边框 */
	boxfill8(buf, xsize, COL8_C6C6C6, 0, 0, xsize - 1, ysize - 1);
	boxfill8(buf, xsize, COL8_FFFFFF, 0, 0, xsize - 1, 0);           /* 顶边高光 */
	boxfill8(buf, xsize, COL8_FFFFFF, 0, 0, 0, ysize - 1);           /* 左边高光 */
	boxfill8(buf, xsize, COL8_848484, 0, ysize - 1, xsize - 1, ysize - 1); /* 底边阴影 */
	boxfill8(buf, xsize, COL8_848484, xsize - 1, 0, xsize - 1, ysize - 1); /* 右边阴影 */

	for (i = 0; i < l->count; i++) {
		y = MENU_BORDER + i * MENU_ITEM_H;

		/* 分隔线 */
		if (l->items[i].action == -1) {
			boxfill8(buf, xsize, COL8_C6C6C6, MENU_BORDER, y,
				xsize - MENU_BORDER - 1, y + MENU_ITEM_H - 1);
			boxfill8(buf, xsize, COL8_848484, MENU_BORDER + 2, y + 10,
				xsize - MENU_BORDER - 3, y + 10);
			boxfill8(buf, xsize, COL8_FFFFFF, MENU_BORDER + 2, y + 11,
				xsize - MENU_BORDER - 3, y + 11);
			continue;
		}

		if (i == l->hover) {
			/* 高亮 */
			boxfill8(buf, xsize, COL8_000084, MENU_BORDER, y,
				xsize - MENU_BORDER - 1, y + MENU_ITEM_H - 1);
			putfonts8_asc_hz(buf, xsize, MENU_TEXT_X + MENU_BORDER,
				y + MENU_TEXT_Y, COL8_FFFFFF, l->items[i].text);
			if (item_has_sub(l->items, i))
				putfonts8_asc(buf, xsize, xsize - 16, y + MENU_TEXT_Y + 1,
					COL8_FFFFFF, (unsigned char *)">");
		} else {
			/* 普通 */
			boxfill8(buf, xsize, COL8_FFFFFF, MENU_BORDER, y,
				xsize - MENU_BORDER - 1, y + MENU_ITEM_H - 1);
			putfonts8_asc_hz(buf, xsize, MENU_TEXT_X + MENU_BORDER,
				y + MENU_TEXT_Y, COL8_000000, l->items[i].text);
			if (item_has_sub(l->items, i))
				putfonts8_asc(buf, xsize, xsize - 16, y + MENU_TEXT_Y + 1,
					COL8_000000, (unsigned char *)">");
		}
	}
}

/* ============================================================
 * 鼠标测试
 * ============================================================ */

static int layer_hit(struct MENU_LAYER *l, int mx, int my)
{
	int rx = mx - l->sht->vx0;
	int ry = my - l->sht->vy0;
	return (rx >= 0 && rx < l->w && ry >= 0 && ry < l->h);
}

static int layer_index(struct MENU_LAYER *l, int mx, int my)
{
	int rx = mx - l->sht->vx0;
	int ry = my - l->sht->vy0;
	int idx;

	if (rx < MENU_BORDER || rx >= l->w - MENU_BORDER) return -1;
	if (ry < MENU_BORDER || ry >= l->h - MENU_BORDER) return -1;
	idx = (ry - MENU_BORDER) / MENU_ITEM_H;
	if (idx < 0 || idx >= l->count) return -1;
	return idx;
}

/* ============================================================
 * 公共 API
 * ============================================================ */

/* 判断菜单是否打开 */
int is_menu_open(void)
{
	return g_depth > 0;
}

/* 显示上下文菜单 */
void show_context_menu(int x, int y, struct MENU_ITEM *items, int count)
{
	struct SHEET *sht;

	hide_all_menus();

	sht = layer_create(x, y, items, count);
	if (sht == 0) return;

	g_layer[0].sht = sht;
	g_layer[0].items = items;
	g_layer[0].count = count;
	g_layer[0].hover = -1;
	g_layer[0].w = sht->bxsize;
	g_layer[0].h = sht->bysize;
	g_layer[0].parent_idx = -1;
	g_depth = 1;

	layer_draw(&g_layer[0]);
	sheet_refresh(g_layer[0].sht, 0, 0, g_layer[0].w, g_layer[0].h);
}

/* 关闭从指定深度开始的所有子菜单 */
static void close_from(int depth)
{
	int d;
	for (d = g_depth - 1; d >= depth; d--)
		layer_destroy(&g_layer[d]);
	g_depth = depth;
}

/* 关闭所有菜单 */
void hide_all_menus(void)
{
	close_from(0);
}

/* 打开子菜单 */
static void sub_open(int parent_d, int parent_item)
{
	struct MENU_LAYER *p = &g_layer[parent_d];
	struct MENU_ITEM *si = p->items[parent_item].sub;
	int sc = p->items[parent_item].sub_count;
	struct SHEET *sht;
	int cd, sx, sy;

	cd = parent_d + 1;

	/* 子菜单位置：父菜单项右侧 */
	sx = p->sht->vx0 + p->w - 2;
	sy = p->sht->vy0 + MENU_BORDER + parent_item * MENU_ITEM_H;

	/* 如果右侧超出屏幕，放到左侧 */
	if (sx + 120 > g_binfo->scrnx)
		sx = p->sht->vx0 - 120;
	if (sx < 0) sx = 0;

	sht = layer_create(sx, sy, si, sc);
	if (sht == 0) return;

	g_layer[cd].sht = sht;
	g_layer[cd].items = si;
	g_layer[cd].count = sc;
	g_layer[cd].hover = -1;
	g_layer[cd].w = sht->bxsize;
	g_layer[cd].h = sht->bysize;
	g_layer[cd].parent_idx = parent_item;
	g_depth = cd + 1;

	layer_draw(&g_layer[cd]);
	sheet_refresh(g_layer[cd].sht, 0, 0, g_layer[cd].w, g_layer[cd].h);
}

/* 更新 hover（含子菜单展开/关闭） */
void menu_update_hover(int mx, int my)
{
	int d, new_hov[MENU_NEST_MAX], in[MENU_NEST_MAX], new_depth;

	if (g_depth <= 0) return;

	/* 检查每层是否包含鼠标 */
	for (d = 0; d < g_depth; d++) {
		in[d] = layer_hit(&g_layer[d], mx, my);
		new_hov[d] = in[d] ? layer_index(&g_layer[d], mx, my) : -1;
	}

	/* 确定有效深度：最近一层包含鼠标的 */
	new_depth = 0;
	for (d = g_depth - 1; d >= 0; d--) {
		if (in[d]) { new_depth = d + 1; break; }
	}
	if (new_depth < g_depth)
		close_from(new_depth);

	/* 更新 hover 并检查子菜单展开 */
	for (d = 0; d < g_depth; d++) {
		if (new_hov[d] != g_layer[d].hover) {
			g_layer[d].hover = new_hov[d];
			layer_draw(&g_layer[d]);
			sheet_refresh(g_layer[d].sht, 0, 0, g_layer[d].w, g_layer[d].h);
		}

		/* hover 到含子菜单的项 → 展开 */
		if (new_hov[d] >= 0 && item_has_sub(g_layer[d].items, new_hov[d])) {
			if (d + 1 >= g_depth) {
				sub_open(d, new_hov[d]);
			} else if (g_layer[d + 1].parent_idx != new_hov[d]) {
				close_from(d + 1);
				sub_open(d, new_hov[d]);
			}
		}
	}
}

/* 处理点击：返回 action ID，-1 = 未选中/取消。总是关闭所有菜单 */
int menu_handle_click(struct SHTCTL *shtctl, int mx, int my)
{
	int d, result = -1;

	if (g_depth <= 0) return -1;

	/* 从最深层向上查找 */
	for (d = g_depth - 1; d >= 0; d--) {
		int idx;
		if (!layer_hit(&g_layer[d], mx, my)) continue;
		idx = layer_index(&g_layer[d], mx, my);
		if (idx < 0) continue;

		if (g_layer[d].items[idx].action == -2) {
			/* 点击含子菜单的项：不执行操作 */
			break;
		}
		if (g_layer[d].items[idx].action >= 0) {
			result = g_layer[d].items[idx].action;
			break;
		}
		/* action == -1（分隔线）：无操作 */
		break;
	}

	hide_all_menus();
	return result;
}
