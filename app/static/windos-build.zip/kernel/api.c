/* api.c - WinDOS 系统调用分发器 (INT 0x40) */

#include "bootpack.h"

int *win_api(int edi, int esi, int ebp, int esp, int ebx, int edx, int ecx, int eax)
{
    struct TASK *task = task_now();
    struct SHTCTL *shtctl = (struct SHTCTL *) *((int *) 0x0fe4);
    struct SHEET *sht;
    int *reg = &eax + 1;
    /* reg[0]=EDI, reg[1]=ESI, reg[2]=EBP, reg[3]=ESP */
    /* reg[4]=EBX, reg[5]=EDX, reg[6]=ECX, reg[7]=EAX */
    int ds_base = task->ds_base;

    if (edx == 1) {
        /* putchar - 输出一个字符到控制台 */
        if (task->cons != 0) {
            cons_putchar(task->cons, eax & 0xff, 1);
        }
    } else if (edx == 2) {
        /* putstr0 - 输出字符串到控制台 */
        if (task->cons != 0) {
            cons_putstr0(task->cons, (char *) ebx + ds_base);
        }
    } else if (edx == 3) {
        /* putstr1 - 输出指定长度字符串 */
        if (task->cons != 0) {
            cons_putstr1(task->cons, (char *) ebx + ds_base, ecx);
        }
	} else if (edx == 4) {
		/* end - 结束应用 */
		/* _start_app 保存了内核 ESP 到 &(task->tss.esp0)
		 * 返回此地址让 _asm_end_app 恢复内核栈 */
		return &(task->tss.esp0);
    } else if (edx == 5) {
        /* openwin */
        sht = sheet_alloc(shtctl);
        sht->task = task;
        sht->flags |= 0x10;
        sheet_setbuf(sht, (char *) ebx + ds_base, esi, edi, eax);
        make_window8((char *) ebx + ds_base, esi, edi, (char *) ecx + ds_base, 0);
        { int _i; char *_t = (char *) ecx + ds_base; for (_i = 0; _t[_i] && _i < 31; _i++) sht->title[_i] = _t[_i]; sht->title[_i] = 0; }
        sheet_slide(sht, ((shtctl->xsize - esi) / 2) & ~3, (shtctl->ysize - edi) / 2);
        sheet_updown(sht, shtctl->top);
        /* 保持按钮和鼠标在顶层 */
        if (g_sht_btn && g_sht_btn->height >= 0) sheet_updown(g_sht_btn, shtctl->top);
        if (g_sht_mouse && g_sht_mouse->height >= 0) sheet_updown(g_sht_mouse, shtctl->top);
        reg[7] = (int) sht;
    } else if (edx == 6) {
        /* putstrwin */
        sht = (struct SHEET *) (ebx & 0xfffffffe);
        putfonts8_asc(sht->buf, sht->bxsize, esi, edi, eax, (char *) ebp + ds_base);
        if ((ebx & 1) == 0) {
            sheet_refresh(sht, esi, edi, esi + ecx * 8, edi + 16);
        }
    } else if (edx == 7) {
        /* boxfilwin */
        sht = (struct SHEET *) (ebx & 0xfffffffe);
        boxfill8(sht->buf, sht->bxsize, ebp, eax, ecx, esi, edi);
        if ((ebx & 1) == 0) {
            sheet_refresh(sht, eax, ecx, esi + 1, edi + 1);
        }
    } else if (edx == 8) {
        /* linewin */
        sht = (struct SHEET *) (ebx & 0xfffffffe);
        hrb_linewin(sht, esi, edi, eax, ecx, ebp);
        if ((ebx & 1) == 0) {
            /* 刷新包围线段的矩形区域 */
            int x0 = esi < eax ? esi : eax;
            int x1 = esi > eax ? esi : eax;
            int y0 = edi < ecx ? edi : ecx;
            int y1 = edi > ecx ? edi : ecx;
            sheet_refresh(sht, x0, y0, x1 + 1, y1 + 1);
        }
    } else if (edx == 9) {
        /* point */
        sht = (struct SHEET *) (ebx & 0xfffffffe);
        sht->buf[edi * sht->bxsize + esi] = eax;
        if ((ebx & 1) == 0) {
            sheet_refresh(sht, esi, edi, esi + 1, edi + 1);
        }
    } else if (edx == 10) {
        /* refreshwin — 全量重建 map 并刷新 */
        sht = (struct SHEET *) (ebx & 0xfffffffe);
        {
            int vx0 = sht->vx0 + esi, vy0 = sht->vy0 + edi;
            int vx1 = sht->vx0 + eax, vy1 = sht->vy0 + ecx;
            sheet_refreshmap(shtctl, vx0, vy0, vx1, vy1, 0);
            sheet_refreshsub(shtctl, vx0, vy0, vx1, vy1, 0, shtctl->top);
        }
    } else if (edx == 11) {
        /* closewin */
        sht = (struct SHEET *) (ebx & 0xfffffffe);
        sheet_free(sht);
    } else if (edx == 12) {
        /* getkey - 从任务 FIFO 获取输入 */
        /* mode: 0=非阻塞, 1=阻塞 */
        struct TASK *t = task_now();
        if (eax == 0) {
            /* 非阻塞：有数据就返回，无数据返回 0 */
            if (fifo32_status(&t->fifo) != 0) {
                int d = fifo32_get(&t->fifo);
                reg[7] = (d >= 256 && d <= 511) ? (d - 256) : d;
            } else {
                reg[7] = 0;
            }
        } else {
            /* 阻塞：等待数据 */
            while (fifo32_status(&t->fifo) == 0) {
                io_hlt();
            }
            int d = fifo32_get(&t->fifo);
            reg[7] = (d >= 256 && d <= 511) ? (d - 256) : d;
        }
    } else if (edx == 13) {
        /* show_menu - 显示上下文菜单并阻塞等待选择 */
        /* 参数: EBX=x, ESI=y, EDI=items 指针(需加 ds_base), EAX=count */
        /* 返回: EAX=action_id (-1=取消) */
        struct MOUSE_DEC mdec;
        int mx = 0, my = 0, done = 0;
        show_context_menu(ebx, esi, (struct MENU_ITEM *)(edi + ds_base), eax);
        reg[7] = -1;
        while (!done) {
            io_cli();
            if (fifo8_status(&keyfifo) + fifo8_status(&mousefifo) == 0) {
                io_stihlt();
            } else {
                if (fifo8_status(&mousefifo) != 0) {
                    int d = fifo8_get(&mousefifo);
                    io_sti();
                    if (mouse_decode(&mdec, d) != 0) {
                        mx += mdec.x;
                        my += mdec.y;
                        if (mx < 0) mx = 0;
                        if (my < 0) my = 0;
                        if (mx > g_binfo->scrnx - 16) mx = g_binfo->scrnx - 1;
                        if (my > g_binfo->scrny - 16) my = g_binfo->scrny - 1;
                        menu_update_hover(mx, my);
                        if ((mdec.btn & 0x01) != 0) {
                            reg[7] = menu_handle_click(shtctl, mx, my);
                            done = 1;
                        }
                        if ((mdec.btn & 0x02) != 0) {
                            hide_all_menus();
                            reg[7] = -1;
                            done = 1;
                        }
                    }
                }
                if (fifo8_status(&keyfifo) != 0) {
                    int k = fifo8_get(&keyfifo);
                    io_sti();
                    if (k == 0x01) { /* ESC */
                        hide_all_menus();
                        reg[7] = -1;
                        done = 1;
                    }
                }
            }
        }
    } else if (edx == 14) {
        /* setcritical - 设置进程保护级别 */
        /* 参数: EBX=is_kernel, ESI=bsod_on_kill, EDI=is_system */
        if (edi == 0) {
            /* is_system==0: 强制清除前两项 */
            task->is_kernel = 0;
            task->bsod_on_kill = 0;
        } else {
            task->is_kernel = ebx;
            task->bsod_on_kill = esi;
        }
        task->is_system = edi;
    } else if (edx == 15) {
        /* list_files - 列出 FAT12 文件 */
        /* 参数: EBX=buf(加上ds_base), ESI=buf大小(字节) */
        /* 功能: 复制 FILEINFO 到 buf, 最多 buf_size/32 个 */
        /* 返回: EAX=文件数 */
        struct FILEINFO *finfo = (struct FILEINFO *)(ADR_DISKIMG + 0x002600);
        unsigned char *dst = (unsigned char *)ebx + ds_base;
        int max_copy = esi / 32;
        int count = 0, i;
        for (i = 0; i < MAX_FAT12_FILES && count < max_copy; i++) {
            if (finfo[i].name[0] == 0x00) break;
            if (finfo[i].name[0] == 0xe5) continue;
            if ((finfo[i].type & 0x18) != 0) continue;
            memcpy(dst + count * 32, &finfo[i], 32);
            count++;
        }
        reg[7] = count;
    } else if (edx == 16) {
        /* malloc - 从预分配堆中分配内存 */
        /* 参数: EBX=大小(字节) */
        /* 返回: EAX=应用空间地址(0=失败) */
        int alloc_size = (ebx + 3) & ~3;  /* 4 字节对齐 */
        int result = task->heap_top;
        task->heap_top += alloc_size;
        reg[7] = result;
    } else if (edx == 17) {
        /* free - 释放内存（bump 分配器暂不支持释放）*/
        /* 参数: EBX=地址, ECX=大小 */
    } else if (edx == 18) {
        /* run_wda - 运行 .wda 文件 */
        /* 参数: EBX=文件名指针(加上ds_base) */
        /* 返回: EAX=0成功 / 负数失败 */
        reg[7] = load_wda((const char *)ebx + ds_base, 0);
    } else if (edx == 19) {
        /* get_tasklist - 获取任务列表 */
        /* 参数: EBX=buf(加上ds_base), ESI=buf大小(字节) */
        /* 返回: EAX=任务数 */
        unsigned char *dst = (unsigned char *)ebx + ds_base;
        int max_copy = esi / 16;  /* 每个任务 16 字节 */
        int count = 0, i;
        for (i = 0; i < MAX_TASKS && count < max_copy; i++) {
            if (taskctl->tasks0[i].flags != 0) {
                /* 写入: sel(4) + level(4) + priority(4) + flags(4) = 16 字节 */
                *(int *)(dst + count * 16 + 0) = taskctl->tasks0[i].sel;
                *(int *)(dst + count * 16 + 4) = taskctl->tasks0[i].level;
                *(int *)(dst + count * 16 + 8) = taskctl->tasks0[i].priority;
                *(int *)(dst + count * 16 + 12) = taskctl->tasks0[i].flags;
                count++;
            }
        }
        reg[7] = count;
    } else if (edx == 20) {
        /* kill_task - 结束任务 */
        /* 参数: EBX = 任务 sel (TASK_GDT0 + index) * 8 */
        struct TASK *t;
        int idx = (ebx / 8) - TASK_GDT0;
        if (0 <= idx && idx < MAX_TASKS) {
            t = &taskctl->tasks0[idx];
            /* 不能结束自己（flags=2 的主任务）或标志为 0 的任务 */
            if (t->flags != 0) {
                task_sleep(t);
                t->flags = 0;  /* 标记为未使用 */
                reg[7] = 0;    /* 成功 */
            } else {
                reg[7] = -1;   /* 任务已结束 */
            }
        } else {
            reg[7] = -1;
        }
    } else if (edx == 21) {
        /* get_os_version - 返回 OS 版本号*100，如 2614=26.14 */
        reg[7] = 2614;
    } else if (edx == 22) {
        /* is_window_valid - 窗口是否存在 */
        sht = (struct SHEET *) (ebx & 0xfffffffe);
        reg[7] = (sht->flags != 0) ? 1 : 0;
    } else if (edx == 23) {
        /* alloctimer */
        reg[7] = (int) timer_alloc();
    } else if (edx == 24) {
        /* inittimer */
        struct TASK *task = task_now();
        timer_init((struct TIMER *) ebx, &task->fifo, eax + 256);
    } else if (edx == 25) {
        /* settimer */
        timer_settime((struct TIMER *) ebx, eax);
    } else if (edx == 26) {
        if (g_mbtn) {
            if (g_mx >= esi && g_mx < esi + eax && g_my >= edi && g_my < edi + ecx) { g_mbtn = 0; reg[7] = 1; }
            else reg[7] = 0;
        } else reg[7] = 0;
    } else if (edx == 27) {
        struct TIMER *tm = timer_alloc();
        timer_init(tm, &task->fifo, 128);
        timer_settime(tm, eax);
        fifo32_get(&task->fifo);
        timer_free(tm);
    }

    return 0;
}

/* 画线辅助函数 */
void hrb_linewin(struct SHEET *sht, int x0, int y0, int x1, int y1, int col)
{
    int dx = x1 - x0, dy = y1 - y0;
    int x = x0, y = y0;

    if (dx < 0) dx = -dx;
    if (dy < 0) dy = -dy;

    if (dx >= dy) {
        int step_x = x1 > x0 ? 1 : -1;
        int step_y = y1 > y0 ? 1 : -1;
        int err = dx / 2;
        for (; x != x1; x += step_x) {
            sht->buf[y * sht->bxsize + x] = col;
            err -= dy;
            if (err < 0) { y += step_y; err += dx; }
        }
    } else {
        int step_x = x1 > x0 ? 1 : -1;
        int step_y = y1 > y0 ? 1 : -1;
        int err = dy / 2;
        for (; y != y1; y += step_y) {
            sht->buf[y * sht->bxsize + x] = col;
            err -= dx;
            if (err < 0) { x += step_x; err += dy; }
        }
    }
    return;
}
