/* g_app_exit_esp0[2] - 应用退出时恢复内核栈 */
int g_app_exit_esp0[2];
