/* hzk16_installer.c - 将 HZK16 字库写入 WinDOS 文件系统镜像 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SECTOR_SIZE 512
#define FS_BLOCK_SIZE 512
#define HZK16_SIZE (217 * 1024)  /* 217KB */

/* 简单的 FAT12 文件系统操作 */
/* 这里我们直接修改 WinDOS.img，把 HZK16 追加到文件系统 */

int main(int argc, char *argv[])
{
    FILE *fp_img = NULL;
    FILE *fp_hzk = NULL;
    unsigned char *buf = NULL;
    long img_size, hzk_size;
    int ret = 1;

    if (argc < 3) {
        printf("用法: hzk16_installer.exe WinDOS.img HZK16\n");
        return 1;
    }

    /* 打开 HZK16 文件 */
    fp_hzk = fopen(argv[2], "rb");
    if (!fp_hzk) {
        printf("无法打开 %s\n", argv[2]);
        goto cleanup;
    }

    fseek(fp_hzk, 0, SEEK_END);
    hzk_size = ftell(fp_hzk);
    fseek(fp_hzk, 0, SEEK_SET);

    printf("HZK16 文件大小: %ld 字节 (%.1f KB)\n", hzk_size, hzk_size / 1024.0);

    /* 打开 WinDOS.img */
    fp_img = fopen(argv[1], "r+b");
    if (!fp_img) {
        printf("无法打开 %s\n", argv[1]);
        goto cleanup;
    }

    fseek(fp_img, 0, SEEK_END);
    img_size = ftell(fp_img);
    fseek(fp_img, 0, SEEK_SET);

    printf("WinDOS.img 当前大小: %ld 字节 (%.1f KB)\n", img_size, img_size / 1024.0);

    /* 简化方案：把 HZK16 追加到镜像末尾，并记录位置 */
    /* 在真实项目中，应该修改文件系统元数据来添加文件 */
    /* 这里我们先做一个简单的方案：把 HZK16 放在镜像末尾，OS 用固定地址访问 */

    /* 方案：修改 IPL 让它把 HZK16 加载到固定内存地址 */
    printf("\n建议方案：\n");
    printf("1. 修改 ipl10.nas，增加加载 HZK16 到内存 0x00100000 的代码\n");
    printf("2. 在 chinese_font.c 中直接从 0x00100000 读取字库\n");
    printf("3. 重新生成 WinDOS.img\n");

    ret = 0;

cleanup:
    if (buf) free(buf);
    if (fp_hzk) fclose(fp_hzk);
    if (fp_img) fclose(fp_img);
    return ret;
}
