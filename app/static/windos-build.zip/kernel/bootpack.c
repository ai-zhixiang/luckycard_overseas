/* WinDOS Bootpack file */
#include "bootpack.h"
#include <stdio.h>
int g_mx = 0, g_my = 0, g_mbtn = 0;

struct SHEET *g_sht_mouse = 0;  /* 全局鼠标图层（保持顶层用） */
struct SHEET *g_sht_back;
struct SHTCTL *g_shtctl = 0;
struct MEMMAN *g_memman = 0;
struct BOOTINFO *g_binfo = 0;
struct SHEET *g_sht_startmenu = 0;
int g_startmenu_visible = 0;
int *g_fat = 0;  /* FAT 缓冲区指针，将在 init 时分配 */

static int menu_hover = 0;

struct SHEET *g_key_win = 0;  /* 当前控制台输入目标 */
struct SHEET *g_active_window = 0;  /* 当前活跃（焦点）窗口 */
unsigned int g_memtotal = 0;  /* 总内存（供 explorer 等模块用）*/

/* 键盘扫描码 → 字符码转换表（原书 keytable0）*/
static char keytable0[0x80] = {
	0,   0,   '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '^', 0x08, 0,
	'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '@', '[', 0x0a, 0, 'A', 'S',
	'D', 'F', 'G', 'H', 'J', 'K', 'L', ';', ':', 0,   0,   ']', 'Z', 'X', 'C', 'V',
	'B', 'N', 'M', ',', '.', '/', 0,   '*', 0,   ' ', 0,   0,   0,   0,   0,   0,
	0,   0,   0,   0,   0,   0,   0,   '7', '8', '9', '-', '4', '5', '6', '+', '1',
	'2', '3', '0', '.', 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
	0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
	0,   0,   0,   0x5c, 0,  0,   0,   0,   0,   0,   0,   0,   0,   0x5c, 0,  0
};
/* 键盘扫描码 → 字符码转换表（原书 keytable1，Shift 按下时）*/
static char keytable1[0x80] = {
	0,   0,   '!', 0x22, '#', '$', '%', '&', 0x27, '(', ')', '~', '=', '~', 0x08, 0,
	'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '`', '{', 0x0a, 0, 'A', 'S',
	'D', 'F', 'G', 'H', 'J', 'K', 'L', '+', '*', 0,   0,   '}', 'Z', 'X', 'C', 'V',
	'B', 'N', 'M', '<', '>', '?', 0,   '*', 0,   ' ', 0,   0,   0,   0,   0,   0,
	0,   0,   0,   0,   0,   0,   0,   '7', '8', '9', '-', '4', '5', '6', '+', '1',
	'2', '3', '0', '.', 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
	0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
	0,   0,   0,   '_', 0,   0,   0,   0,   0,   0,   0,   0,   0,   '|', 0,   0
};

void make_window8(unsigned char *buf, int xsize, int ysize, char *title, char act);
void window_set_active(struct SHEET *sht, int active);
void BSOD(int stopcode, struct BOOTINFO *binfo);
static void BSOD320(int stopcode, struct BOOTINFO *binfo);
static void BSOD_HIGH(int stopcode, struct BOOTINFO *binfo, int scale);

void WinMain(void)
{
	static unsigned char keystatus[256] = {0};
	static int bsod_triggered = 0;

	struct BOOTINFO *binfo = (struct BOOTINFO *) ADR_BOOTINFO;
	char s[40], keybuf[32], mousebuf[128];
	int mx, my, i;
	unsigned int memtotal;
	struct MOUSE_DEC mdec;
	struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
	struct SHTCTL *shtctl;
	struct SHEET *sht_back, *sht_mouse, *sht_win;
	unsigned char *buf_back, buf_mouse[288], *buf_win;
	int j, x, y, mmx = -1, mmy = -1;
	int key_shift = 0, key_leds = (binfo->leds >> 4) & 7;
	struct SHEET *sht = 0;
	struct TASK *task_a;
	init_gdtidt();
	init_pic();
	io_sti();

	fifo8_init(&keyfifo, 32, keybuf);
	fifo8_init(&mousefifo, 128, mousebuf);
	init_pit();
	io_out8(PIC0_IMR, 0xf8);
	io_out8(PIC1_IMR, 0xef);

	init_keyboard();
	enable_mouse(&mdec);
	memtotal = memtest(0x00400000, 0xbfffffff);
	g_memtotal = memtotal;
	memman_init(memman);
	memman_free(memman, 0x00001000, 0x0009e000);
	memman_free(memman, 0x00400000, memtotal - 0x00400000);

	fs_init("WinDOS");

	init_palette();
	shtctl = shtctl_init(memman, binfo->vram, binfo->scrnx, binfo->scrny);
	task_a = task_init(memman);  /* 初始化多任务 */
	task_a->tss.ss0 = 1 * 8;
	task_a->tss.esp0 = (int) memman_alloc_4k(memman, 64 * 1024) + 64 * 1024;
	task_a->ds_base = 0;
	*((int *) 0x0fe4) = (int) shtctl;  /* API 用 */
	sht_back  = sheet_alloc(shtctl);
	sht_mouse = sheet_alloc(shtctl);
	sht_win = sheet_alloc(shtctl);
	g_shtctl = shtctl;
	g_sht_back = sht_back;
	g_sht_mouse = sht_mouse;
	g_memman = memman;
	g_binfo = binfo;
	buf_back = (unsigned char *) memman_alloc_4k(memman, binfo->scrnx * binfo->scrny);
	buf_win = (unsigned char *) memman_alloc_4k(memman, 160 * 68);
	if (buf_back == 0 || buf_win == 0) {
		BSOD(0x0000000A, binfo);
	}
	sheet_setbuf(sht_back, buf_back, binfo->scrnx, binfo->scrny, -1);
	sheet_setbuf(sht_mouse, buf_mouse, 16, 18, 99);
	sheet_setbuf(sht_win, buf_win, 160, 68, -1);
	init_screen8(buf_back, binfo->scrnx, binfo->scrny);
	init_mouse_cursor8(buf_mouse, 99);
	{
		unsigned char welcome_title[] = "欢迎";
		unsigned char welcome_line1[] = "欢迎使用";
		make_window8(buf_win, 160, 68, (char *)welcome_title, 1);
		{ int _i; for (_i = 0; welcome_title[_i]; _i++) sht_win->title[_i] = welcome_title[_i]; sht_win->title[_i] = 0; }
		putfonts8_asc_hz(buf_win, 160, 24, 28, COL8_000000, welcome_line1);
		/* "WinDOS!" 居右显示 */
		putfonts8_asc(buf_win, 160, 24, 44, COL8_000000, "WinDOS!");
	}
	show_boot_screen(shtctl, binfo);
	login_screen(shtctl, binfo);
	g_active_window = sht_win;  /* 初始活跃窗口 */
	sheet_slide(sht_back, 0, 0);
	mx = (binfo->scrnx - 16) / 2;
	my = (binfo->scrny - 28 - 16) / 2;
	sheet_slide(sht_mouse, mx, my);
	sheet_slide(sht_win, 80, 72);
	sheet_updown(sht_back,  0);
	sheet_updown(sht_win, 1);
	sheet_updown(sht_mouse, 20);
	sprintf(s, "(%3d, %3d)", mx, my);
	putfonts8_asc(buf_back, binfo->scrnx, 0, 0, COL8_FFFFFF, s);
	{
		unsigned char mem_label[] = "内存";
		unsigned char mem_free[] = "可用";
		sprintf(s, "%s %dMB %s : %dKB", mem_label,
			memtotal / (1024 * 1024), mem_free,
			memman_total(memman) / 1024);
	}
	putfonts8_asc_hz(buf_back, binfo->scrnx, 0, 32, COL8_FFFFFF, (unsigned char *)s);
	sheet_refresh(sht_back, 0, 0, binfo->scrnx, 48);

	init_startmenu();
	hzk16_load();

	/* 初始化 FAT 缓冲区并读取 FAT 表 */
	g_fat = (int *)memman_alloc_4k(memman, 4 * 2880);
	if (g_fat) file_readfat(g_fat, ADR_DISKIMG);

	*((int *) 0x0fec) = (int) &keyfifo;  /* 系统 FIFO 地址 */



	unsigned char test_hz[] = {0xBB, 0xB6, 0xD3, 0xAD, 0x00};
	putfonts8_asc_hz(buf_back, binfo->scrnx, 120, 0, COL8_FFFFFF, test_hz);

	/* 开机动画 + 登录界面 */


	/* 恢复桌面 */
	sheet_refreshmap(shtctl, 0, 0, binfo->scrnx, binfo->scrny, 0);
	sheet_refreshsub(shtctl, 0, 0, binfo->scrnx, binfo->scrny, 0, shtctl->top);

	for (;;) {
		io_cli();
		if (fifo8_status(&keyfifo) + fifo8_status(&mousefifo) == 0) {
			io_stihlt();
		} else {
			if (fifo8_status(&keyfifo) != 0) {
				i = fifo8_get(&keyfifo);
				io_sti();
				/* 键盘数据：仅 make（按下）才转字符，break（松开）不处理 */
				if (i < 0x80) {
					/* make 码：扫描码 -> 字符码（原书方式）*/
					char s0;
					if (key_shift == 0) {
						s0 = keytable0[i];
					} else {
						s0 = keytable1[i];
					}
					if ('A' <= s0 && s0 <= 'Z') {
						if (((key_leds & 4) == 0 && key_shift == 0) ||
							((key_leds & 4) != 0 && key_shift != 0)) {
							s0 += 0x20; /* 大写字母转小写 */
						}
					}
					if (s0 != 0 && g_key_win != 0 && g_key_win->task != 0) {
						fifo32_put(&g_key_win->task->fifo, s0 + 256);
					}
				}
				/* 跟踪 Shift 状态（makes 和 breaks 都要）*/
				if (i == 0x2a) { key_shift |= 1; }  /* 左Shift ON */
				if (i == 0x36) { key_shift |= 2; }  /* 右Shift ON */
				if (i == 0xaa) { key_shift &= ~1; } /* 左Shift OFF */
				if (i == 0xb6) { key_shift &= ~2; } /* 右Shift OFF */
				/* Caps Lock 切换 */
				if (i == 0x3a) {
					int j;
					key_leds ^= 4;
					/* 更新键盘 LED */
					for (j = 0; j < 0x2000; j++) {
						if ((io_in8(0x64) & 2) == 0) break;
					}
					io_out8(0x60, 0xED);
					for (j = 0; j < 0x2000; j++) {
						if ((io_in8(0x64) & 2) == 0) break;
					}
					io_out8(0x60, key_leds);
				}
				if (i < 0x80) {
					keystatus[i] = 1;
				} else {
					keystatus[i & 0x7F] = 0;
				}
				if (!bsod_triggered &&
					keystatus[0x1D] &&
					(keystatus[0x2A] || keystatus[0x36]) &&
					keystatus[0x30]) {
						bsod_triggered = 1;
						BSOD(0x00000042, binfo);
				}
				sprintf(s, "%02X", i);
				boxfill8(buf_back, binfo->scrnx, COL8_008484,  0, 16, 15, 31);
				putfonts8_asc(buf_back, binfo->scrnx, 0, 16, COL8_FFFFFF, s);
				sheet_refresh(sht_back, 0, 16, 16, 32);
			} else if (fifo8_status(&mousefifo) != 0) {
				i = fifo8_get(&mousefifo);
				io_sti();
				if (mouse_decode(&mdec, i) != 0) {

					if ((mdec.btn & 0x01) != 0) { /* 按下左键 */
						if (is_menu_open()) {
							/* 优先处理菜单点击 */
							int sel = menu_handle_click(shtctl, mx, my);
							if (sel == MENU_ACT_REFRESH) explorer_refresh();
							if (sel == MENU_ACT_NEW_DIR) explorer_new_dir();
							if (sel == MENU_ACT_NEW_TXT) explorer_new_file();
						} else if (mmx < 0) {
							/*如果处于通常模式*/
							/*按照从上到下的顺序寻找鼠标所指向的图层*/
							for (j = shtctl->top - 1; j > 0; j--) {
								sht = shtctl->sheets[j];
								x = mx - sht->vx0;
								y = my - sht->vy0;
								if (0 <= x && x < sht->bxsize && 0 <= y && y < sht->bysize) {
									if (sht->buf[y * sht->bxsize + x] != sht->col_inv) {
										sheet_updown(sht, shtctl->top - 1);
										/* 确保按钮和鼠标在窗口上方 */
										if (g_sht_btn && g_sht_btn->height >= 0 && sht != g_sht_btn && sht != g_sht_startmenu)
											sheet_updown(g_sht_btn, shtctl->top);
										if (g_sht_mouse && g_sht_mouse->height >= 0)
											sheet_updown(g_sht_mouse, shtctl->top);
										/* 焦点切换（排除开始菜单）*/
										if (sht != g_active_window && sht->title[0] != 0 && sht != g_sht_startmenu) {
											if (g_active_window)
											window_set_active(g_active_window, 0);
											window_set_active(sht, 1);
											g_active_window = sht;
										}
									if (3 <= x && x < sht->bxsize - 3 && 3 <= y && y < 21 && sht != g_sht_startmenu && sht != g_sht_btn) {
										mmx = mx; /*进入窗口移动模式*/
										mmy = my;
										}
										if (sht->bxsize - 21 <= x && x < sht->bxsize - 5 && 5 <= y && y < 19 && sht != g_sht_startmenu && sht != g_sht_btn) {
									/*点击 X 按钮*/
									if (sht == g_sht_explorer) {
										explorer_close();
									} else if (sht == g_sht_taskmgr) {
										taskmgr_close();
									} else if (sht == g_key_win) {
										close_console(sht);
								} else if (sht->task != 0 && (sht->flags & 0x10)) {
									/* .wda 应用窗口 → 只释放图层，不杀任务 */
									sheet_free(sht);
									mmx = -1;  /* 防止后续事件拖拽已释放的窗口 */
									} else {
										sheet_updown(sht, -1);
									}
									}
										break;
									}
								}
							}
						} else {
							/*如果处于窗口移动模式*/
							x = mx - mmx; /*计算鼠标的移动距离*/
							y = my - mmy;
							/* 小幅度移动不刷新，减少卡顿 */
							if (x < -1 || x > 1 || y < -1 || y > 1) {
								sheet_slide(sht, sht->vx0 + x, sht->vy0 + y);
								mmx = mx; /*更新为移动后的坐标*/
								mmy = my;
							}
						}
					} else {
						/*没有按下左键*/
						mmx = -1; /*返回通常模式*/
					}
					/* 任务管理器左键检测 — 仅当点击落在任务管理器上 */
					if ((mdec.btn & 0x01) != 0 && g_taskmgr_opened &&
						g_sht_taskmgr && !is_menu_open() && mmx < 0 &&
						sht == g_sht_taskmgr) {
						taskmgr_on_click(mx, my);
					}
					/* 左键点击资源管理器文件列表 — 仅当点击落在资源管理器上 */
					if ((mdec.btn & 0x01) != 0 && g_sht_explorer && g_explorer_opened && !is_menu_open() && mmx < 0 &&
						sht == g_sht_explorer) {
						explorer_open_file_at(mx, my);
					}
					/* 右键点击资源管理器 — 仅当点击落在资源管理器上 */
					if ((mdec.btn & 0x02) != 0 && g_sht_explorer && g_explorer_opened &&
						sht == g_sht_explorer) {
						int rx = mx - g_sht_explorer->vx0;
						int ry = my - g_sht_explorer->vy0;
						if (0 <= rx && rx < g_sht_explorer->bxsize && 0 <= ry && ry < g_sht_explorer->bysize) {
							if (is_menu_open()) hide_all_menus();
							/* 子菜单：新建 → (新建文件夹, 新建文本文档) */
							static struct MENU_ITEM sub_new[] = {
								{
									"新建文件夹",
									MENU_ACT_NEW_DIR, 0, 0
								},
								{
									"新建文本文档",
									MENU_ACT_NEW_TXT, 0, 0
								},
							};
							static struct MENU_ITEM explorer_menu[] = {
								{
									"新建",
									-2, sub_new, 2
								},
								{
									"刷新",
									MENU_ACT_REFRESH, 0, 0
								},
							};
							show_context_menu(mx, my, explorer_menu, 2);
						}
					}
					sprintf(s, "[lcr %4d %4d]", mdec.x, mdec.y);
					if ((mdec.btn & 0x01) != 0) { s[1] = 'L'; }
					if ((mdec.btn & 0x02) != 0) { s[3] = 'R'; }
					if ((mdec.btn & 0x04) != 0) { s[2] = 'C'; }
					boxfill8(buf_back, binfo->scrnx, COL8_008484, 32, 16, 32 + 15 * 8 - 1, 31);
					putfonts8_asc(buf_back, binfo->scrnx, 32, 16, COL8_FFFFFF, s);
					sheet_refresh(sht_back, 32, 16, 32 + 15 * 8, 32);
					mx += mdec.x;
					my += mdec.y;
					if (mx < 0) { mx = 0; }
					if (my < 0) { my = 0; }
					if (mx > binfo->scrnx - 16) { mx = binfo->scrnx - 1; }
					if (my > binfo->scrny - 16) { my = binfo->scrny - 1; }
					/* 菜单 hover 检测 */
					if (is_menu_open()) {
						menu_update_hover(mx, my);
					}
					sprintf(s, "(%3d, %3d)", mx, my);
					boxfill8(buf_back, binfo->scrnx, COL8_008484, 0, 0, 79, 15);
					putfonts8_asc(buf_back, binfo->scrnx, 0, 0, COL8_FFFFFF, s);
					sheet_refresh(sht_back, 0, 0, 80, 16);
					sheet_slide(sht_mouse, mx, my);

				/* 开始菜单 hover 检测 */
				if (g_startmenu_visible) {
					int menu_x = mx;
					int menu_y = my - (binfo->scrny - 440);
					int new_over = MENU_HOVER_NONE;
					if (menu_x >= 0 && menu_x < 180 && menu_y >= 0 && menu_y < 400) {
						if (menu_y >= 12 && menu_y <= 41) new_over = MENU_HOVER_COMP;
						else if (menu_y >= 42 && menu_y <= 71) new_over = MENU_HOVER_DOCS;
						else if (menu_y >= 72 && menu_y <= 101) new_over = MENU_HOVER_SEARCH;
						else if (menu_y >= 102 && menu_y <= 131) new_over = MENU_HOVER_TASKMGR;
						else if (menu_y >= 132 && menu_y <= 161) new_over = MENU_HOVER_CONSOLE;
					}
					if (new_over != menu_hover) {
						menu_hover = new_over;
						refresh_startmenu(menu_hover);
					}
				}

									/* 开始按钮点击检测 */
				if ((mdec.btn & 0x01) != 0) {
					if (mx >= 0 && mx <= 60 && my >= binfo->scrny - 42 && my <= binfo->scrny - 2) {
						if (g_startmenu_visible) {
							sheet_updown(g_sht_startmenu, -1);
							g_startmenu_visible = 0;
						} else {
							sheet_updown(g_sht_startmenu, 3);
							g_startmenu_visible = 1;
						}
						update_btn_state(g_startmenu_visible);
					}
					/* 菜单项点击 */
					if (g_startmenu_visible && menu_hover != 0) {
						int mx2 = mx, my2 = my - (binfo->scrny - 440);
						if (mx2 >= 6 && mx2 < 178 && my2 >= 24 && my2 <= 157) {
							if (menu_hover == MENU_HOVER_COMP) {
								explorer_open();
							if (g_sht_explorer) {
								if (g_active_window) window_set_active(g_active_window, 0);
								window_set_active(g_sht_explorer, 1);
								g_active_window = g_sht_explorer;
							}
							} else if (menu_hover == MENU_HOVER_DOCS) {
								BSOD(0x00000002, binfo);
							} else if (menu_hover == MENU_HOVER_SEARCH) {
								BSOD(0x00000003, binfo);
							} else if (menu_hover == MENU_HOVER_TASKMGR) {
								taskmgr_open();
								if (g_sht_taskmgr) {
									if (g_active_window) window_set_active(g_active_window, 0);
									window_set_active(g_sht_taskmgr, 1);
									g_active_window = g_sht_taskmgr;
								}
							} else if (menu_hover == MENU_HOVER_CONSOLE) {
								g_key_win = open_console(shtctl, memtotal);
								sheet_slide(g_key_win, 32, 4);
								sheet_updown(g_key_win, shtctl->top);
								if (g_active_window) window_set_active(g_active_window, 0);
								window_set_active(g_key_win, 1);
								g_active_window = g_key_win;
							} else if (menu_hover == MENU_HOVER_SHUTDOWN) {
								BSOD(0x00000001, binfo);
							} else if (menu_hover == MENU_HOVER_RESTART) {
								io_out8(0x64, 0xFE);
								for (;;) io_hlt();
							}
							sheet_updown(g_sht_startmenu, -1);
							g_startmenu_visible = 0;
							menu_hover = 0;
							refresh_startmenu(0);
							update_btn_state(0);
						}
					}
				}
			}
		}
		/* 每帧确保按钮和鼠标在顶层 */
		if (g_sht_btn && g_sht_btn->height >= 0 && g_sht_btn->height < shtctl->top)
			sheet_updown(g_sht_btn, shtctl->top);
		if (g_sht_mouse && g_sht_mouse->height >= 0 && g_sht_mouse->height < shtctl->top)
			sheet_updown(g_sht_mouse, shtctl->top);
		}
	}
}

/* ===== 控制台相关函数 ===== */

struct TASK *open_constask(struct SHEET *sht, unsigned int memtotal)
{
	struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
	struct TASK *task = task_alloc();
	int *cons_fifo = (int *) memman_alloc_4k(memman, 128 * 4);
	/* 先初始化 FIFO，再运行任务（确保任务启动时 FIFO 就绪）*/
	fifo32_init(&task->fifo, 128, cons_fifo, task);
	
	task->cons_stack = memman_alloc_4k(memman, 64 * 1024);
	task->tss.esp = task->cons_stack + 64 * 1024 - 12;
	task->tss.eip = (int) &console_task;
	task->tss.es = 1 * 8;
	task->tss.cs = 2 * 8;
	task->tss.ss = 1 * 8;
	task->tss.ds = 1 * 8;
	task->tss.fs = 1 * 8;
	task->tss.gs = 1 * 8;
	*((int *) (task->tss.esp + 4)) = (int) sht;
	*((int *) (task->tss.esp + 8)) = memtotal;
	/* 用 level 0（和 task_a 同级）确保能获取时间片 */
	task_run(task, 0, 2);
	return task;
}

struct SHEET *open_console(struct SHTCTL *shtctl, unsigned int memtotal)
{
	struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
	struct SHEET *sht = sheet_alloc(shtctl);
	unsigned char *buf = (unsigned char *) memman_alloc_4k(memman, 256 * 165);
	sheet_setbuf(sht, buf, 256, 165, -1);
	{
		unsigned char cons_title[] = "命令行";
		make_window8(buf, 256, 165, (char *)cons_title, 1);
		{ int _i; for (_i = 0; cons_title[_i]; _i++) sht->title[_i] = cons_title[_i]; sht->title[_i] = 0; }
	}
	/* 绘制黑色文本区域 */
	boxfill8(buf, 256, COL8_000000, 8, 28, 8 + 240 - 1, 28 + 128 - 1);
	sht->task = open_constask(sht, memtotal);
	sht->flags |= 0x20;	/* 有光标 */
	return sht;
}

void close_constask(struct TASK *task)
{
	struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
	task_sleep(task);
	memman_free_4k(memman, task->cons_stack, 64 * 1024);
	memman_free_4k(memman, (int) task->fifo.buf, 128 * 4);
	task->flags = 0;
	return;
}

void close_console(struct SHEET *sht)
{
	struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
	close_constask(sht->task);
	sheet_free(sht);
	if (sht == g_key_win) g_key_win = 0;
	if (sht == g_active_window) g_active_window = 0;
	return;
}

void make_window8(unsigned char *buf, int xsize, int ysize, char *title, char act)
{
	if (buf == 0) return;
	static char closebtn[14][16] = {
		"OOOOOOOOOOOOOOOO",
		"OQQQQQQQQQQQQQ$O",
		"OQQQQQQQQQQQQQ$O",
		"OQQQ@QQQQQ@QQQ$O",
		"OQQQQ@QQQ@QQQQ$O",
		"OQQQQQ@Q@QQQQQ$O",
		"OQQQQQQ@QQQQQQ$O",
		"OQQQQQ@Q@QQQQQ$O",
		"OQQQQ@QQQ@QQQQ$O",
		"OQQQ@QQQQQ@QQQ$O",
		"OQQQQQQQQQQQQQ$O",
		"OQQQQQQQQQQQQQ$O",
		"O$$$$$$$$$$$$$$O",
		"OOOOOOOOOOOOOOOO"
	};
	int x, y;
	char c;
	boxfill8(buf, xsize, COL8_C6C6C6, 0,         0,         xsize - 1, 0        );
	boxfill8(buf, xsize, COL8_FFFFFF, 1,         1,         xsize - 2, 1        );
	boxfill8(buf, xsize, COL8_C6C6C6, 0,         0,         0,         ysize - 1);
	boxfill8(buf, xsize, COL8_FFFFFF, 1,         1,         1,         ysize - 2);
	boxfill8(buf, xsize, COL8_FFFFFF, xsize - 2, 1,         xsize - 2, ysize - 2);
	boxfill8(buf, xsize, COL8_C6C6C6, xsize - 1, 0,         xsize - 1, ysize - 1);
	boxfill8(buf, xsize, COL8_FFFFFF, 2,         2,         xsize - 3, ysize - 3);
	boxfill8(buf, xsize, COL8_FFFFFF, 3, 3, xsize - 4, 20);
	boxfill8(buf, xsize, COL8_FFFFFF, 1,         ysize - 2, xsize - 2, ysize - 2);
	boxfill8(buf, xsize, COL8_C6C6C6, 0,         ysize - 1, xsize - 1, ysize - 1);
	putfonts8_asc_hz(buf, xsize, 24, 4, COL8_000000, (unsigned char *)title);
	for (y = 0; y < 14; y++) {
		for (x = 0; x < 16; x++) {
			c = closebtn[y][x];
			if (c == '@') {
				c = COL8_000000;
			} else if (c == '$') {
				c = COL8_FFFFFF;
			} else if (c == 'Q') {
				c = COL8_FFFFFF;
			} else {
				c = COL8_FFFFFF;
			}
			buf[(5 + y) * xsize + (xsize - 21 + x)] = c;
		}
	}
	return;
}

/* 窗口焦点管理 */

void window_set_active(struct SHEET *sht, int active)
{
	static char closebtn[14][16] = {
		"OOOOOOOOOOOOOOOO",
		"OQQQQQQQQQQQQQ$O",
		"OQQQQQQQQQQQQQ$O",
		"OQQQ@QQQQQ@QQQ$O",
		"OQQQQ@QQQ@QQQQ$O",
		"OQQQQQ@Q@QQQQQ$O",
		"OQQQQQQ@QQQQQQ$O",
		"OQQQQQ@Q@QQQQQ$O",
		"OQQQQ@QQQ@QQQQ$O",
		"OQQQ@QQQQQ@QQQ$O",
		"OQQQQQQQQQQQQQ$O",
		"OQQQQQQQQQQQQQ$O",
		"O$$$$$$$$$$$$$$O",
		"OOOOOOOOOOOOOOOO"
	};
	if (sht == g_sht_btn || sht == g_sht_startmenu) return;
	int xsize = sht->bxsize;
	unsigned char *buf = sht->buf;
	int x, y;
	char c;

	/* 重绘标题栏背景 */
	boxfill8(buf, xsize, active ? COL8_FFFFFF : COL8_FFFFFF, 3, 3, xsize - 4, 20);
	/* 重绘标题文字 */
	if (sht->title[0] != 0) {
		putfonts8_asc_hz(buf, xsize, 24, 4, COL8_000000, (unsigned char *)sht->title);
	}
	/* 重绘关闭按钮 */
	for (y = 0; y < 14; y++) {
		for (x = 0; x < 16; x++) {
			c = closebtn[y][x];
			if (c == '@')      c = COL8_000000;
			else if (c == '$') c = COL8_FFFFFF;
			else if (c == 'Q') c = COL8_FFFFFF;
			else               c = COL8_FFFFFF;
			buf[(5 + y) * xsize + (xsize - 21 + x)] = c;
		}
	}
	sheet_refresh(sht, 0, 0, xsize, 21);
}

static void put_pixel_scaled(unsigned char *vram, int xsize, int x, int y, int scale, unsigned char color)
{
	int i, j;
	for (i = 0; i < scale; i++) {
		for (j = 0; j < scale; j++) {
			vram[(y + i) * xsize + (x + j)] = color;
		}
	}
}

static void putfont8_scaled(unsigned char *vram, int xsize, int x, int y, int scale, unsigned char color, unsigned char *font)
{
	int i, j;
	for (i = 0; i < 16; i++) {
		unsigned char d = font[i];
		for (j = 0; j < 8; j++) {
			if (d & 0x80) {
				put_pixel_scaled(vram, xsize, x + j * scale, y + i * scale, scale, color);
			}
			d <<= 1;
		}
	}
}

static void putfonts8_scaled(unsigned char *vram, int xsize, int x, int y, int scale, unsigned char color, char *s)
{
	extern unsigned char hankaku[4096];
	int i = 0;
	while (s[i] != 0) {
		putfont8_scaled(vram, xsize, x + i * 8 * scale, y, scale, color, hankaku + s[i] * 16);
		i++;
	}
}

void BSOD(int stopcode, struct BOOTINFO *binfo)
{
	unsigned char *vram = binfo->vram;
	int xsize = binfo->scrnx;
	int ysize = binfo->scrny;
	int scale;
	io_cli();
	boxfill8(vram, xsize, COL8_0000FF, 0, 0, xsize - 1, ysize - 1);
	if (xsize < 640) { scale = 1; } else { scale = 2; }
	if (scale == 1) { BSOD320(stopcode, binfo); }
	else { BSOD_HIGH(stopcode, binfo, scale); }
	for (;;) io_hlt();
}

static void BSOD320(int stopcode, struct BOOTINFO *binfo)
{
	unsigned char *vram;
	int xsize, ysize;
	char stpcode[32];
	if (binfo == 0) { for (;;) io_hlt(); }
	vram = binfo->vram;
	xsize = binfo->scrnx;
	ysize = binfo->scrny;
	io_cli();
	if (g_shtctl) {
		int i;
		for (i = 0; i <= g_shtctl->top; i++) {
			if (g_shtctl->sheets[i] != g_sht_back) {
				sheet_free(g_shtctl->sheets[i]);
			}
		}
	}
	boxfill8(vram, xsize, COL8_0000FF, 0, 0, xsize - 1, ysize - 1);
	putfonts8_asc(vram, xsize, 10, 10, COL8_FFFFFF, "A problem has been detected and WinDOS");
	putfonts8_asc(vram, xsize, 10, 10+16*1, COL8_FFFFFF, "has been shut down to prevent damage ");
	putfonts8_asc(vram, xsize, 10, 10+16*2, COL8_FFFFFF, "to your computer.");
	putfonts8_asc(vram, xsize, 10, 10+16*4, COL8_FFFFFF, "*** STOP ***:");
	sprintf(stpcode, "0x%08X", stopcode);
	putfonts8_asc(vram, xsize, 10 + 14 * 8, 10+16*4, COL8_FFFFFF, stpcode);
	for (;;) io_hlt();
}

static void BSOD_HIGH(int stopcode, struct BOOTINFO *binfo, int scale)
{
	unsigned char *vram;
	int xsize, ysize;
	char stpcode[32];
	if (binfo == 0) { for (;;) io_hlt(); }
	vram = binfo->vram;
	xsize = binfo->scrnx;
	ysize = binfo->scrny;
	io_cli();
	if (g_shtctl) {
		int i;
		for (i = 0; i <= g_shtctl->top; i++) {
			if (g_shtctl->sheets[i] != g_sht_back) {
				sheet_free(g_shtctl->sheets[i]);
			}
		}
	}
	boxfill8(vram, xsize, COL8_0000FF, 0, 0, xsize - 1, ysize - 1);
	{
		int x = 20, y = 60, step = 24 * scale;
		putfonts8_scaled(vram, xsize, x, y, scale, COL8_FFFFFF, "A problem has been detected and WinDOS has been shut down");
		y += step;
		putfonts8_scaled(vram, xsize, x, y, scale, COL8_FFFFFF, "to prevent damage to your computer. ");
		y += step;
		putfonts8_scaled(vram, xsize, x, y, scale, COL8_FFFFFF, "If this is the first time you've seen this stop screen,");
		y += step;
		putfonts8_scaled(vram, xsize, x, y, scale, COL8_FFFFFF, "restart your computer. ");
		y += step;
		putfonts8_scaled(vram, xsize, x, y, scale, COL8_FFFFFF, "If this screen appears again, check for viruses on your ");
		y += step;
		putfonts8_scaled(vram, xsize, x, y, scale, COL8_FFFFFF, "computer.");
		y += 48 * scale;
		putfonts8_scaled(vram, xsize, x, y, scale, COL8_FFFFFF, "*** STOP ***:");
		sprintf(stpcode, "0x%08X", stopcode);
		putfonts8_scaled(vram, xsize, x + 14 * 8 * scale, y, scale, COL8_FFFFFF, stpcode);
	}
	for (;;) io_hlt();
}
