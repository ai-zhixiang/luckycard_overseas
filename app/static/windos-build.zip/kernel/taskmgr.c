/* taskmgr.c - WinDOS 任务管理器 */
#include "bootpack.h"
#include <stdio.h>

struct SHEET *g_sht_taskmgr = 0;
unsigned char *g_buf_taskmgr = 0;
int g_taskmgr_opened = 0;

static int g_tm_w = 380, g_tm_h = 260;
static int g_selected = -1;

#define TM_TITLE_H   21
#define TM_HEADER_Y  24
#define TM_LIST_Y    42
#define TM_ROW_H     18
#define TM_BTN_Y     232
#define TM_MAX_VISIBLE 10

/* 绘制窗口内容 */
static void draw_tm_content(void)
{
	unsigned char *buf = g_buf_taskmgr;
	int xsize = g_tm_w, ysize = g_tm_h;
	int i, y, count = 0;
	struct TASK *task;

	/* 清空内容区 */
	boxfill8(buf, xsize, COL8_FFFFFF, 3, 21, xsize - 4, ysize - 4);

	/* 表头 */
	boxfill8(buf, xsize, COL8_C6C6C6, 4, 22, xsize - 5, 39);
	putfonts8_asc(buf, xsize, 8,  TM_HEADER_Y + 1, COL8_000000, (unsigned char *)"ID");
	putfonts8_asc(buf, xsize, 40, TM_HEADER_Y + 1, COL8_000000, (unsigned char *)"Lv");
	putfonts8_asc(buf, xsize, 64, TM_HEADER_Y + 1, COL8_000000, (unsigned char *)"Pri");
	putfonts8_asc(buf, xsize, 92, TM_HEADER_Y + 1, COL8_000000, (unsigned char *)"Flags");
	putfonts8_asc(buf, xsize, 140, TM_HEADER_Y + 1, COL8_000000, (unsigned char *)"Kern");
	putfonts8_asc(buf, xsize, 180, TM_HEADER_Y + 1, COL8_000000, (unsigned char *)"Sys");
	putfonts8_asc(buf, xsize, 220, TM_HEADER_Y + 1, COL8_000000, (unsigned char *)"DS Base");

	/* 表头分隔线 */
	boxfill8(buf, xsize, COL8_848484, 4, 39, xsize - 5, 39);

	/* 遍历所有任务 */
	for (i = 0; i < MAX_TASKS; i++) {
		task = &taskctl->tasks0[i];
		if (task->flags == 0) continue;

		y = TM_LIST_Y + count * TM_ROW_H;
		if (count >= TM_MAX_VISIBLE) break;

		/* 选中高亮 */
		if (i == g_selected) {
			boxfill8(buf, xsize, COL8_000084, 6, y, xsize - 7, y + TM_ROW_H - 1);
			/* 白色文字 */
			char s[32];
			sprintf(s, "%3d", i);
			putfonts8_asc(buf, xsize, 8,  y + 1, COL8_FFFFFF, (unsigned char *)s);
			sprintf(s, "%2d", task->level);
			putfonts8_asc(buf, xsize, 40, y + 1, COL8_FFFFFF, (unsigned char *)s);
			sprintf(s, "%2d", task->priority);
			putfonts8_asc(buf, xsize, 64, y + 1, COL8_FFFFFF, (unsigned char *)s);
			sprintf(s, "0x%02X", task->flags);
			putfonts8_asc(buf, xsize, 92, y + 1, COL8_FFFFFF, (unsigned char *)s);
			putfonts8_asc(buf, xsize, 140, y + 1, COL8_FFFFFF,
				(unsigned char *)(task->is_kernel ? "Yes" : " No"));
			putfonts8_asc(buf, xsize, 180, y + 1, COL8_FFFFFF,
				(unsigned char *)(task->is_system ? "Yes" : " No"));
			sprintf(s, "0x%08X", task->ds_base);
			putfonts8_asc(buf, xsize, 220, y + 1, COL8_FFFFFF, (unsigned char *)s);
		} else {
			/* 交替行背景 */
			int bg = (count & 1) ? COL8_C6C6C6 : COL8_FFFFFF;
			boxfill8(buf, xsize, bg, 6, y, xsize - 7, y + TM_ROW_H - 1);
			char s[32];
			sprintf(s, "%3d", i);
			putfonts8_asc(buf, xsize, 8,  y + 1, COL8_000000, (unsigned char *)s);
			sprintf(s, "%2d", task->level);
			putfonts8_asc(buf, xsize, 40, y + 1, COL8_000000, (unsigned char *)s);
			sprintf(s, "%2d", task->priority);
			putfonts8_asc(buf, xsize, 64, y + 1, COL8_000000, (unsigned char *)s);
			sprintf(s, "0x%02X", task->flags);
			putfonts8_asc(buf, xsize, 92, y + 1, COL8_000000, (unsigned char *)s);
			putfonts8_asc(buf, xsize, 140, y + 1, COL8_000000,
				(unsigned char *)(task->is_kernel ? "Yes" : " No"));
			putfonts8_asc(buf, xsize, 180, y + 1, COL8_000000,
				(unsigned char *)(task->is_system ? "Yes" : " No"));
			sprintf(s, "0x%08X", task->ds_base);
			putfonts8_asc(buf, xsize, 220, y + 1, COL8_000000, (unsigned char *)s);
		}
		count++;
	}

	/* 底部分隔线 */
	boxfill8(buf, xsize, COL8_848484, 4, TM_BTN_Y - 1, xsize - 5, TM_BTN_Y - 1);

	/* [结束任务] 按钮 */
	{
		int bx = 8, by = TM_BTN_Y + 2, bw = 80, bh = 18;
		boxfill8(buf, xsize, COL8_C6C6C6, bx, by, bx + bw, by + bh);
		boxfill8(buf, xsize, COL8_FFFFFF, bx, by, bx + bw, by);
		boxfill8(buf, xsize, COL8_FFFFFF, bx, by, bx, by + bh);
		boxfill8(buf, xsize, COL8_848484, bx, by + bh, bx + bw, by + bh);
		boxfill8(buf, xsize, COL8_848484, bx + bw, by, bx + bw, by + bh);
		putfonts8_asc_hz(buf, xsize, bx + 10, by + 2, COL8_000000,
			(unsigned char *)"\xbd\xe1\xca\xf8\xc8\xce\xce\xf1\x00");
	}
	/* [刷新] 按钮 */
	{
		int bx = 96, by = TM_BTN_Y + 2, bw = 60, bh = 18;
		boxfill8(buf, xsize, COL8_C6C6C6, bx, by, bx + bw, by + bh);
		boxfill8(buf, xsize, COL8_FFFFFF, bx, by, bx + bw, by);
		boxfill8(buf, xsize, COL8_FFFFFF, bx, by, bx, by + bh);
		boxfill8(buf, xsize, COL8_848484, bx, by + bh, bx + bw, by + bh);
		boxfill8(buf, xsize, COL8_848484, bx + bw, by, bx + bw, by + bh);
		putfonts8_asc_hz(buf, xsize, bx + 14, by + 2, COL8_000000,
			(unsigned char *)"\xcb\xa2\xd0\xc2\x00");
	}
	/* 状态行 */
	{
		char s[40];
		sprintf(s, "%d tasks active", count);
		putfonts8_asc(buf, xsize, 170, TM_BTN_Y + 5, COL8_000000, (unsigned char *)s);
	}
}

/* 全窗口重绘 */
static void redraw_tm(void)
{
	if (!g_buf_taskmgr || !g_sht_taskmgr) return;
	make_window8(g_buf_taskmgr, g_tm_w, g_tm_h, "任务管理器", 1);
	{ int _i; char *_t = "任务管理器"; for (_i = 0; _t[_i]; _i++) g_sht_taskmgr->title[_i] = _t[_i]; g_sht_taskmgr->title[_i] = 0; }
	draw_tm_content();
	sheet_refresh(g_sht_taskmgr, 0, 0, g_tm_w, g_tm_h);
}

/* 打开任务管理器 */
void taskmgr_open(void)
{
	int scrnx, scrny, pos_x, pos_y;

	if (g_taskmgr_opened) {
		sheet_updown(g_sht_taskmgr, 3);
		return;
	}

	scrnx = g_binfo->scrnx;
	scrny = g_binfo->scrny;

	pos_x = (scrnx - g_tm_w) / 2;
	pos_y = (scrny - g_tm_h) / 2;
	if (pos_x < 2) pos_x = 2;
	if (pos_y < 2) pos_y = 2;

	g_sht_taskmgr = sheet_alloc(g_shtctl);
	g_buf_taskmgr = (unsigned char *)memman_alloc_4k(g_memman, g_tm_w * g_tm_h);
	if (g_buf_taskmgr == 0) return;

	sheet_setbuf(g_sht_taskmgr, g_buf_taskmgr, g_tm_w, g_tm_h, 0xFF);
	g_selected = -1;

	redraw_tm();
	sheet_slide(g_sht_taskmgr, pos_x, pos_y);
	sheet_updown(g_sht_taskmgr, 3);
	g_taskmgr_opened = 1;
}

/* 关闭任务管理器 */
void taskmgr_close(void)
{
	if (!g_taskmgr_opened) return;
	g_taskmgr_opened = 0;
	if (g_buf_taskmgr) {
		memman_free_4k(g_memman, (unsigned int) g_buf_taskmgr, g_tm_w * g_tm_h);
		g_buf_taskmgr = 0;
	}
	if (g_sht_taskmgr) {
		sheet_free(g_sht_taskmgr);
		g_sht_taskmgr = 0;
	}
}

/* 点击处理 */
void taskmgr_on_click(int mx, int my)
{
	int x, y;
	struct TASK *task;

	if (!g_taskmgr_opened || !g_sht_taskmgr) return;

	x = mx - g_sht_taskmgr->vx0;
	y = my - g_sht_taskmgr->vy0;

	/* 按钮区域 */
	if (y >= TM_BTN_Y - 2 && y <= TM_BTN_Y + 20) {
		if (x >= 8 && x <= 88) {
			/* 结束任务 */
			if (g_selected >= 0 && g_selected < MAX_TASKS) {
				task = &taskctl->tasks0[g_selected];
				if (task->flags != 0 && task->flags != 2) {
					/* 不能杀内核主任务(flags=2) */
					if (task->is_system && task->bsod_on_kill) {
						/* 系统保护进程被干掉 → BSOD */
						/* 先杀再蓝屏 */
					}
					task_sleep(task);
					task->flags = 0;  /* 释放 TSS 槽 */
					g_selected = -1;
					redraw_tm();
				}
			}
		} else if (x >= 96 && x <= 156) {
			/* 刷新 */
			redraw_tm();
		}
		return;
	}

	/* 任务列表点击 */
	if (y >= TM_LIST_Y && y < TM_LIST_Y + TM_MAX_VISIBLE * TM_ROW_H) {
		int row = (y - TM_LIST_Y) / TM_ROW_H;
		int count = 0, i;
		for (i = 0; i < MAX_TASKS; i++) {
			if (taskctl->tasks0[i].flags == 0) continue;
			if (count == row) {
				g_selected = i;
				redraw_tm();
				return;
			}
			count++;
		}
	}
}
