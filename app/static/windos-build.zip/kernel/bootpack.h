#ifndef BOOTPACK_H
#define BOOTPACK_H

/* asmhead.nas */
struct BOOTINFO { /* 0x0ff0-0x0fff */
	char cyls; /* 启动区读磁盘读到此为止 */
	char leds; /* 启动时键盘的LED的状态 */
	char vmode; /* 显卡模式为多少位彩色 */
	char reserve;
	short scrnx, scrny; /* 画面分辨率 */
	char *vram;
};
#define ADR_BOOTINFO	0x00000ff0
#define ADR_DISKIMG		0x00100000

/* TSS 和多任务 */
#define MAX_TASKS        1000
#define MAX_TASKS_LV     100
#define MAX_TASKLEVELS   10
#define TASK_GDT0        3
#define AR_TSS32         0x0089

/* FIFO32 定义（必须在 TASK 之前，因为 TASK 包含 FIFO32） */
struct FIFO32 {
	int *buf;
	int p, q, size, free, flags;
	struct TASK *task;
};

struct TSS32 {
	int backlink, esp0, ss0, esp1, ss1, esp2, ss2, cr3;
	int eip, eflags, eax, ecx, edx, ebx, esp, ebp, esi, edi;
	int es, cs, ss, ds, fs, gs;
	int ldtr, iomap;
};

/* 段描述符和门描述符（必须在 TASK 之前，因为 TASK 包含 ldt 字段） */
struct SEGMENT_DESCRIPTOR {
	short limit_low, base_low;
	char base_mid, access_right;
	char limit_high, base_high;
};
struct GATE_DESCRIPTOR {
	short offset_low, selector;
	char dw_count, access_right;
	short offset_high;
};

struct CONSOLE {
	struct SHEET *sht;
	int cur_x, cur_y, cur_c;
	struct TIMER *timer;
};

struct FILEHANDLE {
	char *buf;
	int size;
	int pos;
};

struct TASK {
	int sel, flags;
	int level, priority;
	int ds_base;
	int is_kernel;       /* 是否为内核进程 */
	int bsod_on_kill;    /* 被强制干掉后是否蓝屏 */
	int is_system;       /* 是否为系统进程（0=忽略前两项） */
	int heap_top;        /* 堆顶（相对 app_mem 的偏移，下一个 malloc 位置）*/
	int cons_stack;      /* 控制台栈指针 */
	struct FIFO32 fifo;
	struct TSS32 tss;
	unsigned short sel_ldt;     /* LDT 段选择器（GDT 索引） */
	struct SEGMENT_DESCRIPTOR ldt[2];  /* 0=代码段 1=数据段 */
	struct CONSOLE *cons;       /* 控制台 */
	struct FILEHANDLE *fhandle; /* 文件句柄数组 */
	int *fat;                   /* FAT 表 */
	char *cmdline;              /* 命令行 */
	unsigned char langmode, langbyte1;
};

struct TASKLEVEL {
	int running;
	int now;
	struct TASK *tasks[MAX_TASKS_LV];
};

struct TASKCTL {
	int now_lv;
	char lv_change;
	struct TASKLEVEL level[MAX_TASKLEVELS];
	struct TASK tasks0[MAX_TASKS];
};

/* naskfunc.nas */
void io_hlt(void);
void io_cli(void);
void io_sti(void);
void io_stihlt(void);
int io_in8(int port);
void io_out8(int port, int data);
int io_load_eflags(void);
void io_store_eflags(int eflags);
void load_gdtr(int limit, int addr);
void load_idtr(int limit, int addr);
void load_tr(int tr);
void load_ldt(int ldt);
int load_cr0(void);
void store_cr0(int cr0);
void asm_inthandler20(void);
void asm_inthandler21(void);
void asm_inthandler27(void);
void asm_inthandler2c(void);
void asm_inthandler08(void);  /* #DF */
void asm_inthandler0d(void);  /* #GP */
int *inthandler0d(int *esp);
unsigned int memtest_sub(unsigned int start, unsigned int end);

/* fifo.c */
struct FIFO8 {
	unsigned char *buf;
	int p, q, size, free, flags;
};
void fifo8_init(struct FIFO8 *fifo, int size, unsigned char *buf);
int fifo8_put(struct FIFO8 *fifo, unsigned char data);
int fifo8_get(struct FIFO8 *fifo);
int fifo8_status(struct FIFO8 *fifo);

/* fifo32 函数声明 */
void fifo32_init(struct FIFO32 *fifo, int size, int *buf, struct TASK *task);
int fifo32_put(struct FIFO32 *fifo, int data);
int fifo32_get(struct FIFO32 *fifo);
int fifo32_status(struct FIFO32 *fifo);

/* graphic.c */
void init_palette(void);
void set_palette(int start, int end, unsigned char *rgb);
void boxfill8(unsigned char *vram, int xsize, unsigned char c, int x0, int y0, int x1, int y1);
void init_screen8(char *vram, int x, int y);
void putfont8(char *vram, int xsize, int x, int y, char c, char *font);
void putfonts8_asc(char *vram, int xsize, int x, int y, char c, unsigned char *s);
void init_mouse_cursor8(char *mouse, char bc);
void putblock8_8(char *vram, int vxsize, int pxsize,
	int pysize, int px0, int py0, char *buf, int bxsize);
void make_window8(unsigned char *buf, int xsize, int ysize, char *title, char act);
#define COL8_000000		0
#define COL8_FF0000		1
#define COL8_00FF00		2
#define COL8_FFFF00		3
#define COL8_0000FF		4
#define COL8_FF00FF		5
#define COL8_00FFFF		6
#define COL8_FFFFFF		7
#define COL8_C6C6C6		8
#define COL8_840000		9
#define COL8_008400		10
#define COL8_848400		11
#define COL8_000084		12
#define COL8_840084		13
#define COL8_008484		14
#define COL8_848484		15

/* dsctbl.c */
void init_gdtidt(void);
void set_segmdesc(struct SEGMENT_DESCRIPTOR *sd, unsigned int limit, int base, int ar);
void set_gatedesc(struct GATE_DESCRIPTOR *gd, int offset, int selector, int ar);
#define ADR_IDT			0x0026f800
#define LIMIT_IDT		0x000007ff
#define ADR_GDT			0x00270000
#define LIMIT_GDT		0x0000ffff
#define ADR_BOTPAK		0x00280000
#define LIMIT_BOTPAK	0x0007ffff
#define AR_DATA32_RW	0x4092
#define AR_CODE32_ER	0x409a
#define AR_INTGATE32	0x008e
#define AR_LDT      0x0082

/* int.c */
void init_pic(void);
void inthandler27(int *esp);
#define PIC0_ICW1		0x0020
#define PIC0_OCW2		0x0020
#define PIC0_IMR		0x0021
#define PIC0_ICW2		0x0021
#define PIC0_ICW3		0x0021
#define PIC0_ICW4		0x0021
#define PIC1_ICW1		0x00a0
#define PIC1_OCW2		0x00a0
#define PIC1_IMR		0x00a1
#define PIC1_ICW2		0x00a1
#define PIC1_ICW3		0x00a1
#define PIC1_ICW4		0x00a1

/* keyboard.c */
void inthandler21(int *esp);
void wait_KBC_sendready(void);
void init_keyboard(void);
extern struct FIFO8 keyfifo;
#define PORT_KEYDAT		0x0060
#define PORT_KEYCMD		0x0064

/* mouse.c */
struct MOUSE_DEC {
	unsigned char buf[3], phase;
	int x, y, btn;
};
void inthandler2c(int *esp);
void enable_mouse(struct MOUSE_DEC *mdec);
int mouse_decode(struct MOUSE_DEC *mdec, unsigned char dat);
extern struct FIFO8 mousefifo;

/* memory.c */
#define MEMMAN_FREES 4090 /* 大约是32KB*/
#define MEMMAN_ADDR			0x003c0000

struct FREEINFO { /* 可用信息 */
	unsigned int addr, size;
};
struct MEMMAN { /* 内存管理 */
	int frees, maxfrees, lostsize, losts;
	struct FREEINFO free[MEMMAN_FREES];
};

unsigned int memtest(unsigned int start, unsigned int end);
void memman_init(struct MEMMAN *man);
unsigned int memman_total(struct MEMMAN *man);
unsigned int memman_alloc(struct MEMMAN *man, unsigned int size);
int memman_free(struct MEMMAN *man, unsigned int addr, unsigned int size);
unsigned int memman_alloc_4k(struct MEMMAN *man, unsigned int size);
int memman_free_4k(struct MEMMAN *man, unsigned int addr, unsigned int size);

/* sheet.c */
#define MAX_SHEETS		256
#define SHEET_USE  1
#define SHEET_DORMANT  0x40

struct SHEET {
	unsigned char *buf;
	int bxsize, bysize, vx0, vy0, col_inv, height, flags;
	struct SHTCTL *ctl;
	struct TASK *task;
	char title[32];     /* 窗口标题（用于焦点切换重绘标题栏）*/
};

struct SHTCTL {
	unsigned char *vram, *map;
	int xsize, ysize, top;
	struct SHEET *sheets[MAX_SHEETS];
	struct SHEET sheets0[MAX_SHEETS];
};

struct SHTCTL *shtctl_init(struct MEMMAN *memman, unsigned char *vram, int xsize, int ysize);
struct SHEET *sheet_alloc(struct SHTCTL *ctl);
void sheet_setbuf(struct SHEET *sht, unsigned char *buf, int xsize, int ysize, int col_inv);
void sheet_updown(struct SHEET *sht, int height);
void sheet_refresh(struct SHEET *sht, int bx0, int by0, int bx1, int by1);
void sheet_slide(struct SHEET *sht, int vx0, int vy0);
void sheet_free(struct SHEET *sht);

/* timer.c */
#define MAX_TIMER 500
#define TIMER_FLAGS_ALLOC 1
#define TIMER_FLAGS_USING 2
struct TIMER {
	struct TIMER *next;
	unsigned int timeout;
	char flags, flags2;
	struct FIFO32 *fifo;
	int data;
};
struct TIMERCTL {
	unsigned int count, next;
	struct TIMER *t0;
	struct TIMER timers0[MAX_TIMER];
};
extern struct TIMERCTL timerctl;

void init_pit(void);
struct TIMER *timer_alloc(void);
void timer_free(struct TIMER *timer);
void timer_init(struct TIMER *timer, struct FIFO32 *fifo, int data);
void timer_settime(struct TIMER *timer, unsigned int timeout);
int timer_cancel(struct TIMER *timer);
void timer_cancelall(struct FIFO32 *fifo);
void inthandler20(int *esp);

/* file_sys.c - 文件系统 */
#define FS_MAX_FILES       64      /* 最大文件数 */
#define FS_FILENAME_LEN    32      /* 文件名最大长度 */
#define FS_BLOCK_SIZE      512     /* 数据块大小 */
#define FS_MAX_FILE_SIZE   32768   /* 单个文件最大大小 32KB */

/* 文件类型 */
#define FS_TYPE_FILE       0x01    /* 普通文件 */
#define FS_TYPE_DIR        0x02    /* 目录 */

/* 文件打开模式 */
#define FS_READ            0x01    /* 只读 */
#define FS_WRITE           0x02    /* 只写 */
#define FS_READ_WRITE      0x03    /* 读写 */

/* 文件属性 */
#define FS_ATTR_READONLY   0x01    /* 只读 */
#define FS_ATTR_HIDDEN     0x02    /* 隐藏 */
#define FS_ATTR_SYSTEM     0x04    /* 系统文件 */
#define FS_ATTR_DIRECTORY  0x10    /* 目录 */
#define FS_ATTR_ARCHIVE    0x20    /* 归档 */

/* 文件系统超级块 */
struct FS_SUPERBLOCK {
    unsigned short magic;          /* 魔数 */
    unsigned int total_blocks;      /* 总块数 */
    unsigned int free_blocks;       /* 空闲块数 */
    unsigned int inode_count;       /* inode数量 */
    unsigned int block_size;        /* 块大小 */
    char volume_name[32];          /* 卷标名 */
    unsigned int create_time;       /* 创建时间 */
    unsigned char reserved[480];   /* 保留 */
};

/* 文件inode结构 */
struct FS_INODE {
    unsigned short mode;           /* 文件类型和权限 */
    unsigned int size;             /* 文件大小 */
    unsigned int blocks;           /* 占用的数据块数 */
    unsigned int atime;            /* 最后访问时间 */
    unsigned int mtime;            /* 最后修改时间 */
    unsigned int ctime;            /* 创建时间 */
    unsigned int block_ptr[8];     /* 直接块指针 */
    unsigned int single_indirect;   /* 一级间接指针 */
    unsigned char flags;           /* 标志位 */
    unsigned char reserved[15];    /* 保留 */
};

/* FAT12 磁盘目录项结构（同原书） */
struct FILEINFO {
	unsigned char name[8], ext[3], type;
	char reserve[10];
	unsigned short time, date, clustno;
	unsigned int size;
};
#define MAX_FAT12_FILES  224

/* 目录项结构 */
struct FS_DIRENT {
    unsigned short inode;          /* inode号 */
    char name[FS_FILENAME_LEN];   /* 文件名 */
    unsigned char type;            /* 文件类型 */
    unsigned char attr;            /* 文件属性 */
    unsigned int size;             /* 文件大小 */
    unsigned int mtime;           /* 修改时间 */
    unsigned char reserved[16];    /* 保留 */
};

/* 文件描述符 */
struct FS_FILE {
    unsigned short fd;            /* 文件描述符ID */
    unsigned short inode;         /* 对应的inode号 */
    unsigned int pos;             /* 当前读写位置 */
    unsigned char mode;           /* 打开模式 */
    unsigned char flags;          /* 标志 */
    struct FS_INODE *inode_ptr;   /* inode指针 */
};

/* 文件系统函数声明 */
int fs_init(const char *volume_name);
int fs_create(const char *path, unsigned char attr);
int fs_mkdir(const char *path, unsigned char attr);
int fs_unlink(const char *path);
int fs_open(const char *path, unsigned char mode);
int fs_close(int fd);
int fs_read(int fd, void *buf, unsigned int count);
int fs_write(int fd, const void *buf, unsigned int count);
int fs_seek(int fd, int offset, int whence);
int fs_stat(const char *path, struct FS_DIRENT *stat);
int fs_list_dir(const char *path, struct FS_DIRENT *dirs, int max_entries);
int fs_mkfs(const char *volume_name);
int fs_get_info(char *buf, int buf_size);
int fs_is_initialized(void);

/* fat12.c - FAT12 读写 */
#define DATA_OFFSET      0x004200  /* 数据区在镜像中的偏移（扇区 33）*/
#define CLUSTER_SIZE     512
extern int *g_fat;
extern int g_saved_kernel_esp[2];
void BSOD(int stopcode, struct BOOTINFO *binfo);
void exception_handler(int exc_no, int eip, int cs);
int file_load(const char *fname, unsigned char *buf);
int load_wda(const char *fname, struct SHEET *sht);

void file_readfat(int *fat, unsigned char *img);
void file_writefat(int *fat, unsigned char *img);
int fat_find_free(int *fat);
int fat_find_free_entry(unsigned char *img);
int fat_create(char *name, unsigned int size, int *fat, unsigned char *img);
int fat_append_cluster(int clust, int *fat);
struct FILEINFO *file_search(char *name, struct FILEINFO *finfo, int max);
void file_loadfile(int clustno, int size, char *buf, int *fat, char *img);
int fat_writefile(struct FILEINFO *finfo, char *buf, int size, int *fat, unsigned char *img);
/* chinese_font.c - HZK16 中文字库 */
int hzk16_load(void);
int hzk16_is_loaded(void);
int is_gb2312(unsigned char c1, unsigned char c2);
int hzk16_get_font(unsigned char ch1, unsigned char ch2, unsigned char *buf);
void putfont8_hz(unsigned char *buf, int xsize, int x, int y,
                  unsigned char ch1, unsigned char ch2, unsigned char col);
int putfonts8_asc_hz(unsigned char *buf, int xsize, int x, int y,
                      unsigned char col, unsigned char *str);
/* startmenuandbtn.c */
void make_btn8(unsigned char *buf, int xsize, int ysize, unsigned char *title, int pressed);
void make_startmenu8(unsigned char *buf, int xsize, int ysize, int hover_item);
void init_startmenu(void);
void refresh_startmenu(int hover_item);
void update_btn_state(int pressed);
extern struct SHEET *g_sht_btn;
extern struct SHEET *g_sht_mouse;

/* login.c - 登录界面 */
void show_boot_screen(struct SHTCTL *shtctl, struct BOOTINFO *binfo);
void login_screen(struct SHTCTL *shtctl, struct BOOTINFO *binfo);

/* explorer.c - 文件浏览器 */
void explorer_open(void);
void explorer_close(void);
void explorer_refresh(void);
void explorer_open_file_at(int mx, int my);
void explorer_new_file(void);
void explorer_new_dir(void);
extern struct SHEET *g_sht_explorer;
extern int g_explorer_opened;

/* console.c - 控制台 */
void console_task(struct SHEET *sheet, int memtotal);
void cons_putchar(struct CONSOLE *cons, int chr, char move);
void cons_newline(struct CONSOLE *cons);
void cons_putstr0(struct CONSOLE *cons, char *s);
void cons_putstr1(struct CONSOLE *cons, char *s, int l);
void cons_runcmd(char *cmdline, struct CONSOLE *cons, int *fat, int memtotal);
int cmd_app(struct CONSOLE *cons, int *fat, char *cmdline);
void cmd_exit(struct CONSOLE *cons, int *fat);
struct TASK *open_constask(struct SHEET *sht, unsigned int memtotal);
struct SHEET *open_console(struct SHTCTL *shtctl, unsigned int memtotal);
void close_constask(struct TASK *task);
void close_console(struct SHEET *sht);

/* taskmgr.c - 任务管理器 */
void taskmgr_open(void);
void taskmgr_close(void);
void taskmgr_on_click(int mx, int my);
extern struct SHEET *g_sht_taskmgr;
extern int g_taskmgr_opened;

/* menu.c - 右键上下文菜单（支持二级子菜单） */
struct MENU_ITEM {
	unsigned char text[64];      /* 菜单项文字（GB2312 混合 ASCII） */
	int action;                  /* >=0=动作ID, -1=分隔线, -2=含子菜单 */
	struct MENU_ITEM *sub;      /* 子菜单项数组 (action==-2 时有效) */
	int sub_count;              /* 子菜单项数 */
};

int is_menu_open(void);
void show_context_menu(int x, int y, struct MENU_ITEM *items, int count);
void hide_all_menus(void);
void menu_update_hover(int mx, int my);
int menu_handle_click(struct SHTCTL *shtctl, int mx, int my);

/* 右键菜单动作 ID */
#define MENU_ACT_REFRESH    1   /* 刷新 */
#define MENU_ACT_NEW_DIR    2   /* 新建文件夹 */
#define MENU_ACT_NEW_TXT    3   /* 新建文本文档 */
#define MENU_HOVER_NONE     0
#define MENU_HOVER_COMP     1  /* 此电脑 */
#define MENU_HOVER_DOCS     2  /* 文档 */
#define MENU_HOVER_SEARCH   3  /* 搜索 */
#define MENU_HOVER_TASKMGR  4  /* 任务管理器 */
#define MENU_HOVER_CONSOLE  5  /* 控制台 */
#define MENU_HOVER_SHUTDOWN 6  /* 关机 */
#define MENU_HOVER_RESTART  7  /* 重启 */

extern struct SHTCTL *g_shtctl;
extern struct MEMMAN *g_memman;
extern struct BOOTINFO *g_binfo;
extern unsigned int g_memtotal;
extern struct SHEET *g_sht_startmenu;
extern int g_startmenu_visible;
extern struct TASKCTL *taskctl;

/* naskfunc.nas - 多任务 */
void farjmp(int eip, int cs);
void asm_win_api(void);
void start_app(int eip, int cs, int esp, int ds, int *tss_esp0);

/* api.c - 系统调用 */
int *win_api(int edi, int esi, int ebp, int esp, int ebx, int edx, int ecx, int eax);
void hrb_api_linewin(struct SHEET *sht, int x0, int y0, int x1, int y1, int col);

/* mtask.c - 多任务管理 */
struct TASK *task_init(struct MEMMAN *memman);
struct TASK *task_alloc(void);
void task_run(struct TASK *task, int level, int priority);
void task_sleep(struct TASK *task);
struct TASK *task_now(void);
void task_add(struct TASK *task);
void task_remove(struct TASK *task);
void task_switch(void);
void task_switchsub(void);

extern struct SHTCTL *g_shtctl;
extern struct MEMMAN *g_memman;
extern struct BOOTINFO *g_binfo;
extern unsigned int g_memtotal;
extern struct SHEET *g_sht_startmenu;
extern int g_startmenu_visible;
#endif
extern int g_mx, g_my, g_mbtn;
