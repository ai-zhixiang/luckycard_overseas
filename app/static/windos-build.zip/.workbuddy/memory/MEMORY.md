# WinDOS 项目长期记忆

## 工具链与编码
- **中文预处理管线**：源码直接写 UTF-8 中文，`py/gb2hex.py` 编译时自动转 GB2312 `\xHH` 转义
- 编译流程：`.c → gb2hex.py → _utf8.c → cc1 → .gas → gas2nask → .nas → nask → .obj`
- cc1.exe 不支持 UTF-8/GBK 源文件，所以必须经过预处理
- 如需手动查编码：`python3 py/gb2312tool.py "中文"`

## 关键技术点
- _asm_end_app 需在 POPAD 前恢复 DS/ES/FS/GS 到内核段（1*8）
- 控制台任务需要 task_run(task, 0, 2) level 0 才能获得时间片
- FIFO 需在 task_run 之前初始化
- 键盘只处理 make 码（i < 0x80），break 码跳过
- api_end（edx=4）不能设 task->flags=0，否则终止控制台任务本身
- 退格需直接 boxfill8 黑色涂掉字符位置
- hover/click 坐标必须与 sheet vy0 完全一致
