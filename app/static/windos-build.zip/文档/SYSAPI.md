# WinDOS 系统内部 API 参考手册

> 这些 API 仅供内核子系统、系统进程使用。
> 普通应用程序请使用 \[API.md](API.md) 中的公开接口。

## 调用约定

|寄存器|用途|
|-|-|
|EDX|功能号|
|EAX, EBX, ECX, ESI, EDI, EBP|参数|

\---

## 系统 API 列表

### 14\. setcritical — 设置进程保护级别

```c
void setcritical(int is\_kernel, int bsod\_on\_kill, int is\_system);
```

**INT 0x40 功能号 14**

设置当前进程的保护级别。由进程自身调用，内核将其写入对应 `struct TASK` 字段。

|参数|类型|对应 TASK 字段|说明|
|-|-|-|-|
|is\_kernel|int|`task->is\_kernel`|是否为内核进程|
|bsod\_on\_kill|int|`task->bsod\_on\_kill`|被强制结束后触发蓝屏|
|is\_system|int|`task->is\_system`|是否为系统进程|

**核心逻辑（api.c：`win\_api` dispatcher）：**

```c
if (edx == 14) {
    if (edi == 0) {         // is\_system == 0
        task->is\_kernel = 0;
        task->bsod\_on\_kill = 0;
    } else {
        task->is\_kernel = ebx;
        task->bsod\_on\_kill = esi;
    }
    task->is\_system = edi;
}
```

|is\_system|is\_kernel|bsod\_on\_kill|效果|
|-|-|-|-|
|0|任意|任意|忽略输入，强制归零（普通进程）|
|1|0|0|系统进程，无特殊保护|
|1|1|0|内核进程，杀进程不会蓝屏|
|1|1|1|内核进程，杀进程触发 BSOD|

\---

## 使用示例

```c
// === 系统进程示例：任务管理器 ===
void WinMain(void) {
    setcritical(1, 0, 1);   // 系统进程，内核级，杀掉不蓝屏
    // ...
}

// === 核心系统进程：窗口管理器 ===
void WinMain(void) {
    setcritical(1, 1, 1);   // 系统进程，内核级，杀掉蓝屏
    // ...
}

// === 普通进程 ===
void WinMain(void) {
    setcritical(0, 0, 0);   // 普通应用（前两参数被忽略）
    // 等价于 setcritical(1, 1, 0)
}
```

\---

## 运行时结构

`struct TASK` 中的相关字段（定义于 `bootpack.h`）：

```c
struct TASK {
    // ...
    int is\_kernel;       /\* 是否为内核进程 \*/
    int bsod\_on\_kill;    /\* 被强制干掉后是否蓝屏 \*/
    int is\_system;       /\* 是否为系统进程 \*/
    // ...
};
```

\---

## 内部 API v2.0（新增：edx 15-20）

### 15\. list\_files — 列出 FAT12 文件

```c
int list\_files(void \*buf, int buf\_size);
```

**INT 0x40 功能号 15**

复制磁盘根目录的 FAT12 文件目录项到应用缓冲区。每个目录项 32 字节（`struct FILEINFO` 格式）。

|参数|类型|说明|
|-|-|-|
|EBX|buf\*|应用缓冲区地址（+ds\_base）|
|ESI|int|缓冲区大小（字节）|
|**返回 EAX**|int|文件数量|

`buf` 中最多填充 `buf\_size / 32` 个目录项，每项 32 字节：

```c
struct FILEINFO {
    unsigned char name\[8];  /\* 文件名（空格填充）\*/
    unsigned char ext\[3];   /\* 扩展名 \*/
    unsigned char type;     /\* 文件属性 \*/
    char reserve\[10];
    unsigned short time;
    unsigned short date;
    unsigned short clustno; /\* 起始簇号 \*/
    unsigned int size;      /\* 文件大小 \*/
};
```

**示例：**

```c
#define MAX\_FILES 224
struct FILEINFO finfo\[MAX\_FILES];
int count = list\_files(finfo, sizeof(finfo));
// finfo\[0..count-1] 中为文件列表
```

\---

### 16\. malloc — 分配内存

```c
void \*malloc(int size);
```

**INT 0x40 功能号 16**

分配 4KB 对齐的内存块。实际分配大小为 `(size + 4095) \& \~4095` 字节。

|参数|类型|说明|
|-|-|-|
|EBX|int|请求大小（字节）|
|**返回 EAX**|void\*|分配地址（0=失败）|

**实现：** 调用 `memman\_alloc\_4k(memman, aligned\_size)`。

> ⚠️ 当前实现没有 `realloc`。频繁分配/释放可能碎片化。

\---

### 17\. free — 释放内存

```c
void free(void \*addr, int size);
```

**INT 0x40 功能号 17**

释放由 `malloc` 分配的内存。

|参数|类型|说明|
|-|-|-|
|EBX|void\*|要释放的地址|
|ECX|int|原分配大小（字节）|

`size` 不需要精确到 4KB 对齐，函数内部会做对齐：

```c
memman\_free\_4k(memman, addr, (size + 4095) \& \~4095);
```

\---

### 18\. run\_wda — 运行 .wda 文件

```c
int run\_wda(const char \*fname);
```

**INT 0x40 功能号 18**

从磁盘加载并运行一个 `.wda` 文件，作为独立任务。

|参数|类型|说明|
|-|-|-|
|EBX|char\*|`.wda` 文件名（如 `"explorer\_wda.wda"`）|
|**返回 EAX**|int|0=成功，负数=失败|

**失败码：**

|返回值|说明|
|-|-|
|-1|内存分配失败|
|-2|文件不存在或太小|
|-3|非有效 .wda 格式（magic 错误）|
|-4|应用内存分配失败|
|-5|任务分配失败|

**示例：**

```c
run\_wda("taskmgr\_wda.wda");  // 启动任务管理器
```

**实现：** 内部调用 `load\_wda(fname, 0)`（loader.c）。

\---

### 19\. get\_tasklist — 获取任务列表

```c
int get\_tasklist(void \*buf, int buf\_size);
```

**INT 0x40 功能号 19**

复制内核任务列表到应用缓冲区。每个任务 16 字节。

|参数|类型|说明|
|-|-|-|
|EBX|void\*|应用缓冲区地址（+ds\_base）|
|ESI|int|缓冲区大小（字节）|
|**返回 EAX**|int|任务数量|

`buf` 中每 16 字节对应一个活跃任务：

```c
struct TASK\_INFO {
    int sel;       /\* 任务选择子 = (TASK\_GDT0 + idx) \* 8 \*/
    int level;     /\* 运行的层级 \*/
    int priority;  /\* 优先级（时间片大小）\*/
    int flags;     /\* 标志（0=未用, 1=休眠, 2=活动）\*/
};
```

**示例：**

```c
struct { int sel, level, priority, flags; } tasks\[64];
int count = get\_tasklist(tasks, sizeof(tasks));
for (int i = 0; i < count; i++) {
    int task\_id = tasks\[i].sel / 8 - 3;  // 转换为 0-based 索引
    // ...
}
```

\---

### 20\. kill\_task — 结束任务

```c
int kill\_task(int task\_sel);
```

**INT 0x40 功能号 20**

通过任务选择子结束指定任务。

|参数|类型|说明|
|-|-|-|
|EBX|int|任务选择子（来自 get\_tasklist 返回的 `sel`）|
|**返回 EAX**|int|0=成功, -1=失败（任务不存在或已结束）|

**实现逻辑：**

```c
int idx = (ebx / 8) - TASK\_GDT0;
if (0 <= idx \&\& idx < MAX\_TASKS \&\& tasks0\[idx].flags != 0) {
    task\_sleep(\&tasks0\[idx]);
    tasks0\[idx].flags = 0;  // 标记为未使用
    reg\[7] = 0;   // 成功
} else {
    reg\[7] = -1;  // 失败
}
```

> ⚠️ 不能结束当前运行的任务自身（flags=2），也不能结束标志为 0 的空闲槽。

**示例：**

```c
int count = get\_tasklist(tasks, sizeof(tasks));
for (int i = 0; i < count; i++) {
    kill\_task(tasks\[i].sel);  // 结束所有任务
}
```

---

### 21\. GetCurrentOSVersion — 获取系统版本

```c
int GetCurrentOSVersion(void);
```

**INT 0x40 功能号 21**

返回操作系统版本号（×100）。内核硬编码返回值。

|返回值|说明|
|-|-|
|2614|表示 26.14|

```c
int ver = GetCurrentOSVersion();  // 2614
```

> 🆕 v3.0 新增。属于公开 API，详见 [API.md](API.md)。

