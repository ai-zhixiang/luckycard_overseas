# WinDOS API 参考手册

## 架构

```
┌─────────────────────┐
│   应用 (.wda)        │
│  #include "apilib.h"│
│  createwin(...)     │
└────────┬────────────┘
         │ INT 0x40
         ▼
┌─────────────────────┐
│   WinDOS 内核        │
│  win_api() 分发器    │
│  (api.c)            │
└─────────────────────┘
```

## 调用约定

| 寄存器                          | 用途         |
| ---------------------------- | ---------- |
| EDX                          | 功能号 (1-27) |
| EAX, EBX, ECX, ESI, EDI, EBP | 参数         |
| EAX (返回时)                    | 返回值        |

所有 API 通过 `INT 0x40` 陷入内核，DPL=3 允许用户态调用。

---

## API 列表

### EDX=1~3: putchar / putstr0 / putstr1 — 控制台输出

```c
void putchar(int c);
void putstr0(char *s);
void putstr1(char *s, int l);
```

| 函数      | 说明           |
| ------- | ------------ |
| putchar | 输出单个字符到控制台   |
| putstr0 | 输出 \0 结尾的字符串 |
| putstr1 | 输出定长字符串      |

---

### EDX=4: end — 结束应用

```c
void end(void);
```

结束当前应用的执行，返回内核。**必须调用**。

---

### EDX=5: createwin — 打开窗口

```c
int createwin(char *buf, int xsiz, int ysiz, int col_inv, char *title);
```

| 参数      | 说明            |
| ------- | ------------- |
| buf     | 窗口缓冲区（应用自己分配） |
| xsiz    | 窗口宽度          |
| ysiz    | 窗口高度          |
| col_inv | 透明色（-1 表示无透明） |
| title   | 标题栏文字         |

| 返回值      | 说明           |
| -------- | ------------ |
| sheet 指针 | 窗口句柄，后续操作都用它 |

---

### EDX=6: putstrwin — 窗口内写文字

```c
void putstrwin(int win, int x, int y, int col, int len, char *str);
```

---

### EDX=7: boxfilwin — 窗口内填充矩形

```c
void boxfilwin(int win, int x0, int y0, int x1, int y1, int col);
```

---

### EDX=8: linewin — 窗口内画线

```c
void linewin(int win, int x0, int y0, int x1, int y1, int col);
```

---

### EDX=9: point — 窗口内画点

```c
void point(int win, int x, int y, int col);
```

---

### EDX=10: refreshwin — 刷新窗口区域

```c
void refreshwin(int win, int x0, int y0, int x1, int y1);
```

---

### EDX=11: closewin — 关闭窗口

```c
void closewin(int win);
```

---

### EDX=12: getkey — 获取按键

```c
int getkey(int mode);
```

| mode | 说明                |
| ---- | ----------------- |
| 0    | 不等待，立即返回，无按键时返回 0 |
| 1    | 阻塞等待直到有按键按下       |

---

### EDX=13: show_menu — 显示上下文菜单

```c
int show_menu(int x, int y, struct MENU_ITEM *items, int count);
```

---

### EDX=14: CreateProcess — 启动 .wda 应用

```c
int CreateProcess(const char *fname);
```

| 返回值 | 说明          |
| --- | ----------- |
| 0   | 启动成功        |
| -1  | 内存分配失败      |
| -2  | 文件不存在或太小    |
| -3  | 非有效 .wda 格式 |
| -4  | 应用内存分配失败    |
| -5  | 任务分配失败      |

---

### EDX=15~20: 系统内部 API（略）

---

### EDX=21: GetCurrentOSVersion — 获取系统版本

```c
int GetCurrentOSVersion(void);
```

返回值 = 版本号 × 100（如 2614 = 26.14）

---

### EDX=22: AllocTimer — 分配定时器

```c
int AllocTimer(void);
```

返回定时器指针，用于 InitTimer / SetTimer。

---

### EDX=23: InitTimer — 初始化定时器

```c
void InitTimer(int timer, int data);
```

---

### EDX=24: SetTimer — 设置定时器时间

```c
void SetTimer(int timer, int time);
```

---

### EDX=25: (内核内部 API)

---

### EDX=26: ClickedButton — 按钮点击检测

```c
int ClickedButton(int win, int bx, int by, int bw, int bh);
```

| 参数     | 说明           |
| ------ | ------------ |
| win    | 窗口句柄         |
| bx, by | 按钮左上角坐标（窗口内） |
| bw, bh | 按钮宽高         |

| 返回值 | 说明          |
| --- | ----------- |
| 1   | 鼠标左键在此区域内点击 |
| 0   | 未点击         |

```c
// 检测 20x20 的格子是否被点击
if (ClickedButton(win, x, y, 20, 20)) {
    // 处理点击
}
```

---

### EDX=27: Sleep — 延时等待

```c
void Sleep(int ms);
```

阻塞当前应用指定毫秒数，同时让出 CPU 给其他任务。

```c
Sleep(50);   // 等 50 毫秒
Sleep(1000); // 等 1 秒
```

---

## 完整示例

```c
// hello.c — 第一个 .wda 应用
#include "apilib.h"

void main(void) {
    char buf[200 * 100];
    int win = createwin(buf, 200, 100, -1, "Hello WDA!");

    boxfilwin(win, 8, 28, 191, 91, 7);
    putstrwin(win, 60, 30, 0, 13, "Hello WinDOS!");
    refreshwin(win, 8, 28, 192, 92);

    end();
}
```
