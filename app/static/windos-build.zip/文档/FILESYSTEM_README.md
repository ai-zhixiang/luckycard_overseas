# WinDOS 文件系统使用说明

## 概述
这是一个基于内存的简单文件系统实现，支持基本的文件操作。

## 功能特性
- 文件创建、删除、读取、写入
- 目录创建
- 文件列表
- 文件系统格式化
- 最大支持 64 个文件
- 单个文件最大 32KB

## 文件列表
- `file_sys.c` - 文件系统主实现
- `bootpack.h` - 已添加文件系统相关声明

## API 使用说明

### 1. 初始化文件系统
```c
/* 在 bootpack.c 的 WinMain 中调用 */
fs_init("WinDOS");
```

### 2. 创建文件
```c
/* 创建普通文件 */
fs_create("/test.txt", FS_ATTR_ARCHIVE);

/* 创建只读文件 */
fs_create("/readonly.txt", FS_ATTR_READONLY | FS_ATTR_ARCHIVE);
```

### 3. 创建目录
```c
fs_mkdir("/mydir", FS_ATTR_DIRECTORY);
```

### 4. 打开文件
```c
/* 只读模式打开 */
int fd = fs_open("/test.txt", FS_READ);

/* 只写模式打开 (不存在则创建) */
int fd = fs_open("/test.txt", FS_WRITE);

/* 读写模式打开 */
int fd = fs_open("/test.txt", FS_READ_WRITE);
```

### 5. 写入文件
```c
char *msg = "Hello, WinDOS!";
int written = fs_write(fd, msg, strlen(msg));
```

### 6. 读取文件
```c
char buf[100];
fs_seek(fd, 0, 0);  /* 移动到文件开头 SEEK_SET */
int read = fs_read(fd, buf, sizeof(buf));
```

### 7. 关闭文件
```c
fs_close(fd);
```

### 8. 删除文件
```c
fs_unlink("/test.txt");
```

### 9. 列出目录内容
```c
struct FS_DIRENT dirs[64];
int count = fs_list_dir("/", dirs, 64);

for (int i = 0; i < count; i++) {
    putfonts8_asc(buf_back, binfo->scrnx, x, y, COL8_FFFFFF, dirs[i].name);
    y += 16;
}
```

### 10. 获取文件信息
```c
struct FS_DIRENT stat;
fs_stat("/test.txt", &stat);
/* stat.size - 文件大小 */
/* stat.type - 文件类型 */
/* stat.attr - 文件属性 */
```

### 11. 获取文件系统信息
```c
char info[256];
fs_get_info(info, sizeof(info));
/* 显示 info 字符串 */
```

### 12. 格式化文件系统
```c
fs_mkfs("NewVolume");
```

## 示例代码

以下是一个完整的使用示例（可以集成到 bootpack.c 中）：

```c
void test_filesystem(struct BOOTINFO *binfo)
{
    char buf[256];
    int fd;
    int written, read;
    struct FS_DIRENT dirs[64];
    int count;
    int i;
    
    /* 1. 初始化文件系统 */
    fs_init("WinDOS");
    
    /* 2. 显示文件系统信息 */
    fs_get_info(buf, sizeof(buf));
    /* 这里可以解析 buf 并显示 */
    
    /* 3. 创建文件 */
    fs_create("/hello.txt", FS_ATTR_ARCHIVE);
    
    /* 4. 写入文件 */
    fd = fs_open("/hello.txt", FS_WRITE);
    if (fd >= 0) {
        char *msg = "Hello, WinDOS File System!";
        written = fs_write(fd, msg, strlen(msg));
        fs_close(fd);
    }
    
    /* 5. 读取文件 */
    fd = fs_open("/hello.txt", FS_READ);
    if (fd >= 0) {
        char read_buf[256];
        read = fs_read(fd, read_buf, sizeof(read_buf));
        fs_close(fd);
    }
    
    /* 6. 创建目录 */
    fs_mkdir("/mydir", 0);
    
    /* 7. 列出根目录内容 */
    count = fs_list_dir("/", dirs, 64);
    for (i = 0; i < count; i++) {
        /* 显示文件名 */
        /* putfonts8_asc(..., dirs[i].name); */
    }
    
    /* 8. 删除文件 */
    /* fs_unlink("/hello.txt"); */
}
```

## 集成到 WinDOS

在 `bootpack.c` 的 `WinMain` 函数中添加：

```c
/* 在初始化完成后调用 */
fs_init("WinDOS");

/* 测试文件系统 */
test_filesystem(binfo);
```

## 注意事项
1. 当前实现使用内存文件系统，重启后数据会丢失
2. 只支持根目录，不支持多级目录
3. 文件名最大 31 字符
4. 最大文件数：64 个
5. 单个文件最大：32KB

## 未来改进
- [ ] 支持多级目录
- [ ] 支持更大的文件 (间接指针)
- [ ] 持久化存储 (保存到磁盘镜像)
- [ ] 支持文件权限
- [ ] 实现文件重命名
- [ ] 支持软链接和硬链接

## 编译
文件系统已经添加到 Makefile 中，直接运行 `make` 即可编译：
```bash
make img
```

## 文件结构
```
file_sys.c                   - 文件系统实现
├── 超级块管理
├── inode 管理
├── 数据块管理
├── 目录操作
└── 文件 I/O 操作
```
