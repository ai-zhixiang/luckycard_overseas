[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "alloca.nas"]

		GLOBAL	__alloca

[SECTION .text]

__alloca:	; int *alloca(int size);
		ADD		EAX,[ESP+4]
		SUB		EAX,4
		JMP		DWORD [ESP+4]
