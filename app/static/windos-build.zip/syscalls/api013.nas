[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "api013.nas"]

		GLOBAL	_show_menu

[SECTION .text]

_show_menu:	; int api_show_menu(int x, int y, struct MENU_ITEM *items, int count);
		PUSH	EDI
		PUSH	ESI
		PUSH	EBX
		MOV		EDX,13
		MOV		EBX,[ESP+16]	; x
		MOV		ESI,[ESP+20]	; y
		MOV		EDI,[ESP+24]	; items
		MOV		EAX,[ESP+28]	; count
		INT		0x40
		POP		EBX
		POP		ESI
		POP		EDI
		RET
