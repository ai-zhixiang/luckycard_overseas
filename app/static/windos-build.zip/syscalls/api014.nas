[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "api014.nas"]

		GLOBAL	_setcritical

[SECTION .text]

_setcritical:	; void setcritical(int is_kernel, int bsod_on_kill, int is_system);
		PUSH	EDI
		PUSH	ESI
		PUSH	EBX
		MOV		EDX,14
		MOV		EBX,[ESP+16]	; is_kernel
		MOV		ESI,[ESP+20]	; bsod_on_kill
		MOV		EDI,[ESP+24]	; is_system
		INT		0x40
		POP		EBX
		POP		ESI
		POP		EDI
		RET
