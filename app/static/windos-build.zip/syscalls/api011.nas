[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "api011.nas"]

		GLOBAL	_closewin

[SECTION .text]

_closewin:	; void api_closewin(int win);
		PUSH	EBX
		MOV		EDX,11
		MOV		EBX,[ESP+8]		; win
		INT		0x40
		POP		EBX
		RET
