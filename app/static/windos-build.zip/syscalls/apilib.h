/* apilib.h - WinDOS 应用编程接口 */

#ifndef APILIB_H
#define APILIB_H

/* 控制台输出 */
void putchar(int c);
void putstr0(char *s);
void putstr1(char *s, int l);
void end(void);

/* 窗口操作 */
int  createwin(char *buf, int xsiz, int ysiz, int col_inv, char *title);
void putstrwin(int win, int x, int y, int col, int len, char *str);
void boxfilwin(int win, int x0, int y0, int x1, int y1, int col);
void linewin(int win, int x0, int y0, int x1, int y1, int col);
void point(int win, int x, int y, int col);
void refreshwin(int win, int x0, int y0, int x1, int y1);
void closewin(int win);

/* 输入 */
int getkey(int mode);

/* 菜单 */
struct MENU_ITEM {
	unsigned char text[64];
	int action;
	struct MENU_ITEM *sub;
	int sub_count;
};
int show_menu(int x, int y, struct MENU_ITEM *items, int count);

/* 进程保护 */
void setcritical(int is_kernel, int bsod_on_kill, int is_system);

/* 内存 */
void *alloca(int size);

int GetCurrentOSVersion(void);

#endif
