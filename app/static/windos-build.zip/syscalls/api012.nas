[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "api012.nas"]

		GLOBAL	_getkey

[SECTION .text]

_getkey:	; int api_getkey(int mode);
		MOV		EDX,12
		MOV		EAX,[ESP+4]		; mode
		INT		0x40
		RET
