[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "api010.nas"]

		GLOBAL	_refreshwin

[SECTION .text]

_refreshwin:	; void api_refreshwin(int win, int x0, int y0, int x1, int y1);
		PUSH	EDI
		PUSH	ESI
		PUSH	EBX
		MOV		EDX,10
		MOV		EBX,[ESP+16]	; win
		MOV		ESI,[ESP+20]	; x0
		MOV		EDI,[ESP+24]	; y0
		MOV		EAX,[ESP+28]	; x1
		MOV		ECX,[ESP+32]	; y1
		INT		0x40
		POP		EBX
		POP		ESI
		POP		EDI
		RET
