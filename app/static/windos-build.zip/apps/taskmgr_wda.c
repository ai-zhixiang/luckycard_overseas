/* taskmgr_wda.c - 独立任务管理器（.wda 版）*/
#include "apilib.h"

/* 任务信息（匹配 api.c 中 get_tasklist 格式）*/
struct TASK_INFO {
	int sel;       /* 任务选择子 */
	int level;     /* 优先级层级 */
	int priority;  /* 优先级 */
	int flags;     /* 标志（0=未用, 1=休眠, 2=活动）*/
};

void main(void)
{
	int win;
	int w = 350, h = 260;
	int i, task_count;
	struct TASK_INFO tasks[64];
	char line[40];
	char *buf;

	/* 从堆分配窗口缓冲区（栈只有 8KB，不够 350*260）*/
	buf = (char *)malloc(w * h);
	if (buf == 0) return;

	/* 读取任务列表 */
	task_count = get_tasklist(tasks, sizeof(tasks));
	if (task_count < 0) task_count = 0;

	/* 创建窗口 */
	win = createwin(buf, w, h, -1, "Task Manager");
	if (win <= 0) { free(buf, w * h); return; }

	/* 表头 */
	putstrwin(win, 8, 28, 0, 30, "  ID  Lv Pri Flags");
	refreshwin(win, 0, 0, w, h);

	/* 显示任务列表 */
	{
		int y = 44;
		for (i = 0; i < task_count && i < 12; i++) {
			/* 格式: "  %3d  %2d  %3d   %d" */
			int sel_id = (tasks[i].sel / 8) - 3;  /* 转换为任务索引 */
			char buf[40];
			int j;
			/* 手动构造字符串（没有 sprintf）*/
			/* 格式：空格+数字+对齐 */
			int n = sel_id, pos = 0;
			/* ID */
			buf[pos++] = ' ';
			if (n >= 100) { buf[pos++] = '0' + n/100; n %= 100; } else buf[pos++] = ' ';
			if (n >= 10)  { buf[pos++] = '0' + n/10;  n %= 10; }  else buf[pos++] = ' ';
			buf[pos++] = '0' + n;
			buf[pos++] = ' ';
			/* Level */
			n = tasks[i].level;
			if (n >= 10) { buf[pos++] = '0' + n/10; n %= 10; } else buf[pos++] = ' ';
			buf[pos++] = '0' + n;
			buf[pos++] = ' ';
			/* Priority */
			n = tasks[i].priority;
			if (n >= 100) { buf[pos++] = '0' + n/100; n %= 100; } else buf[pos++] = ' ';
			if (n >= 10)  { buf[pos++] = '0' + n/10;  n %= 10; }  else buf[pos++] = ' ';
			buf[pos++] = '0' + n;
			buf[pos++] = ' ';
			/* Flags */
			buf[pos++] = '0' + tasks[i].flags;
			buf[pos++] = 0;

			putstrwin(win, 8, y, 0, 40, buf);
			y += 16;
		}
	}
	refreshwin(win, 0, 0, w, h);

	/* 等待 ESC 退出 */
	for (;;) {
		int key = getkey(0);
		if (key == 0x01) break;  /* ESC */
	}

	closewin(win);
	free(buf, w * h);
	end();
}
