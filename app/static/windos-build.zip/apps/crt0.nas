[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "crt0.nas"]
	GLOBAL	_start
	GLOBAL	___main
	EXTERN	_main
[SECTION .text]
___main:
	RET
_start:
	CALL	_main
	MOV	EDX,4
	INT	0x40
