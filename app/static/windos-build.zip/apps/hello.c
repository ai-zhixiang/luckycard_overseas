/* hello.c - WinDOS C 应用程序测试 */
#include "apilib.h"

void main(void)
{
    putchar('H');
    putchar('e');
    putchar('l');
    putchar('l');
    putchar('o');
    putchar('\r');
    putchar('\n');

    putstr0("Hello from .wda C app!\r\n");
    putstr0("If you see this, the loader works!\r\n");

    /* 退出 */
    end();
}
