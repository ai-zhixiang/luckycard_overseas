/* winhello.c - WinDOS 欢迎窗口 (.wda) — 点 X 关闭 */
#include "apilib.h"

void main(void)
{
    char *buf;
    int win;

    buf = (char *)malloc(200 * 100);
    if (buf == 0) return;

    win = createwin(buf, 200, 100, -1, "WinHello");
    if (win <= 0) return;

    boxfilwin(win, 8, 28, 191, 91, COL8_FFFFFF);
    putstrwin(win, 30, 42, COL8_000000, 16, "Hello, WinDOS!");

    while (is_window_valid(win)) {}
}
