#include "apilib.h"

void init_board(void);
void draw_cell(int win, int r, int c);
void open_cell(int win, int r, int c);

static unsigned char _pad[16] = {0};

#define ROWS 9
#define COLS 9
#define MINES 10
#define CELL 20
#define BX 4
#define BY 24

int board[9][9];
int opened[9][9];
int flagged[9][9];
int over;

void main(void)
{
	int win, r, c, bx, by, clicked;
	char buf[200 * 240];
	win = CreateWin(buf, 200, 240, -1, "Minesweeper");
	init_board();
	BoxFilWin(win, 0, 0, 199, 239, 7);
	for (r = 0; r < ROWS; r++)
		for (c = 0; c < COLS; c++)
			draw_cell(win, r, c);
	RefreshWin(win, 0, 0, COLS * CELL + 8, ROWS * CELL + 28);
	while (over == 0) {
		clicked = 0;
		for (r = 0; r < ROWS && clicked == 0; r++)
			for (c = 0; c < COLS && clicked == 0; c++) {
				bx = BX + c * CELL;
				by = BY + r * CELL;
				if (clickedbutton(win, bx, by, CELL, CELL)) {
					clicked = 1;
					open_cell(win, r, c);
					draw_cell(win, r, c);
					RefreshWin(win, 0, 0, 200, 240);
				}
			}
		if (clicked == 0) alloctimer();
	}
	BoxFilWin(win, 40, 90, 160, 130, 14);
	PutStrWin(win, 50, 105, 7, 0, "GAME OVER");
	RefreshWin(win, 0, 0, 200, 240);
	for (;;) alloctimer();
}

void init_board(void)
{
	int i, r, c, dr, dc, nr, nc, n;
	for (r = 0; r < ROWS; r++)
		for (c = 0; c < COLS; c++) {
			board[r][c] = 0;
			opened[r][c] = 0;
			flagged[r][c] = 0;
		}
	for (i = 0; i < MINES; i++) {
		r = alloctimer() % ROWS;
		c = alloctimer() % COLS;
		if (board[r][c] == -1) i--;
		else board[r][c] = -1;
	}
	for (r = 0; r < ROWS; r++)
		for (c = 0; c < COLS; c++) {
			if (board[r][c] == -1) continue;
			n = 0;
			for (dr = -1; dr <= 1; dr++)
				for (dc = -1; dc <= 1; dc++) {
					nr = r + dr;
					nc = c + dc;
					if (nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS)
						if (board[nr][nc] == -1) n++;
				}
			board[r][c] = n;
		}
}

void draw_cell(int win, int r, int c)
{
	int x, y;
	char s[2];
	x = BX + c * CELL;
	y = BY + r * CELL;
	if (opened[r][c]) {
		BoxFilWin(win, x, y, x + CELL - 2, y + CELL - 2, 7);
		if (board[r][c] == -1) {
			PutStrWin(win, x + 6, y + 3, 4, 0, "*");
		} else if (board[r][c] > 0) {
			s[0] = '0' + board[r][c];
			s[1] = 0;
			PutStrWin(win, x + 6, y + 3, 0, board[r][c], s);
		}
	} else if (flagged[r][c]) {
		BoxFilWin(win, x, y, x + CELL - 2, y + CELL - 2, 8);
		PutStrWin(win, x + 6, y + 3, 4, 0, "F");
	} else {
		BoxFilWin(win, x, y, x + CELL - 2, y + CELL - 2, 8);
	}
}

void open_cell(int win, int r, int c)
{
	int dr, dc, nr, nc;
	if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return;
	if (opened[r][c] || flagged[r][c]) return;
	opened[r][c] = 1;
	if (board[r][c] == -1) {
		over = 1;
		return;
	}
	if (board[r][c] == 0) {
		for (dr = -1; dr <= 1; dr++)
			for (dc = -1; dc <= 1; dc++) {
				nr = r + dr;
				nc = c + dc;
				open_cell(win, nr, nc);
			}
	}
}
