[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "ms_start.nas"]
	GLOBAL	_start
	EXTERN	___main
[SECTION .text]
_start:
	CALL	___main
	MOV	EDX,4
	INT	0x40
