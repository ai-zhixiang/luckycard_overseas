/* apilib.h - WinDOS C 应用 API 库头文件 */
/* 应用程序只应包含此头文件和自己的代码，不应包含内核头文件 */

#ifndef APILIB_H
#define APILIB_H

/* 控制台输出 */
void putchar(int c);
void putstr0(char *s);
void putstr1(char *s, int l);
void end(void);

/* 窗口操作 */
int  createwin(char *buf, int xsiz, int ysiz, int col_inv, char *title);
void putstrwin(int win, int x, int y, int col, int len, char *str);
void boxfilwin(int win, int x0, int y0, int x1, int y1, int col);
void linewin(int win, int x0, int y0, int x1, int y1, int col);
void point(int win, int x, int y, int col);
void refreshwin(int win, int x0, int y0, int x1, int y1);
void closewin(int win);

/* 输入 */
int getkey(int mode);

/* 菜单 */
struct MENU_ITEM {
    unsigned char text[64];
    int action;
    struct MENU_ITEM *sub;
    int sub_count;
};
int show_menu(int x, int y, struct MENU_ITEM *items, int count);

/* 进程保护（系统内部用） */
void setcritical(int is_kernel, int bsod_on_kill, int is_system);

/* 颜色常量 */
#define COL8_000000  0
#define COL8_FF0000  1
#define COL8_00FF00  2
#define COL8_FFFF00  3
#define COL8_0000FF  4
#define COL8_FF00FF  5
#define COL8_00FFFF  6
#define COL8_FFFFFF  7
#define COL8_C6C6C6  8
#define COL8_840000  9
#define COL8_008400  10
#define COL8_848400  11
#define COL8_000084  12
#define COL8_840084  13
#define COL8_008484  14
#define COL8_848484  15

/* 新增 API：文件系统与内存（内部 API） */
int  list_files(void *buf, int buf_size);
void *malloc(int size);
void free(void *addr, int size);
int  run_wda(const char *fname);
int  CreateProcess(const char *fname);  /* run_wda 别名 */

/* 新增 API：任务管理（内部 API） */
int  get_tasklist(void *buf, int buf_size);
int  kill_task(int task_sel);

/* 系统信息 */
int  GetCurrentOSVersion(void);  /* 返回版本号*100，如 2614=26.14 */
int  is_window_valid(int win);   /* 窗口是否存在（1=存在 0=已关闭）*/

/* 定时器 */
void *api_alloctimer(void);
void  api_inittimer(void *timer, int data);
void  api_settimer(void *timer, unsigned int timeout);

/* 原书兼容别名 */
#define api_openwin     createwin
#define api_boxfilwin   boxfilwin
#define api_putstrwin   putstrwin
#define api_refreshwin  refreshwin
#define api_getkey      getkey

/* 格式化 */
int  wsprintf(char *buf, const char *fmt, ...);  /* sprintf 别名（cc1 内置冲突）*/
void itoa(int n, char *buf);
void hexstr(unsigned int n, char *buf);
int  strlen(const char *s);
char *strcpy(char *dst, const char *src);

int ClickedButton(int win, int bx, int by, int bw, int bh);
void Sleep(int ms);

#endif
