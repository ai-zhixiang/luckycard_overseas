/* hello2.c - 最简测试 */
void main(void)
{
	end();
}
