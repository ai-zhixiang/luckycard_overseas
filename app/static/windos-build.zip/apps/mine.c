/* mine.c — 扫雷 (kernel task) */
#include "bootpack.h"

#define ROWS 9
#define COLS 9
#define MINES 10
#define CELL 20
#define BX 4
#define BY 24

static int board[ROWS][COLS];
static int opened[ROWS][COLS];
static int flagged[ROWS][COLS];
static int over;
static int rng_seed;

static int my_rand(void) {
	rng_seed = rng_seed * 1103515245 + 12345;
	return (rng_seed >> 16) & 0x7FFF;
}

static void init_board(void)
{
	int i, r, c, dr, dc, nr, nc, n;
	rng_seed = (int)api_alloctimer();
	for (r = 0; r < ROWS; r++)
		for (c = 0; c < COLS; c++) {
			board[r][c] = 0; opened[r][c] = 0; flagged[r][c] = 0;
		}
	for (i = 0; i < MINES; i++) {
		r = my_rand() % ROWS; c = my_rand() % COLS;
		if (board[r][c] == -1) i--; else board[r][c] = -1;
	}
	for (r = 0; r < ROWS; r++)
		for (c = 0; c < COLS; c++) {
			if (board[r][c] == -1) continue;
			n = 0;
			for (dr = -1; dr <= 1; dr++)
				for (dc = -1; dc <= 1; dc++) {
					nr = r + dr; nc = c + dc;
					if (nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS)
						if (board[nr][nc] == -1) n++;
				}
			board[r][c] = n;
		}
}

static void draw_cell(int win, int r, int c)
{
	int x = BX + c * CELL, y = BY + r * CELL;
	char s[2];
	if (opened[r][c]) {
		BoxFilWin(win, x, y, x + CELL - 2, y + CELL - 2, 7);
		if (board[r][c] == -1) {
			PutStrWin(win, x + 6, y + 3, 4, 0, "*");
		} else if (board[r][c] > 0) {
			s[0] = '0' + board[r][c]; s[1] = 0;
			PutStrWin(win, x + 6, y + 3, 0, board[r][c], s);
		}
	} else if (flagged[r][c]) {
		BoxFilWin(win, x, y, x + CELL - 2, y + CELL - 2, 8);
		PutStrWin(win, x + 6, y + 3, 4, 0, "F");
	} else {
		BoxFilWin(win, x, y, x + CELL - 2, y + CELL - 2, 8);
	}
}

static void open_cell(int win, int r, int c)
{
	int dr, dc;
	if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return;
	if (opened[r][c] || flagged[r][c]) return;
	opened[r][c] = 1;
	if (board[r][c] == -1) { over = 1; return; }
	if (board[r][c] == 0)
		for (dr = -1; dr <= 1; dr++)
			for (dc = -1; dc <= 1; dc++)
				open_cell(win, r + dr, c + dc);
}

void HariMain(void)
{
	int win, r, c, bx, by, clicked;
	char buf[200 * 240];
	win = CreateWin(buf, 200, 240, -1, "Minesweeper");
	init_board();
	BoxFilWin(win, 0, 0, 199, 239, 7);
	for (r = 0; r < ROWS; r++)
		for (c = 0; c < COLS; c++)
			draw_cell(win, r, c);
	RefreshWin(win, 0, 0, COLS * CELL + 8, ROWS * CELL + 28);

	while (over == 0) {
		clicked = 0;
		for (r = 0; r < ROWS && clicked == 0; r++)
			for (c = 0; c < COLS && clicked == 0; c++) {
				bx = BX + c * CELL; by = BY + r * CELL;
				if (api_clickedbutton(win, bx, by, CELL, CELL)) {
					clicked = 1;
					open_cell(win, r, c);
					draw_cell(win, r, c);
					RefreshWin(win, 0, 0, 200, 240);
				}
			}
		/* 让出 CPU */
		api_alloctimer();
	}
	BoxFilWin(win, 40, 90, 160, 130, 14);
	PutStrWin(win, 50, 105, 7, 0, "GAME OVER");
	RefreshWin(win, 0, 0, 200, 240);
	for (;;) api_alloctimer();
}
