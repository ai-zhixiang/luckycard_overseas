/* minitest.c — 最小窗口测试 (.wda) — 点 X 关闭 */
#include "apilib.h"

void main(void)
{
    char *buf;
    int win;

    buf = (char *)malloc(160 * 68);
    if (buf == 0) return;

    win = createwin(buf, 160, 68, -1, "MiniTest");
    if (win <= 0) return;

    boxfilwin(win, 8, 28, 151, 60, COL8_FFFFFF);
    putstrwin(win, 16, 36, COL8_000000, 17, "minitest running!");

    while (is_window_valid(win)) {}
}
