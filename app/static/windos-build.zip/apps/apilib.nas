; apilib.nas - WinDOS Ӧ�ó��� API ��
[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "apilib.nas"]

[SECTION .text]

	GLOBAL	_putchar
_putchar:	; void putchar(int c);
	MOV	EDX,1
	MOV	EAX,[ESP+4]
	INT	0x40
	RET

	GLOBAL	_putstr0
_putstr0:	; void putstr0(char *s);
	MOV	EDX,2
	MOV	EBX,[ESP+4]
	INT	0x40
	RET

	GLOBAL	_end
_end:		; void end(void);
	MOV	EDX,4
	INT	0x40
	RET

	GLOBAL	_createwin
_createwin:	; int createwin(char *buf, int xsiz, int ysiz, int col_inv, char *title);
	PUSH	EBX
	MOV	EDX,5
	MOV	EBX,[ESP+8]
	MOV	ESI,[ESP+12]
	MOV	EDI,[ESP+16]
	MOV	EAX,[ESP+20]
	MOV	ECX,[ESP+24]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_putstrwin
_putstrwin:	; void putstrwin(int win, int x, int y, int col, int len, char *str);
	PUSH	EBX
	PUSH	EBP
	MOV	EDX,6
	MOV	EBX,[ESP+12]
	MOV	ESI,[ESP+16]
	MOV	EDI,[ESP+20]
	MOV	EAX,[ESP+24]
	MOV	ECX,[ESP+28]
	MOV	EBP,[ESP+32]
	INT	0x40
	POP	EBP
	POP	EBX
	RET

	GLOBAL	_boxfilwin
_boxfilwin:	; void boxfilwin(int win, int x0, int y0, int x1, int y1, int col);
	PUSH	EBX
	PUSH	EBP
	MOV	EDX,7
	MOV	EBX,[ESP+12]
	MOV	EAX,[ESP+16]
	MOV	ECX,[ESP+20]
	MOV	ESI,[ESP+24]
	MOV	EDI,[ESP+28]
	MOV	EBP,[ESP+32]
	INT	0x40
	POP	EBP
	POP	EBX
	RET

	GLOBAL	_linewin
_linewin:	; void linewin(int win, int x0, int y0, int x1, int y1, int col);
	PUSH	EBX
	PUSH	EBP
	MOV	EDX,8
	MOV	EBX,[ESP+12]
	MOV	ESI,[ESP+16]
	MOV	EDI,[ESP+20]
	MOV	EAX,[ESP+24]
	MOV	ECX,[ESP+28]
	MOV	EBP,[ESP+32]
	INT	0x40
	POP	EBP
	POP	EBX
	RET

	GLOBAL	_point
_point:		; void point(int win, int x, int y, int col);
	PUSH	EBX
	MOV	EDX,9
	MOV	EBX,[ESP+8]
	MOV	ESI,[ESP+12]
	MOV	EDI,[ESP+16]
	MOV	EAX,[ESP+20]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_refreshwin
_refreshwin:	; void refreshwin(int win, int x0, int y0, int x1, int y1);
	PUSH	EBX
	MOV	EDX,10
	MOV	EBX,[ESP+8]
	MOV	ESI,[ESP+12]
	MOV	EDI,[ESP+16]
	MOV	EAX,[ESP+20]
	MOV	ECX,[ESP+24]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_closewin
_closewin:	; void closewin(int win);
	PUSH	EBX
	MOV	EDX,11
	MOV	EBX,[ESP+8]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_getkey
_getkey:	; int getkey(int mode);
	MOV	EDX,12
	MOV	EAX,[ESP+4]
	INT	0x40
	RET

	GLOBAL	_show_menu
_show_menu:	; int show_menu(int x, int y, struct MENU_ITEM *items, int count);
	PUSH	EBX
	MOV	EDX,13
	MOV	EBX,[ESP+8]
	MOV	ESI,[ESP+12]
	MOV	EDI,[ESP+16]
	MOV	EAX,[ESP+20]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_setcritical
_setcritical:	; void setcritical(int is_kernel, int bsod_on_kill, int is_system);
	PUSH	EBX
	MOV	EDX,14
	MOV	EBX,[ESP+8]
	MOV	ESI,[ESP+12]
	MOV	EDI,[ESP+16]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_list_files
_list_files:	; int list_files(void *buf, int buf_size);
	PUSH	EBX
	MOV	EDX,15
	MOV	EBX,[ESP+8]
	MOV	ESI,[ESP+12]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_malloc
_malloc:	; void *malloc(int size);
	PUSH	EBX
	MOV	EDX,16
	MOV	EBX,[ESP+8]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_free
_free:		; void free(void *addr, int size);
	PUSH	EBX
	MOV	EDX,17
	MOV	EBX,[ESP+8]
	MOV	ECX,[ESP+12]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_run_wda
_run_wda:	; int run_wda(const char *fname);
	PUSH	EBX
	MOV	EDX,18
	MOV	EBX,[ESP+8]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_CreateProcess
_CreateProcess:	; int CreateProcess(const char *fname);
	PUSH	EBX
	MOV	EDX,18
	MOV	EBX,[ESP+8]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_get_tasklist
_get_tasklist:	; int get_tasklist(void *buf, int buf_size);
	PUSH	EBX
	MOV	EDX,19
	MOV	EBX,[ESP+8]
	MOV	ESI,[ESP+12]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_kill_task
_kill_task:	; int kill_task(int task_sel);
	PUSH	EBX
	MOV	EDX,20
	MOV	EBX,[ESP+8]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_GetCurrentOSVersion
_GetCurrentOSVersion:	; int GetCurrentOSVersion(void);
	MOV	EDX,21
	INT	0x40
	RET

	GLOBAL	_is_window_valid
_is_window_valid:	; int is_window_valid(int win);
	PUSH	EBX
	MOV	EDX,22
	MOV	EBX,[ESP+8]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_api_alloctimer
_api_alloctimer:
	PUSH	EBX
	MOV	EDX,23
	INT	0x40
	POP	EBX
	RET
	GLOBAL	_ClickedButton
_ClickedButton:
	MOV	EDX,26
	INT	0x40
	RET

	GLOBAL	_Sleep
_Sleep:
	MOV	EDX,27
	INT	0x40
	RET


	GLOBAL	_api_inittimer
_api_inittimer:
	PUSH	EBX
	MOV	EDX,24
	MOV	EBX,[ESP+8]
	MOV	EAX,[ESP+12]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	_api_settimer
_api_settimer:
	PUSH	EBX
	MOV	EDX,25
	MOV	EBX,[ESP+8]
	MOV	EAX,[ESP+12]
	INT	0x40
	POP	EBX
	RET

	GLOBAL	__alloca
__alloca:
	SUB	ESP,EAX
	ADD	ESP,-4
	RET
