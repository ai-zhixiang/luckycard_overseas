; minesweeper.nas — BIOS version
[FORMAT "WCOFF"]
[INSTRSET "i486p"]
[BITS 32]
[FILE "minesweeper.nas"]

	GLOBAL	_HariMain

[SECTION .text]
_HariMain:
	; Just call end for now - stub
	MOV		EDX,4
	INT		0x40
