/* winver.c — 显示 WinDOS 版本 */
#include "apilib.h"

void main(void)
{
    char *fbuf;
    int win;

    fbuf = (char *)malloc(200 * 100);
    if (fbuf == 0) return;

    win = createwin(fbuf, 200, 100, -1, "WinDOS Version");
    if (win <= 0) return;

    boxfilwin(win, 8, 28, 191, 91, COL8_FFFFFF);
    putstrwin(win, 20, 42, COL8_000000, 30, "WinDOS build 26.14");

    while (is_window_valid(win)) {}
}
