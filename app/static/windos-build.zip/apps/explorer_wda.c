/* explorer_wda.c - 独立文件管理器（.wda 版）*/
#include "apilib.h"

#define MAX_WDA_FILES 224

/* FAT12 FILEINFO 结构体（直接匹配内核定义）*/
struct FILEINFO {
	unsigned char name[8], ext[3], type;
	char reserve[10];
	unsigned short time, date, clustno;
	unsigned int size;
};

/* 文件列表条目（精简版）*/
struct FILE_ENTRY {
	char display[20];
};

void main(void)
{
	int win;
	int w = 500, h = 350;
	int i, file_count;
	struct FILEINFO finfo[MAX_WDA_FILES];
	char *buf;

	/* 从堆分配窗口缓冲区（栈只有 8KB，不够 500*350）*/
	buf = (char *)malloc(w * h);
	if (buf == 0) return;

	/* 读取文件列表 */
	file_count = list_files(finfo, sizeof(finfo));
	if (file_count < 0) file_count = 0;

	/* 创建窗口 */
	win = createwin(buf, w, h, -1, "File Explorer");
	if (win <= 0) { free(buf, w * h); return; }

	/* 显示文件列表 */
	{
		char line[40];
		int y = 28;
		for (i = 0; i < file_count && i < 18; i++) {
			int j;
			for (j = 0; j < 8 && finfo[i].name[j] != ' '; j++) {
				line[j] = finfo[i].name[j];
			}
			if (j > 0) { line[j] = '.'; j++; }
			line[j] = finfo[i].ext[0];
			line[j+1] = finfo[i].ext[1];
			line[j+2] = finfo[i].ext[2];
			line[j+3] = ' ';
			{
				char sz[12];
				int k, sz_val = finfo[i].size;
				/* 数字转字符串 */
				for (k = 11; k >= 0; k--) {
					if (sz_val > 0) { sz[k] = '0' + (sz_val % 10); sz_val /= 10; }
					else if (k < 7) sz[k] = ' ';
					else sz[k] = '0';
				}
				sz[7] = 0;
				for (k = 0; sz[k]; k++) line[j+4+k] = sz[k];
				line[j+4+k] = 0;
			}
			putstrwin(win, 8, y, 0, 40, line);
			y += 16;
		}
	}
	refreshwin(win, 0, 0, w, h);

	/* 等待 ESC 退出 */
	for (;;) {
		int key = getkey(0);
		if (key == 0x01) break;  /* ESC */
	}

	closewin(win);
	free(buf, w * h);
	end();
}
