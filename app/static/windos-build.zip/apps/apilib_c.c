/* apilib_c.c - 应用层轻量 C 辅助函数（sprintf 等）*/
#include "apilib.h"

/* strcpy */
char *strcpy(char *dst, const char *src)
{
	char *d = dst;
	while ((*d++ = *src++) != 0);
	return dst;
}

/* strlen */
int strlen(const char *s)
{
	int n = 0;
	while (*s++) n++;
	return n;
}

/* 整数 → 字符串 */
void itoa(int n, char *buf)
{
	int i = 0, neg = 0;
	char tmp[12];
	if (n < 0) { neg = 1; n = -n; }
	do { tmp[i++] = '0' + (n % 10); n /= 10; } while (n > 0);
	if (neg) tmp[i++] = '-';
	if (i == 0) tmp[i++] = '0';
	while (i > 0) buf[neg++] = tmp[--i];
	buf[neg] = 0;
}

/* 十六进制整数 → 字符串 */
void hexstr(unsigned int n, char *buf)
{
	int i = 0, d;
	char tmp[12];
	do { d = n & 0xF; tmp[i++] = d < 10 ? '0' + d : 'A' + d - 10; n >>= 4; } while (n > 0);
	while (i > 0) *buf++ = tmp[--i];
	*buf = 0;
}

/* 轻量 wsprintf — 仅支持 %d %x %X %s %%（避开 cc1 对 sprintf 的内置处理）*/
int wsprintf(char *buf, const char *fmt, ...)
{
	char *p = buf;
	const char *f = fmt;
	int *args = (int *)(&fmt) + 1;  /* 变参：fmt 之后的第一项 */
	int arg_idx = 0;

	while (*f) {
		if (*f == '%') {
			f++;
			if (*f == 'd') {
				int n = args[arg_idx++];
				if (n < 0) { *p++ = '-'; n = -n; }
				itoa(n < 0 ? -n : n, p);
				while (*p) p++;
			} else if (*f == 'x') {
				unsigned int n = args[arg_idx++];
				hexstr(n, p);
				while (*p) p++;
			} else if (*f == 'X') {
				unsigned int n = args[arg_idx++];
				hexstr(n, p);
				while (*p) p++;
			} else if (*f == 's') {
				char *s = (char *)args[arg_idx++];
				while (*s) *p++ = *s++;
			} else if (*f == '%') {
				*p++ = '%';
			}
			f++;
		} else {
			*p++ = *f++;
		}
	}
	*p = 0;
	return p - buf;
}
