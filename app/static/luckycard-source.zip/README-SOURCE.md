# Lucky Card — Open Source Code

This is a sanitized export of the Lucky Card source code.
API keys, secrets, and environment-specific configuration have been replaced with placeholders.

## Getting Started

1. Copy `.env.example` to `.env` and fill in your credentials
2. Install dependencies: `pip install -r requirements.txt`
3. Run: `uvicorn app.main:app --host 0.0.0.0 --port 8000`

## License

© 2026 Lucky Card. All rights reserved.
